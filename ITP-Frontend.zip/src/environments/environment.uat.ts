export const environment = {
        production: false,
        api: 'http://localhost:9080/itp-core/api/v1',
        name:'itp_uat',
        description:'itp_uat_application ,last build time :Thu Aug 13 2020 16:12:16 GMT+0300 (Arabian Standard Time)',
        version:'v1.0',
        sessionIdle:600,
        sessionTimeOut:10,
        sessionPing:120,
      };