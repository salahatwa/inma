export const environment = {
  production: true,
  api:'http://localhost:9080/itp-core/api/v1',
  name:'itp_prod',
  description:'itp_prod_application',
  version:'v1.0',
  sessionIdle:600,
  sessionTimeOut:10,
  sessionPing:120
};
