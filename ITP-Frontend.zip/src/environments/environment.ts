declare const require: any;
const { name, description, version } = require('../../package.json');

export const environment = {
  production: false,
  api: 'http://localhost:9080/itp/api/v1',
  name,
  description,
  version,
  sessionIdle:600,
  sessionTimeOut:10,
  sessionPing:120,
};
