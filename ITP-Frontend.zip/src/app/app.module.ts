import { DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UserIdleModule } from 'angular-user-idle';
import { NgProgressModule } from 'ngx-progressbar';
import { NgProgressHttpModule } from 'ngx-progressbar/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from './pages/layout.module';
import { LoginModule } from './pages/login/login.module';
import { UserIdleDialogComponent } from './shared/components/user-idle-dialog/user-idle-dialog.component';
import { CounterDirective } from './shared/directives/counter.directive';
import { SharedModule } from './shared/modules/shared.module';
import { TranslationModule } from './shared/modules/translation.module';
import { Config } from './shared/utils/config';


// npm install --save notyf
// ng serve -prod
const env = new Config();
@NgModule({
  declarations: [
    AppComponent,
    UserIdleDialogComponent,
    CounterDirective
  ],
  imports: [
    BrowserAnimationsModule,
    HttpClientModule,
    NgProgressModule.withConfig({
      spinnerPosition: "left",
      color: "#fff"
    }),
    NgProgressHttpModule,
    AppRoutingModule,
    LayoutModule,
    LoginModule,
    TranslationModule,
    UserIdleModule.forRoot({ idle: env.sessionIdle, timeout: env.sessionTimeOut, ping: env.sessionPing }),
    SharedModule,
    
  ],
  providers: [Title, Config, DatePipe],
  entryComponents: [UserIdleDialogComponent],
  bootstrap: [AppComponent],
})
export class AppModule { }
