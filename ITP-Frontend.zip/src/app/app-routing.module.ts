import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CustomerSearchComponent } from './pages/customer-search/customer-search.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LayoutComponent } from './pages/layout.component';
import { LoginComponent } from './pages/login/login.component';
import { OrderSearchComponent } from './pages/order-search/order-search.component';
import { ErrorComponent } from './shared/components/error.component';
import { AuthGuard } from './shared/services/auth/auth-guard.service';
import { NoAuthGuard } from './shared/services/auth/no-auth-guard.service';
import { LivePricesComponent } from './pages/live-prices/live-prices.component';


@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: 'login', component: LoginComponent, data: { title: 'form.button.login' }, canActivate: [NoAuthGuard] },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
        canActivate: [AuthGuard],
        data: { title: 'dashboard.title' }
      },
      {
        path: '',
        component: LayoutComponent,
        canActivateChild: [AuthGuard],
        children: [
          {
            path: 'dashboard',
            component: DashboardComponent,
            data: { title: 'dashboard.title' }
          },
          {
            path: 'order-search',
            component: OrderSearchComponent,
            data: { title: 'dashboard.title' }
          },
          {
            path: 'customer-search',
            component: CustomerSearchComponent,
            data: { title: 'dashboard.title' }
          },
          {
            path: 'live-prices',
            component: LivePricesComponent,
            data: { title: 'dashboard.title' }
          }
        ]
      },
      { path: '404', component: ErrorComponent },
      { path: '**', component: ErrorComponent, pathMatch: 'full' }
    ], { useHash: true })
  ],
  declarations: [
    ErrorComponent,
  ],
  providers: [],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
