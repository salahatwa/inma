import { Injectable, Injector } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { JwtService } from './jwt.service';
import { UtilsService } from '../utils.service';

@Injectable()
export class HttpTokenInterceptor implements HttpInterceptor {
  constructor(private jwtService: JwtService,private utilService:UtilsService,private router:Router) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const headersConfig = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    const token = this.jwtService.getToken();

    if (token) {
      headersConfig['Authorization'] = `Bearer ${token}`;
    }

    const lang=this.utilService.getCurrentLang();
    if (lang) {
      headersConfig['Accept-Language'] = `${lang}`;
    }else
     headersConfig['Accept-Language'] = `ar`;

    const request = req.clone({ setHeaders: headersConfig,withCredentials: false});
  
    return next.handle(request).pipe(
      catchError(
        (err, caught) => {
          
          if (err.status === 401){
            this.handleAuthError();
            return of(err);
          }else if(err.status==0)
          {
            err.error={
              message:"Server not reachable"
            }
          }
          throw err;
        }
      )
    );
  }
  private handleAuthError() {
    this.jwtService.destroyToken();
    this.router.navigateByUrl('/login');
  }
}
