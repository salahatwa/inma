import { Injectable } from '@angular/core';

import { JSEncrypt } from 'jsencrypt';
import { throwError, Observable, of } from 'rxjs';
import { Config } from '../utils/config';

@Injectable({
  providedIn: 'root'
})
export class RSAUtilsService {

  // privateKey = `-----BEGIN RSA PRIVATE KEY-----
  // MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAKAUZV+tjiNBKhlBZbKBnzeugpdYPhh5PbHanjV0aQ+LF7vetPYhbTiCVqA3a+Chmge44+prlqd3qQCYra6OYIe7oPVq4mETa1c/7IuSlKJgxC5wMqYKxYydb1eULkrs5IvvtNddx+9O/JlyM5sTPosgFHOzr4WqkVtQ71IkR+HrAgMBAAECgYAkQLo8kteP0GAyXAcmCAkA2Tql/8wASuTX9ITD4lsws/VqDKO64hMUKyBnJGX/91kkypCDNF5oCsdxZSJgV8owViYWZPnbvEcNqLtqgs7nj1UHuX9S5yYIPGN/mHL6OJJ7sosOd6rqdpg6JRRkAKUV+tmN/7Gh0+GFXM+ug6mgwQJBAO9/+CWpCAVoGxCA+YsTMb82fTOmGYMkZOAfQsvIV2v6DC8eJrSa+c0yCOTa3tirlCkhBfB08f8U2iEPS+Gu3bECQQCrG7O0gYmFL2RX1O+37ovyyHTbst4s4xbLW4jLzbSoimL235lCdIC+fllEEP96wPAiqo6dzmdH8KsGmVozsVRbAkB0ME8AZjp/9Pt8TDXD5LHzo8mlruUdnCBcIo5TMoRG2+3hRe1dHPonNCjgbdZCoyqjsWOiPfnQ2Brigvs7J4xhAkBGRiZUKC92x7QKbqXVgN9xYuq7oIanIM0nz/wq190uq0dh5Qtow7hshC/dSK3kmIEHe8z++tpoLWvQVgM538apAkBoSNfaTkDZhFavuiVl6L8cWCoDcJBItip8wKQhXwHp0O3HLg10OEd14M58ooNfpgt+8D8/8/2OOFaR0HzA+2Dm
  // -----END RSA PRIVATE KEY-----`;


  $encrypt: any; // JSEncrypt instance

  constructor(private config: Config) {
    this.$encrypt = new JSEncrypt();
    this.$encrypt.setPublicKey(`-----BEGIN PUBLIC KEY-----` +this.config.publicKey+ `-----END PUBLIC KEY-----`);
  }

/**
 * Encrypt text should be less than 117 length
 * @param plainText  
 */
  encrypt(plainText: string): Observable<string> {
    const text = `${plainText}`.trim();

    // The 1024-bit key supports a maximum plaintext length of 127
    if (text.length > 117) {
      return throwError('The content is too long, please re-enter');
    } else {

      return of(this.$encrypt.encrypt(text));
    }
  }

  // decrypt(cypherText: string): string {
  //   this.$encrypt.setPrivateKey(this.privateKey);
  //   const plainText = this.$encrypt.decrypt(cypherText);
  //   if (Object.is(plainText, null)) {
  //     console.log('Decryption failed');
  //   }
  //   return plainText;
  // }
}
