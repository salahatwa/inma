import { OrderDetails } from './../../core/models/models';

export class Constant {

    static NUMBER_REGEX = [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/];
    static DATE_REGEX = [/\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/];


    static MAX_PRICE_VALUE = 1000000;
    static MIN_PRICE_VALUE = 1;

    static BUY = 'SPR';
    static SELL = 'SSL';
    static MARKET_PRICE = '1';
    static LIMIT_PRICE = '2';

    static CUSTOM_DATE = '6';
    static TODAY_ONLY = '0';


    /**
     * 
     * @param order 
     */
    static clipboardMsg(order: OrderDetails) {
        return "OMSRefNum:" + order.omsRefNum + "	MrktRefNum:" + ((order?.mrktRefNum) ? order.mrktRefNum : '') + "	PortfolioNum:" + order.portfolioNum + "	Symbol:" + order.symbol + "	OrdQty:" + order.ordQty + "	AvgPrice:" + order.avgPrice + "	OrdCommiss:" + order.ordCommiss + "	OrdDt:" + order.ordDt + "	OrdDtHjr:" + order.ordDtHjr + "	ExpDt:" + order.expDt + "	ExcQty:" + order.excQty + "	OrdSide:شراء	OrdSideID:" + order.ordSide + "	OrdType:" + order.ordType + "OrdTifType:" + order.tifType + "	Amt:" + ((order.curAmt) ? order.curAmt.amt : '') + "	CurCode:" + ((order.curAmt) ? order.curAmt.curCode : '') + "	RmnngQty:" + order.rmnngQty + "	MaxFloor:" + ((order.maxFloor) ? order.maxFloor : '') + "	MrktAuthrzd:" + order.mrktAuthrzd;
    }


    /**
     * Validate Date yyyy-mm-dd
     */
    static DatePattern = '^(19[5-9][0-9]|20[0-4][0-9]|2050)[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12][0-9]|3[01])$';

    static INVALID_CHARS = [
        "-",
        "+",
        "e",
    ];

    /**
 * Market Price
 */
    static tifTypeMPrice = [
        {
            "key": "enter_order.tifType.todayOnly",
            "value": "0"
        },
        {
            "key": "enter_order.tifType.atOpening",
            "value": "2"
        },
        {
            "key": "enter_order.tifType.fillAndKill",
            "value": "3"
        },
        {
            "key": "enter_order.tifType.fillOrKill",
            "value": "4"
        },

        {
            "key": "enter_order.tifType.specDate",
            "value": "6"
        }

    ];



    /**
     * Limit Price
     */
    static tifTypeLPrice = [

        {
            "key": "enter_order.tifType.todayOnly",
            "value": "0"
        },
        {
            "key": "enter_order.tifType.atOpening",
            "value": "2"
        },
        {
            "key": "enter_order.tifType.specDate",
            "value": "6"
        },
        // {
        //     "key":"enter_order.tifType.endOfWeek",
        //     "value":"6"
        // },
        // {
        //     "key":"enter_order.tifType.endOfMonth",
        //     "value":"6"
        // }

    ];

    static PAGINATION_MAX_RECS = 10;
    static ORDER_TRADES_LIST = 1;
    static OUTSTANDING_ORDERS_LIST = 2;

    static N_ALLOWED_OPT_ORD_STATUS = ['2', '6', '4', 'N', 'NEW', '8', 'C'];
    static N_ALLOWED_OPT_ORD_STATUS_UPDATE = ['2', '4', 'N', '8', 'C'];
    static ADD_ORDER_ACTION = 'ADD';
    static UPDATE_ORDER_ACTION = 'UPDATE';
    static CANCEL_ORDER_ACTION = 'CANCEL';

}
