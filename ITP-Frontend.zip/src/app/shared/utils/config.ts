import { environment } from '../../../environments/environment';

export class Config {
  name: string = environment.name;
  description: string = environment.description;
  version: string = environment.version;
  api: string = environment.api;
  sessionIdle:number=environment.sessionIdle;
  sessionTimeOut:number=environment.sessionTimeOut;
  sessionPing:number=environment.sessionPing;
  publicKey:string='MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCgFGVfrY4jQSoZQWWygZ83roKXWD4YeT2x2p41dGkPixe73rT2IW04glagN2vgoZoHuOPqa5and6kAmK2ujmCHu6D1auJhE2tXP+yLkpSiYMQucDKmCsWMnW9XlC5K7OSL77TXXcfvTvyZcjObEz6LIBRzs6+FqpFbUO9SJEfh6wIDAQAB'
}

