import { AbstractControl, ValidationErrors, Validators, ValidatorFn, FormGroup } from '@angular/forms'
import { Constant } from './constant';

export function tickSize(control: AbstractControl): ValidationErrors | null {
    var val = control.value;

    if (!isNaN(val)) {
        var price = parseInt(control.value);
        if (val && val.indexOf(".") > -1) {
            var decVal = val.substring(val.indexOf(".") + 1);
            if (decVal.length == 1) {
                decVal = decVal + "0";
            }
            var intval = parseInt(decVal);

            if (price >= 10 && price < 25) {
                intval = intval % 2;
                if (intval != 0) {
                    return { 'tickSize': false, 'requiredValue': '0.02, 0.04, 0.06' };
                }
            }

            else if (price >= 25 && price < 50) {
                intval = intval % 5;
                if (intval != 0) {
                    return { 'tickSize': false, 'requiredValue': '0.05, 0.10, 0.15' };
                }
            }

            else if (price >= 50 && price < 100) {
                intval = intval % 10;
                if (intval != 0) {
                    return { 'tickSize': false, 'requiredValue': '0.10, 0.20, 0.40' };
                }
            }

            else if (price >= 100) {
                intval = intval % 20;
                if (intval != 0) {
                    return { 'tickSize': false, 'requiredValue': '0.20, 0.40, 0.60' };
                }
            }

        }

    } else {
        return { 'tickSize': false, 'requiredValue': ' Numbers' };
    }

    return null;

}


export function priceRangeValidator(min: number, max: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {

        if (!control.parent) {
            return null;
        }

        // control.parent.get('orderSide').value == 'SPR';

        if (control.value !== undefined && (isNaN(control.value) || control.value < min || control.value > max)) {
            return { 'priceRange': true, 'priceValue': [min, max] };
        }
        return null;
    };
}


export function quanityValidator(ownedQuantity: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {


        if (!control.parent) {
            return null;
        }

        if (ownedQuantity !== undefined && control.parent.get('orderSide').value == Constant.SELL && control.value !== undefined && (isNaN(ownedQuantity) || control.value > ownedQuantity)) {
            return { 'qtyOwned': false, 'qtyValue': ownedQuantity };
        }
        return null;
    };
}

export function priceConditionallyRequiredValidator(formControl: AbstractControl) {
    if (!formControl.parent) {
        return null;
    }

    if (formControl.parent.get('orderType').value == Constant.LIMIT_PRICE) {
        return Validators.required(formControl);
    }
    return null;
}


export function dateConditionallyRequiredValidator(formControl: AbstractControl) {
    if (!formControl.parent) {
        return null;
    }

    if (formControl.parent.get('orderTifType').value == Constant.CUSTOM_DATE) {
        return Validators.required(formControl);
    }
    return null;
}


export function validateDate(group: FormGroup) {
    const invalid = Date.parse(group.get('fromDate').value) > Date.parse(group.get('toDate').value);
    return invalid ? { 'invalidDate': true } : null;
}


