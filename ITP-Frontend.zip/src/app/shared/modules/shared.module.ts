import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { TextMaskModule } from 'angular2-text-mask';
import { AlertModule } from '../components/alert/alert.module';
import { ConfirmOrderDialogComponent } from '../components/dashboard/app-dialogs/confirm-order-dialog/confirm-order-dialog.component';
import { CommissionDetailComponent } from '../components/dashboard/commission-detail/commission-detail.component';
import { OrderHistoryComponent } from '../components/dashboard/order-list-detail/order-history/order-history.component';
import { OrderSummaryComponent } from '../components/dashboard/order-list-detail/order-summary/order-summary.component';
import { OrderUpdateDialogComponent } from '../components/dashboard/order-list-detail/order-update/order-update-dialog.component';
import { OrderUpdateComponent } from '../components/dashboard/order-list-detail/order-update/update/order-update.component';
import { OrdersListComponent } from '../components/dashboard/order-list-detail/orders-list.component';
import { PortfolioDetailComponent } from '../components/dashboard/portfolio-stock-poi-details/portfolio-detail/portfolio-detail.component';
import { PortfolioDetailsDailogComponent } from '../components/dashboard/portfolio-stock-poi-details/portfolio-search/portfolio-details-dailog/portfolio-details-dailog.component';
import { PortfolioSearchComponent } from '../components/dashboard/portfolio-stock-poi-details/portfolio-search/portfolio-search.component';
import { PortfolioStockDetailComponent } from '../components/dashboard/portfolio-stock-poi-details/portfolio-stock-detail/portfolio-stock-detail.component';
import { PortfolioStockPoiDetailsComponent } from '../components/dashboard/portfolio-stock-poi-details/portfolio-stock-poi-details.component';
import { StockDetailComponent } from '../components/dashboard/stock-detail/stock-detail.component';
import { FooterModule } from '../components/footer/footer.module';
import { NavbarModule } from '../components/navbar/navbar.module';
import { ApiService } from '../services/api.service';
import { UtilsService } from '../services/utils.service';
import { BootstrapModule } from './bootstrap.module';
import { IconsModule } from './icons.module';
import { PaginationModule } from '../components/pagination/pagination.module';
import { OrderExportDialogComponent } from '../components/dashboard/order-list-detail/order-export/order-export-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    AlertModule,
    TextMaskModule,
    TranslateModule,
    BootstrapModule,
    NavbarModule,
    FooterModule,
    IconsModule,
    PaginationModule
  ],
  declarations: [
    StockDetailComponent,
    PortfolioStockDetailComponent,
    CommissionDetailComponent,
    PortfolioDetailComponent,
    PortfolioDetailsDailogComponent,
    PortfolioSearchComponent,
    PortfolioStockDetailComponent,
    PortfolioStockPoiDetailsComponent,
    ConfirmOrderDialogComponent,
    OrdersListComponent,
    OrderSummaryComponent,
    OrderUpdateComponent,
    OrderUpdateDialogComponent,
    OrderHistoryComponent,
    OrderExportDialogComponent
  ],
  providers: [Title, UtilsService, ApiService],
  exports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    AlertModule,
    TextMaskModule,
    NavbarModule,
    TranslateModule,
    BootstrapModule,
    FooterModule,
    StockDetailComponent,
    CommissionDetailComponent,
    PortfolioDetailComponent,
    PortfolioDetailsDailogComponent,
    PortfolioSearchComponent,
    PortfolioStockDetailComponent,
    PortfolioStockPoiDetailsComponent,
    ConfirmOrderDialogComponent,
    OrdersListComponent,
    OrderSummaryComponent,
    OrderUpdateComponent,
    OrderUpdateDialogComponent,
    IconsModule,
    PaginationModule,
    OrderExportDialogComponent
  ],
  entryComponents: [
    ConfirmOrderDialogComponent,OrderUpdateDialogComponent,OrderSummaryComponent,OrderHistoryComponent,OrderExportDialogComponent
  ]
})
export class SharedModule { }
