import { NgModule } from "@angular/core";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  imports: [
    NgbModule
  ],
  exports: [
    NgbModule
  ],
  providers: [
  ]
})
export class BootstrapModule { }
