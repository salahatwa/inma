import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertComponent } from './alert.component';
import { TranslationModule } from '../../modules/translation.module';
import { IconsModule } from '../../modules/icons.module';



@NgModule({
  declarations: [AlertComponent],
  imports: [
    CommonModule,
    IconsModule,
    TranslationModule
  ],
  exports:[
    AlertComponent
  ]
})
export class AlertModule { }
