import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar.component';
import { SharedModule } from '../../modules/shared.module';
import { BootstrapModule } from '../../modules/bootstrap.module';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { IconsModule } from '../../modules/icons.module';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [NavbarComponent],
  imports: [
    CommonModule,
    RouterModule,
    TranslateModule,
    IconsModule,
    NgbTooltipModule
  ],
  exports:[NavbarComponent]
})
export class NavbarModule { }
