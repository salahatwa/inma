import { Component, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UtilsService } from '../../services/utils.service';
import { PortfolioDetailsDailogComponent } from '../dashboard/portfolio-stock-poi-details/portfolio-search/portfolio-details-dailog/portfolio-details-dailog.component';
import { User } from './../../../core/models/models';
import { UserService } from './../../../core/services/user.service';

declare var numeral: any;
@Component({
  selector: 'app-inma-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent {

  currentUser: User;
  selectedLang: string = 'ar';



  constructor(private utilService: UtilsService, private userService: UserService, private modalService: NgbModal, private router: Router) {

  }

  logout() {
    this.userService.purgeAuth();

    this.router.navigate(['/login']);
  }

  ngOnInit() {
    this.userService.currentUser.subscribe(user => {
      this.currentUser = user;
    });

  }


  switchLang() {
    this.selectedLang = this.utilService.getCurrentLang();
    if (this.selectedLang == "ar")
      this.selectedLang = this.utilService.setLang("en");
    else if (this.selectedLang == "en")
      this.selectedLang = this.utilService.setLang("ar");
  }




  isScrollDisplayed: boolean;
  sidbarOpen = false;
  subMenuToggle = false;


  sidebar(val: boolean) {
    this.sidbarOpen = val;
  }

  toggleSubMenu(event) {
    event.preventDefault();
    this.subMenuToggle = !this.subMenuToggle;

  }

  @HostListener('window:scroll')
  checkScroll() {

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;


    if (scrollPosition >= 100) {
      this.isScrollDisplayed = true;
    } else {
      this.isScrollDisplayed = false;
    }
  }


  gotoTop(event) {
    event.preventDefault();
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }



  openPortfolioSearchDialog() {
    const dialogRef = this.modalService.open(PortfolioDetailsDailogComponent, { scrollable: true, size: 'xl' });
    dialogRef.componentInstance.portfolio = {};
    dialogRef.result.then(res => {

    }).catch((res) => {
          
    });
  }


}