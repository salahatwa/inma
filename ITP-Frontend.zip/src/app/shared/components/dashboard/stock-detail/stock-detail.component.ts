import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { EventData, StockDetails } from '../../../../core/models/models';
import { UtilsService } from '../../../services/utils.service';
import { StockService } from './../../../../core/services/api';
import { EventBusService } from './../../../../core/services/event-bus.service';

@Component({
  selector: 'app-stock-detail',
  templateUrl: './stock-detail.component.html',
  styleUrls: []
})
export class StockDetailComponent implements OnInit, OnDestroy {

  subscribition: Subscription;
  stock: StockDetails;

  @Input() event: string;

  constructor(private stockService: StockService, private utilService: UtilsService, private eventBus: EventBusService) { }

  /**
   * Listen to events from components [enter-order , update-order] and return data to same components
   *   
   */
  ngOnInit(): void {
    this.subscribition = this.eventBus.on(this.event, (event: EventData) => {

      if (event.value === undefined || event.value === null) {
        this.stock = {};
        return;
      }

      let symbol: string = event.value;

      this.stockService.getStockDetails(symbol)
        .subscribe(
          data => {
            this.stock = data;
            this.eventBus.emit(new EventData(event.eventCallBack, this.stock));
          },
          err => {
            this.stock = {};
            this.eventBus.emit(new EventData(event.eventCallBack, this.stock, null, false, err.message));
          }
        );
    });
  }


  ngOnDestroy() {
    this.subscribition.unsubscribe();
  }



  public getCompanyName() {
    if (!this.stock)
      return '';

    if (this.utilService.getCurrentLang() == 'ar') {
      return this.stock.secArName;
    } else
      return this.stock.secEnName;
  }



}
