import { Component, Input, OnInit } from '@angular/core';
import { PortfolioDetails } from './../../../../../core/models/models';

@Component({
  selector: 'app-portfolio-stock-detail',
  templateUrl: './portfolio-stock-detail.component.html',
  styleUrls: []
})
export class PortfolioStockDetailComponent implements OnInit {

  pageConfig = {
    itemsPerPage: 3,
    currentPage: 1,
    totalItems: 0
  };

  portfolio: PortfolioDetails = {};

  @Input('portfolio')
  set portfolioDetails(portfolio: PortfolioDetails) {
    if (portfolio?.tradeSecList) {
      this.pageConfig.totalItems = portfolio?.tradeSecList.length;
      this.portfolio = portfolio;
    } else {
      this.portfolio.tradeSecList = [];
    }
  }


  constructor() { }

  ngOnInit(): void {

  }

  /**
   * Change page event ,get next elements
   */
  pageChanged(event) {
    this.pageConfig.currentPage = event;
  }


}
