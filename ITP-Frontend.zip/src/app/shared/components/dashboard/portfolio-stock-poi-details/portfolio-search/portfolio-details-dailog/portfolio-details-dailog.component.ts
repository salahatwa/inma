import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { finalize } from 'rxjs/operators';
import { OrderList, PortfolioDetails } from './../../../../../../core/models/models';
import { PortfolioService } from './../../../../../../core/services/api';
import { AlertService } from './../../../../../../shared/components/alert/alert.service';
import { Constant } from './../../../../../../shared/utils/constant';

@Component({
  selector: 'app-portfolio-details-dailog',
  templateUrl: './portfolio-details-dailog.component.html',
  styleUrls: ['./portfolio-details-dailog.component.scss']
})

export class PortfolioDetailsDailogComponent implements OnInit {
  alertId = { id: 'portfolio-dialog-alert' };
  isLoading: boolean = false;
  pageConfig = {
    itemsPerPage: 3,
    currentPage: 1,
    totalItems: 0,
    id: 'page-1-unique'
  };;

  portfolioDialogSearch: FormGroup;

  orderList: OrderList = {};

  @Input() portfolio: PortfolioDetails;

  constructor(private formBuilder: FormBuilder, private portfolioService: PortfolioService,
    private translateService: TranslateService, private notifyService: AlertService,
    public activeModal: NgbActiveModal
  ) {
    
  }

  ngOnInit(): void {
    this.setPortfolioForOutstandingOrder(this.portfolio);

    this.portfolioDialogSearch = this.formBuilder.group({
      portfolioNumber: ['', [Validators.required]]
    });

    this.pageConfig.totalItems = this.portfolio?.tradeSecList?.length;

  }


  getPortfolioDetails() {
    this.isLoading = true;
    this.portfolioService.getPortfolioDetailsByPortfolioNumber(this.portfolioDialogSearch.get('portfolioNumber').value)
      .pipe(finalize(() => {
        this.isLoading = false;
      }))
      .subscribe(
        data => {
          let msgBody = this.translateService.instant('notify.getPortfolioDetails');
          this.notifyService.success(msgBody, this.alertId);
          this.portfolio = data;
          this.pageConfig.totalItems = this.portfolio.tradeSecList.length;
          this.setPortfolioForOutstandingOrder(this.portfolio);
        },
        err => {
          this.notifyService.error(err.message, this.alertId);
          this.portfolio = undefined;
        }
      );
  }


  /**
     * Change page event ,get next elements
     */
  pageChanged(event) {
    this.pageConfig.currentPage = event;
  }

  OnClear() {
    this.portfolioDialogSearch.reset();
  }

  /**
   * Setting PortfolioNum to search search button on outstanding order
   * to enable user getting outstanding order for selected portfolio
   */
  setPortfolioForOutstandingOrder(portfolioDetails: PortfolioDetails) {
    this.orderList.portfolioNum = portfolioDetails.portfolioNum;
    this.orderList.matchedRecs=0;
    this.orderList.ordersDetailsList=[];
    this.orderList.listType=Constant.OUTSTANDING_ORDERS_LIST;
  }

}
