import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { finalize } from 'rxjs/operators';
import { AlertService } from '../../../alert/alert.service';
import { OrderDetails, PortfolioDetails } from './../../../../../core/models/models';
import { PortfolioService } from './../../../../../core/services/api';
import { EventBusService } from './../../../../../core/services/event-bus.service';
import { PortfolioDetailsDailogComponent } from './portfolio-details-dailog/portfolio-details-dailog.component';

@Component({
  selector: 'app-portfolio-search',
  templateUrl: './portfolio-search.component.html',
  styleUrls: []
})
export class PortfolioSearchComponent implements OnInit {

  pageConfig = {
    itemsPerPage: 3,
    currentPage: 1,
    totalItems: 0
  };

  isLoading: boolean = false;

  portfolios: PortfolioDetails[] = [];
  searchPortfoliosForm: FormGroup;
  enableValidation = false;
  outstandingOrders: OrderDetails[];

  portfolio: PortfolioDetails;

  @Input('portfolio')
  set portfolioDetails(portfolio: PortfolioDetails) {
    this.portfolio = portfolio;
    if (this.portfolio?.poiNum && this.searchPortfoliosForm) {
      this.poiNumber.reset();
      this.poiNumber.setValue(this.portfolio?.poiNum);
    }
    else
      this.initForm();

    this.portfolios = [];
  }



  constructor(private formBuilder: FormBuilder, private portfolioService: PortfolioService,
    private notifyService: AlertService, private translateService: TranslateService, private eventBus: EventBusService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.initForm();
  }


  initForm() {
    this.searchPortfoliosForm = this.formBuilder.group({
      poiNumber: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]]
    });
  }

  get poiNumber() { return this.searchPortfoliosForm.get('poiNumber'); }

  getPortfoliosByPOI(poi: string) {
    this.enableValidation = true;
    if (this.searchPortfoliosForm.invalid) {
      return;
    }

    this.isLoading = true;
    this.portfolioService.getAllPortfolios(poi).pipe(finalize(() => {
      this.poiNumber.enable();
      this.enableValidation = false;
      this.isLoading = false;
    })).subscribe(
      data => {
        this.portfolios = data;
        this.pageConfig.totalItems = this.portfolios.length;
        let msgBody = this.translateService.instant('notify.getAllPortfoliosByPOI');
        this.notifyService.success(msgBody, { id: 'portfolio-search-alert' });
      },
      err => {
        this.notifyService.error(err.message, { id: 'portfolio-search-alert' });
      }

    );


  }

  /**
   * Change page event ,get next elements
   */
  pageChanged(event) {
    this.pageConfig.currentPage = event;
  }

  openPortfolioDetailsDialog(portolioNum: string) {
    this.isLoading = true;
    this.portfolioService.getPortfolioDetailsByPortfolioNumber(portolioNum).pipe(finalize(() => {
      this.isLoading = false;
    })).subscribe(
      data => {
        this.openDialog(data);
      },
      err => {
        this.notifyService.error(err.message, { id: 'portfolio-search-alert' });
      }
    );

  }

  openDialog(portfilioDetails: any): void {
    const dialogRef = this.modalService.open(PortfolioDetailsDailogComponent, { scrollable: true ,size: 'xl'});
    dialogRef.componentInstance.portfolio = portfilioDetails;
    dialogRef.result.then(res => {

    }).catch((res) => {
          
    });
  }


}
