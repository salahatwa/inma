import { Component, Input, OnInit } from '@angular/core';
import { EventData, PortfolioDetails } from './../../../../core/models/models';
import { PortfolioService } from './../../../../core/services/api';
import { EventBusService } from './../../../../core/services/event-bus.service';

@Component({
  selector: 'app-portfolio-stock-poi-details',
  templateUrl: './portfolio-stock-poi-details.component.html',
  styleUrls: []
})
export class PortfolioStockPoiDetailsComponent implements OnInit {

  @Input() showPoi: boolean;
  @Input() event: string;

  portfolio: PortfolioDetails;

  constructor(private eventBus: EventBusService, private portfolioService: PortfolioService) { }

  ngOnInit(): void {
    this.addPortfolioListenerEvent();
  }

  addPortfolioListenerEvent() {
    this.eventBus.on(this.event, (event: EventData) => {

      if (event.value === undefined || event.value === null) {
        this.portfolio = {};
        return;
      }

      let symbol: string = event.value.symbol;
      let portfolioNum: string = event.value.portfolioNum;


      this.portfolioService.getPortfolioDetails(symbol, portfolioNum)
        .subscribe(
          data => {
            this.portfolio = data;
            this.eventBus.emit(new EventData(event.eventCallBack, this.portfolio));

            /**
             * send portfolio num to order list component to display search button
             *  search button to get outstanding orders for this portfolioNum
             * */
            // this.orderListEvent.emit({
            //   portfolioNum: this.portfolioDetails.portfolioNum,
            //   ordersDetailsList: []
            // });
          },
          err => {
            this.eventBus.emit(new EventData(event.eventCallBack, this.portfolio, null, false, err.message));
          }
        );
    });
  }

}
