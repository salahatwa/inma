import { Component, Input, OnInit } from '@angular/core';
import { PortfolioDetails } from './../../../../../core/models/models';
import { PortfolioService } from './../../../../../core/services/api';
import { EventBusService } from './../../../../../core/services/event-bus.service';
@Component({
  selector: 'app-portfolio-detail',
  templateUrl: './portfolio-detail.component.html',
  styleUrls: []
})
export class PortfolioDetailComponent implements OnInit {

  portfolio: PortfolioDetails;

  @Input() event: string;

  @Input('portfolio')
  set portfolioDetails(portfolio: PortfolioDetails) {
    this.portfolio = portfolio;
  }

  constructor(private eventBus: EventBusService, private portfolioService: PortfolioService) { }

  // this.eventBus.on(this.event, (event: EventData) => {});
  ngOnInit(): void {
    // this.eventBus.on(this.event, (event: EventData) => {

    //   if (event.value === undefined|| event.value === null ) {
    //     this.portfolio = {};
    //     return;
    //   }
      
    //   let symbol: string = event.value.symbol;
    //   let portfolioNum: string = event.value.portfolioNum;
      

      // this.portfolioService.getPortfolioDetails(symbol, portfolioNum)
      //   .subscribe(
      //     data => {
      //       this.portfolio = data;
      //       this.eventBus.emit(new EventData(event.eventCallBack, this.portfolio));

      //     },
      //     err => {
      //       this.eventBus.emit(new EventData(event.eventCallBack, this.portfolio, null, false, err.message));
      //     }
      //   );


    // });



  }


}
