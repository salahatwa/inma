import { Component, Input, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommissionRequest, CommissionResponse, EventData } from '../../../../core/models/models';
import { OrderService } from './../../../../core/services/api';
import { EventBusService } from './../../../../core/services/event-bus.service';

@Component({
  selector: 'app-commission-detail',
  templateUrl: './commission-detail.component.html',
  styleUrls: []
})
export class CommissionDetailComponent implements OnInit {

  commission: CommissionResponse;

  subscribition: Subscription;

  @Input() event: string;

  @Input('commission')
  set commissionDetails(commission: CommissionResponse) {
    this.commission = commission;
  }

  constructor(private orderService: OrderService, private eventBus: EventBusService) { }

  ngOnInit(): void {
    this.addCommissionListener();
  }

  addCommissionListener() {

    this.subscribition = this.eventBus.on(this.event, (event: EventData) => {

      if (event.value === undefined || event.value === null) {
        this.commissionDetails = {};
        return;
      }

      let commReq: CommissionRequest = event.value;

      this.orderService.getCommissionDetails(commReq)
        .subscribe(
          data => {
            this.commissionDetails = data;
            this.eventBus.emit(new EventData(event.eventCallBack, this.commissionDetails));
          },
          err => {
            this.commissionDetails = {};
            this.eventBus.emit(new EventData(event.eventCallBack, this.commissionDetails, null, false, err.message));
          }
        );
    });

  }

}
