import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { OrderRequest } from './../../../../../core/models/models';
import { Constant } from './../../../../../shared/utils/constant';

@Component({
  selector: 'app-confirm-order-dialog',
  templateUrl: './confirm-order-dialog.component.html'
})
export class ConfirmOrderDialogComponent implements OnInit {

  tifTypeValues: any;
  confirmBtnLabelKey: string;
  cancelBtnLabelKey: string;
  alertMsgKey: string;
  title: string;
  isCancelOrderAction: boolean;

  @Input() order: OrderRequest;

  constructor(public activeModal: NgbActiveModal) { }




  ngOnInit(): void {
    this.isCancelOrderAction = this.order.action === Constant.CANCEL_ORDER_ACTION;
    this.confirmBtnLabelKey = this.isCancelOrderAction ? 'orderCancel.confirm' : 'enter_order.dialog.confirmBtn';
    this.cancelBtnLabelKey = this.isCancelOrderAction ? 'orderCancel.close' : 'enter_order.dialog.closeBtn';
    this.title = this.isCancelOrderAction ? 'orderCancel.title' : 'enter_order.dialog.title';
    this.alertMsgKey = this.isCancelOrderAction ? 'enter_order.dialog.cancelAlert' : 'enter_order.dialog.alert';

    if (this.order.orderType == '1') {
      this.tifTypeValues = Constant.tifTypeMPrice;
    } else {
      this.tifTypeValues = Constant.tifTypeLPrice;
    }
  }

}
