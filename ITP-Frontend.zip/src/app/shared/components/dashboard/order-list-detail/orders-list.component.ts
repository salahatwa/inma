import { Component, Input, OnInit } from '@angular/core';
import { NgbDropdownConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { finalize } from 'rxjs/operators';
import { OrderInquiryRequest, OrderInquiryResponse, OrderRequest } from '../../../../core/models/models';
import { OrderDetails, OrderList } from '../../../../core/models/OrderDetails';
import { OrderService } from '../../../../core/services/api';
import { Constant } from '../../../utils/constant';
import { AlertService } from '../../alert/alert.service';
import { ConfirmOrderDialogComponent } from '../app-dialogs/confirm-order-dialog/confirm-order-dialog.component';
import { UtilsService } from './../../../../shared/services/utils.service';
import { OrderExportDialogComponent } from './order-export/order-export-dialog.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { OrderSummaryComponent } from './order-summary/order-summary.component';
import { OrderUpdateDialogComponent } from './order-update/order-update-dialog.component';

@Component({
  selector: 'app-orders-list',
  templateUrl: './orders-list.component.html',
  styleUrls: ['./orders-list.component.scss'],
  providers: [NgbDropdownConfig]
})
export class OrdersListComponent implements OnInit {

  pageConfig = {
    itemsPerPage: Constant.PAGINATION_MAX_RECS,
    currentPage: 1,
    totalItems: 0
  };

  listTitle: string;

  /**
   * this Object contain OrderDetails List and PortfolioNumber
   * If PortfolioNumber found it will display search button to get outstanding order
   */
  orderList: OrderList = {};


  /**
   * for highlighted current selected order
   */
  currentOrder: OrderDetails;

  selectOrder($event, order) {
    this.currentOrder = order;
  }

  @Input('ordersList')
  set orderListData(orderList: OrderList) {
    this.orderList = orderList;
    this.pageConfig.totalItems = (orderList?.matchedRecs) ? orderList.matchedRecs : 0;
  }




  @Input()
  orderInquiryRequest: OrderInquiryRequest = {
    recCtrlIn: {
      maxRecs: Constant.PAGINATION_MAX_RECS,
      offset: 0
    }
  };

  isLoading: boolean = false;
  alertId = { id: 'order-list-alert' + Math.random().toString(36).substring(2) };


  constructor(config: NgbDropdownConfig, private modalService: NgbModal, private orderService: OrderService, private notifyService: AlertService, private translateService: TranslateService, private utilsService: UtilsService) {
    // customize default values of dropdowns used by this component tree
    if (this.utilsService.getCurrentLang() === 'ar')
      config.placement = 'left-top';
    else
      config.placement = 'right-top'
    //  config.autoClose = false;
  }

  ngOnInit(): void {
    if (this.orderList.listType == Constant.ORDER_TRADES_LIST) {
      this.listTitle = "orderSearch.listTitle";
    } else {
      this.listTitle = "oustandingOrders.title";
    }
  }

  /**
   * Get outstanding order paginate server side
   */
  getOutstandingOrders() {

    if (!this.orderList?.portfolioNum || this.orderList?.portfolioNum == '' || this.orderList?.portfolioNum == 'undefined')
      return;

    this.orderList.ordersDetailsList = [];
    this.isLoading = true;
    this.orderInquiryRequest.portfolioNum = this.orderList.portfolioNum;

    this.orderService.getOutstandingOrders(this.orderInquiryRequest).pipe(finalize(() => {
      this.isLoading = false;
    })).subscribe(
      data => {
        this.pageConfig.totalItems = data.recCtrlOut.matchedRecs;
        this.orderList.ordersDetailsList = data.ordersList;
        let msgBody = this.translateService.instant('notify.getOutstandingOrder');
        this.notifyService.success(msgBody, this.alertId);
      },
      err => {
        this.notifyService.error(err.message, this.alertId);
      }
    );

  }

  /**
   * Update Order status
   * @param order 
   * @param index 
   */
  getLatestOrderStatus(order: OrderDetails, index: number) {
    this.isLoading = true;
    this.orderService.getOrderStatus(order.omsRefNum).pipe(finalize(() => {
      this.isLoading = false;
    })).subscribe(
      data => {
        this.orderList.ordersDetailsList[index] = data;
        this.notifyService.success(this.translateService.instant('notify.ordStatusUpdate', { ordRefNum: data.omsRefNum }), this.alertId);
      },
      err => {
        this.notifyService.error(err.message, this.alertId);
      }
    );
  }

  openOrderSummaryDialog(portfolioNum: string, omsRefNo: string): void {
    let orderSummary: OrderDetails;
    this.orderService.getOrderDetails(portfolioNum, omsRefNo).subscribe(data => {
      orderSummary = data;
      orderSummary.portfolioNum = portfolioNum;
      orderSummary.omsRefNum = omsRefNo;


      const dialogRef = this.modalService.open(OrderSummaryComponent, { scrollable: true, size: 'xl' });
      dialogRef.componentInstance.order = orderSummary;
      dialogRef.result.then(res => {

      }).catch((res) => {

      });

    },
      err => {
        this.notifyService.error(err.message, this.alertId);
      });

  }

  openOrderCancelConfirmDialog(order: OrderDetails, index: number): void {

    let req: OrderRequest = {
      stockSymbol: order?.symbol,
      portfolioNum: order?.portfolioNum,
      orderSide: order?.ordSide,
      orderType: order?.ordType,
      unitPrice: this.utilsService.toNumber(order?.curAmt?.amt),
      orderQty: this.utilsService.toNumber(order?.ordQty),
      tifType: this.utilsService.toNumber(order?.tifType),
      expDt: order?.expDt,
      minFillQty: this.utilsService.toNumber(order.minFillQty),
      action: Constant.CANCEL_ORDER_ACTION,
      omsRefNum: order?.omsRefNum
    }
    const dialogRef = this.modalService.open(ConfirmOrderDialogComponent, { scrollable: true, size: 'lg' });
    dialogRef.componentInstance.order = req;
    dialogRef.result.then(result => {
      if (result) {
        this.isLoading = true;
        this.orderService.cancelOrder(order.portfolioNum, order.omsRefNum)
          .pipe(finalize(() => { this.isLoading = false; }))
          .subscribe(
            data => {
              this.notifyService.success(this.translateService.instant('notify.orderCancel', { ordRefNum: order.omsRefNum }), this.alertId);
              this.currentOrder = data;
              this.orderList.ordersDetailsList[index] = data;
            },
            err => {
              this.notifyService.error(err.message, this.alertId);
            }
          );
      }
    }).catch((res) => {

    });

  }


  openOrderUpdateDialog(order: OrderDetails, index: number): void {
    const dialogRef = this.modalService.open(OrderUpdateDialogComponent, { scrollable: true, size: 'xl' });
    dialogRef.componentInstance.order = order;
    dialogRef.result.then(res => {
      if (res) {
        this.orderList.ordersDetailsList[index] = res;
      }
    }).catch((res) => {
    });
  }

  /**
     * Change page event ,get next elements
    */
  pageChanged(event) {
    this.isLoading = true;
    this.pageConfig.currentPage = event;
    this.orderInquiryRequest.recCtrlIn.offset = (event - 1) * Constant.PAGINATION_MAX_RECS;
    // call server side
    if (this.orderList.listType == Constant.ORDER_TRADES_LIST) {
      this.orderService.inquireOrders(this.orderInquiryRequest).pipe(
        finalize(() => {
          this.isLoading = false;
        })
      ).subscribe(
        data => {
          let inquiryResponse: OrderInquiryResponse = data;
          this.orderList.ordersDetailsList = inquiryResponse.ordersList;
          this.pageConfig.totalItems = inquiryResponse.recCtrlOut.matchedRecs;
        },
        err => {
          console.log(err);
        }
      );
    } else {
      this.getOutstandingOrders();
    }
  }

  /**
   * this method hide / show UPDATE or Cancel button depend on order status
   * 
   * @param operationName 
   * @param order 
   */
  isOperationAllowed(operationName: String, order: OrderDetails): boolean {
    if ((!order?.mrktAuthrzd || order.mrktAuthrzd != 'Y')&&operationName!='STATUS')
      return false;

    switch (operationName) {
      case 'UPDATE':
        return !Constant.N_ALLOWED_OPT_ORD_STATUS.includes(order.ordStatus);
      case 'CANCEL':
        return !Constant.N_ALLOWED_OPT_ORD_STATUS.includes(order.ordStatus);
      case 'STATUS':
        return !Constant.N_ALLOWED_OPT_ORD_STATUS_UPDATE.includes(order.ordStatus);
    }
  }

  /**
   * Display order expiry date column depend on orderTifType
   * @param order
   */
  getOrderExpDate(order: OrderDetails): string {
    let tifTypeValues = [];
    if (order.ordType == Constant.MARKET_PRICE)
      tifTypeValues = Constant.tifTypeMPrice;
    else
      tifTypeValues = Constant.tifTypeLPrice;

    if (order.tifType == Constant.CUSTOM_DATE)
      return order.expDt;
    else {
      let data = tifTypeValues.filter(tifType => tifType.value === order.tifType)[0];
      if (data)
        return this.translateService.instant(tifTypeValues.filter(tifType => tifType.value === order.tifType)[0]?.key);
    }
  }

  openOrderExportDialog(order: OrderDetails) {
    const dialogRef = this.modalService.open(OrderExportDialogComponent, { scrollable: true, size: 'xl' });
    dialogRef.componentInstance.order = order;
    dialogRef.result.then(res => {

    }).catch((res) => {

    });
  }

  openOrderHistoryDialog(omsRefNum: string): void {
    let orderHistoryList: OrderDetails[];
    this.orderService.getOrderHistory(omsRefNum).subscribe(data => {
      orderHistoryList = data;
      const dialogRef = this.modalService.open(OrderHistoryComponent, { scrollable: true, size: 'xl' });
      dialogRef.componentInstance.orderHistoryList = orderHistoryList;
      dialogRef.componentInstance.omsRefNum = omsRefNum;

      dialogRef.result.then(res => {

      }).catch((res) => {

      });

    },
      err => {
        this.notifyService.error(err.message, this.alertId);
      });

  }
}
