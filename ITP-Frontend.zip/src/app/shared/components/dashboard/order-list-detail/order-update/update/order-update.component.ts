import { DatePipe } from '@angular/common';
import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { ConfirmOrderDialogComponent } from '../../../app-dialogs/confirm-order-dialog/confirm-order-dialog.component';
import { CommissionRequest, CommissionResponse, EventData, Events, OrderRequest, PortfolioDetails, StockDetails } from './../../../../../../core/models/models';
import { OrderDetails } from './../../../../../../core/models/OrderDetails';
import { OrderService } from './../../../../../../core/services/api';
import { EventBusService } from './../../../../../../core/services/event-bus.service';
import { AlertService } from './../../../../../../shared/components/alert/alert.service';
import { UtilsService } from './../../../../../../shared/services/utils.service';
import { Constant } from './../../../../../../shared/utils/constant';
import { dateConditionallyRequiredValidator, priceConditionallyRequiredValidator, quanityValidator, tickSize } from './../../../../../../shared/utils/validator';


@Component({
  selector: 'app-order-update',
  templateUrl: './order-update.component.html'
})
export class OrderUpdateComponent implements OnInit, AfterViewInit {

  order: OrderDetails;
  @Input('order')
  set initForm(value: OrderDetails) {
    this.order = value;
    this.initOrderForm(this.order);
  }
  // Mask expression to restric user to enter valid date format
  maskDate = Constant.DATE_REGEX;
  maskNum = Constant.NUMBER_REGEX;
  alertId = { id: 'update-order-alert' }


  isLoading = false;//hold action for any events on enter order component
  updateForm: FormGroup;
  stockDetails: StockDetails;
  commissionDetails: CommissionResponse;
  portfolioDetails: PortfolioDetails;
  minPriceValue: any = Constant.MIN_PRICE_VALUE;
  maxPriceValue: any = Constant.MAX_PRICE_VALUE;
  selectedOrderSide: string = Constant.BUY;
  selectedOrderType: string = Constant.LIMIT_PRICE;
  selectedTifType: string = Constant.TODAY_ONLY;
  tifTypeValues: any;
  orderDateTValue;

  @ViewChild("orderPrice") orderPriceField: ElementRef;
  @ViewChild("orderQty") orderQtyField: ElementRef;
  @ViewChild("orderTifType") orderTifTypeField: ElementRef;
  @ViewChild("orderDate") orderDateField: ElementRef;
  @ViewChild("orderDeclarQty") orderDeclarQtyField: ElementRef;
  @ViewChild("orderSubmit") orderSubmitBtn: ElementRef;

  /**
   * Declaring events that sent output to child components
   */
  @Output() orderEvent = new EventEmitter<OrderDetails>();

  stockSubscribition: Subscription;
  portfolioSubscribition: Subscription;
  commissionSubscribition: Subscription;
  constructor(protected alertService: AlertService, private formBuilder: FormBuilder, private modalService: NgbModal, private eventBus: EventBusService,
    private translateService: TranslateService, private utilService: UtilsService,
    private orderService: OrderService, private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.addGetStockDetailsListener();
    this.addGetPortfolioDetailsListener();
    this.addCommissionDetailsListener();
    // this.addFocusAndValidations();
  }


  ngOnDestroy() {
    this.stockSubscribition.unsubscribe();
    this.portfolioSubscribition.unsubscribe();
    this.commissionSubscribition.unsubscribe();
  }

  /**
  * Listen to call back events from stock details component
 */
  addGetStockDetailsListener() {
    this.stockSubscribition = this.eventBus.on(Events.GET_STOCK_DETAILS_UPDATE_ORDER_CALLBACK, (result: EventData) => {
      this.isLoading = false;
      if (!result.success) {
        this.stockDetails = {};
        this.alertService.error(result.errMsg, this.alertId);
        return;
      }
      this.alertService.success(this.translateService.instant('notify.getStockDetails'), this.alertId);
      this.stockDetails = result.value;
      this.addPriceValidations();
    });
  }

  /**
     * Listen to call back events from portfolio details component
    */
  addGetPortfolioDetailsListener() {
    this.portfolioSubscribition = this.eventBus.on(Events.GET_PORTFOLIO_DETAILS_UPDATE_ORDER_CALLBACK, (result: EventData) => {
      this.isLoading = false;
      if (!result.success) {
        this.portfolioDetails = {};
        this.alertService.error(result.errMsg, this.alertId);
        return;
      }

      this.alertService.success(this.translateService.instant('notify.getPortfolioDetails'), this.alertId);
      this.portfolioDetails = result.value;
    });
  }



  /**
     * Listen to call back events from portfolio details component
    */
  addCommissionDetailsListener() {
    this.commissionSubscribition = this.eventBus.on(Events.GET_COMMISSION_DETAILS_UPDATE_ORDER_CALLBACK, (result: EventData) => {
      this.isLoading = false;
      this.utilService.enableFormField(this.updateForm, 'orderQty');
      if (!result.success) {
        this.orderQtyField.nativeElement.blur();
        this.orderQtyField.nativeElement.focus();
        this.commissionDetails = {};
        this.alertService.error(result.errMsg, this.alertId);
        return;
      }

      this.alertService.success(this.translateService.instant('notify.getCommissionDetails'), this.alertId);
      this.commissionDetails = result.value;
      this.orderTifTypeField.nativeElement.focus();
    });
  }

  ngAfterViewInit() {
    this.getStockDetail(this.order.symbol);
    this.getPortfolioDetail(this.order.portfolioNum, this.order.symbol);
    this.getCommissionWithoutValidations(+this.order.ordQty)
    this.addFocusAndValidations();
  }


  /**
   * Reset  Commission details on typing evenr
   */
  onOrderQtyValueChange() {
    this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_UPDATE_ORDER));
    this.commissionDetails = {};
  }


  /**
   * Confirm order dialog summary
   */
  confirmOrderDialog() {

    if (this.selectedOrderSide == Constant.BUY) {
      let totalDeal: number = +this.commissionDetails?.totTradeAmt;
      let buyinPower: number = +this.portfolioDetails?.buyingPwr;
      if (buyinPower < totalDeal) {
        this.alertService.error(this.translateService.instant('enter_order.validations.buyPower'), this.alertId);
        return;
      }
    }

    let req: OrderRequest = {
      omsRefNum: this.order.omsRefNum,
      stockSymbol: this.updateForm.get('stockSymbol').value,
      portfolioNum: this.updateForm.get('portfolioNum').value,
      orderSide: this.updateForm.get('orderSide').value,
      orderType: this.updateForm.get('orderType').value,
      unitPrice: this.updateForm.get('orderPrice').value,
      orderQty: this.updateForm.get('orderQty').value,
      tifType: this.updateForm.get('orderTifType').value,
      expDt: this.updateForm.get('orderDate').value,
      minFillQty: this.updateForm.get('orderDeclarQty').value,
      action: Constant.UPDATE_ORDER_ACTION
    }

    const dialogRef = this.modalService.open(ConfirmOrderDialogComponent, { scrollable: true, size: 'lg' });
    dialogRef.componentInstance.order = req;

    dialogRef.result.then(result => {
      if (result) {
        this.isLoading = true;
        this.orderService.updateOrder(result)
          .pipe(finalize(() => {
            this.isLoading = false;
          })
          ).subscribe(
            data => {
              this.alertService.success(this.translateService.instant('notify.ordUpdated', { ordRefNum: data.omsRefNum }), this.alertId);

              this.order = data;
              if (this.order.tifType == Constant.CUSTOM_DATE)
                this.order.expDt = this.datePipe.transform(this.order.expDt, 'yyyy-MM-dd');
              this.orderEvent.emit(this.order);

            },
            err => {
              this.alertService.error(err.message, this.alertId);
            }
          );
      }
    }).catch((res) => {

    });

  }

  getOrderPriceNextElm() {
    let priceControl = this.updateForm.controls['orderPrice'];
    priceControl.updateValueAndValidity();
    if (priceControl.errors) {
      this.orderPriceField.nativeElement.blur();
      this.orderPriceField.nativeElement.focus();
    } else {
      this.orderQtyField.nativeElement.focus();
    }
  }

  getTifTypeNextElm(event: any) {
    event.preventDefault();

    if (this.selectedTifType == Constant.CUSTOM_DATE) {
      this.orderDateField.nativeElement.blur();
      this.orderDateField.nativeElement.focus();
    }
    else
      this.orderDeclarQtyField.nativeElement.focus();

  }


  getOrderDateNextElm(event: any) {
    let ordDateControl = this.updateForm.get('orderDate');
    if (ordDateControl.value && ordDateControl.valid) {
      event.preventDefault();
      this.orderDeclarQtyField.nativeElement.focus();

    } else {
      this.orderDateField.nativeElement.blur();
      this.orderDateField.nativeElement.focus();
    }
  }

  getOrderDeclarQtyNextElm() {
    event.preventDefault();
    this.orderSubmitBtn.nativeElement.focus();
  }



  /**
  * fire get stock details
  * @param symbol 
  */
  getStockDetail(symbol: string) {
    this.isLoading = true;
    this.eventBus.emit(new EventData(Events.GET_STOCK_DETAILS_UPDATE_ORDER, symbol, Events.GET_STOCK_DETAILS_UPDATE_ORDER_CALLBACK));
  }

  getPortfolioDetail(portfolioNum: string, symbol: string) {
    this.isLoading = true;
    this.eventBus.emit(new EventData(Events.GET_PORTFOLIO_DETAILS_UPDATE_ORDER, { symbol: symbol, portfolioNum: portfolioNum }, Events.GET_PORTFOLIO_DETAILS_UPDATE_ORDER_CALLBACK));
  }

  /**
   * Get commission details when click enter on Qty Field
   * @param qty 
   */
  getCommissionDetail(qty: number) {
    if (qty && qty > 0) {
      //Validate price in case of Limit price
      if (this.selectedOrderType == Constant.LIMIT_PRICE) {
        let ordPriceControl = this.updateForm.get('orderPrice');

        if (ordPriceControl.errors) {
          this.orderPriceField.nativeElement.blur();
          this.orderPriceField.nativeElement.focus();
          return;
        }

      }

      this.updateForm.controls['orderQty'].updateValueAndValidity();

      if (this.updateForm.get('orderQty').errors) {
        this.orderQtyField.nativeElement.blur();
        this.orderQtyField.nativeElement.focus();
        return;
      }
      this.getCommissionWithoutValidations(qty);
    } else {
      this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_UPDATE_ORDER));
      this.orderQtyField.nativeElement.blur();
      this.orderQtyField.nativeElement.focus();
    }

  }

  getCommissionWithoutValidations(qty: number) {
    let commReq: CommissionRequest = {
      orderQty: qty,
      stockSymbol: this.updateForm.get('stockSymbol').value,
      portfolioNum: this.updateForm.get('portfolioNum').value,
      orderSide: this.updateForm.get('orderSide').value,
      orderType: this.updateForm.get('orderType').value,
      unitPrice: this.updateForm.get('orderPrice').value
    }

    if (commReq.stockSymbol == 'undefined' || commReq.stockSymbol == '' || commReq.stockSymbol == null) {
      this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_UPDATE_ORDER));
      new EventData(Events.GET_STOCK_DETAILS_UPDATE_ORDER, {})
      this.stockDetails = {};
      return;
    }

    if (commReq.portfolioNum == 'undefined' || commReq.portfolioNum == '' || commReq.portfolioNum == null) {
      this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_UPDATE_ORDER));
      return;
    }

    this.isLoading = true;
    this.utilService.disableFormField(this.updateForm, 'orderQty');
    this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_UPDATE_ORDER, commReq, Events.GET_COMMISSION_DETAILS_UPDATE_ORDER_CALLBACK));
  }
  /**
   * 
   * @param event Clear form value
   */
  clear() {
    this.updateForm.reset();
    this.initOrderForm(this.order);
    this.addFocusAndValidations();
    // this.getStockDetail(this.order.symbol);
    // this.getCommissionDetail(+this.order.ordQty);
    // this.getPortfolioDetail(this.order.portfolioNum, this.order.symbol);
  }

  addQtyValidations() {
    this.updateForm.controls['orderQty'].clearValidators();
    this.updateForm.controls['orderQty'].setValidators([Validators.required,
    (control: AbstractControl) => quanityValidator(+this.portfolioDetails?.tradeSecList[0]?.ownedQuantity)(control)]);
    this.updateForm.controls['orderQty'].updateValueAndValidity();
  }

  /**
   * Initialize order form default values , validations
   */
  initOrderForm(order: OrderDetails) {
    /**
       * Intialize TifType List depend on OrderType
       */
    this.selectedTifType = order.tifType;
    this.selectedOrderType = order.ordType;
    this.selectedOrderSide = order.ordSide;
    if (this.selectedOrderType == Constant.MARKET_PRICE)
      this.tifTypeValues = Constant.tifTypeMPrice;
    else
      this.tifTypeValues = Constant.tifTypeLPrice;

    this.updateForm = this.formBuilder.group({
      stockSymbol: [{ value: order.symbol, disabled: true }, [Validators.required]],
      orderSide: [{ value: this.selectedOrderSide, disabled: true }, Validators.required],
      portfolioNum: [{ value: order.portfolioNum, disabled: true }, [Validators.required]],
      orderType: [{ value: this.selectedOrderType, disabled: true }, Validators.required],
      orderPrice: [{ value: order.mrktPrice, disabled: this.selectedOrderType == Constant.MARKET_PRICE }, [
        priceConditionallyRequiredValidator,
        (control: AbstractControl) => Validators.max(this.maxPriceValue)(control),
        (control: AbstractControl) => Validators.min(this.minPriceValue)(control)
        , tickSize]],
      orderQty: [+order.ordQty, [Validators.required,
      (control: AbstractControl) => quanityValidator((this.portfolioDetails?.tradeSecList && this.portfolioDetails?.tradeSecList[0] && this.portfolioDetails?.tradeSecList[0]?.ownedQuantity) ? (+this.portfolioDetails?.tradeSecList[0].ownedQuantity) : 0)(control)]],
      orderTifType: [this.selectedTifType, Validators.required],
      orderDate: [{ value: this.selectedTifType == Constant.CUSTOM_DATE ? order.expDt : '', disabled: this.selectedTifType != Constant.CUSTOM_DATE }, [dateConditionallyRequiredValidator,
        Validators.pattern(Constant.DatePattern),
      ]],
      orderDeclarQty: [order.maxFloor]
    });
  }

  addFocusAndValidations() {
    if (this.selectedOrderType == Constant.MARKET_PRICE) {
      this.orderQtyField.nativeElement.blur();
      this.orderQtyField.nativeElement.focus();
    }
    else {
      this.orderPriceField.nativeElement.blur();
      this.orderPriceField.nativeElement.focus();
    }

    this.addPriceValidations();
    this.updateForm.get('orderQty').updateValueAndValidity();
  }

  addPriceValidations() {
    if (this.stockDetails && this.selectedOrderSide == Constant.BUY) {
      this.maxPriceValue = this.stockDetails.maxPriceLimit;
      this.minPriceValue = 1;
    }
    else if (this.stockDetails && this.selectedOrderSide == Constant.SELL) {
      this.maxPriceValue = 1000000;
      this.minPriceValue = this.stockDetails.minPriceLimit;
    } else {
      this.minPriceValue = Constant.MIN_PRICE_VALUE;
      this.maxPriceValue = Constant.MAX_PRICE_VALUE;
    }
  }



  orderTifTypeChange(event: any) {
    this.selectedTifType = event;
    if (this.selectedTifType == Constant.CUSTOM_DATE)
    {
      this.updateForm.controls['orderDate'].setValue(this.order.expDt);
      this.updateForm.controls['orderDate'].enable();
    }
    else
    {
      this.updateForm.controls['orderDate'].setValue('');
      this.updateForm.controls['orderDate'].disable();
    }

  }

}