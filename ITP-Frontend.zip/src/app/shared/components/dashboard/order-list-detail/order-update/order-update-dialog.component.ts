import { Component, Input, OnInit } from '@angular/core';
import { OrderDetails } from './../../../../../core/models/models';
import { UtilsService } from './../../../../../shared/services/utils.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-order-update-dialog',
  templateUrl: './order-update-dialog.component.html'
})
export class OrderUpdateDialogComponent implements OnInit {

  tifTypeValues: any;

  @Input() order: OrderDetails;
  constructor(public activeModal: NgbActiveModal, public utilService: UtilsService) { }

  ngOnInit(): void {

  }


  setOrderValue(event: OrderDetails) {
    this.order = event;
    this.activeModal.close(this.order);
  }

}