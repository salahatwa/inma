import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { OrderDetails } from '../../../../../core/models/OrderDetails';
import { AlertService } from '../../../alert/alert.service';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.component.html'
})
export class OrderSummaryComponent implements OnInit {
  pageConfig = {
    itemsPerPage: 3,
    currentPage: 1,
    totalItems: 0,
    id: 'orderExecutionLitPagination' + Math.random().toString(36).substring(2)
  };
  alert = { id: 'order-summary-alert' + Math.random().toString(36).substring(2) };

  @Input() order: OrderDetails;

  constructor(public activeModal: NgbActiveModal, private notifyService: AlertService, private translateService: TranslateService) { }

  ngOnInit(): void {
    this.pageConfig.totalItems = this.order.executionInfoList ? this.order.executionInfoList.length : 0;
    let msgBody = this.translateService.instant('notify.loadOrderDetailsSuccess');
    this.notifyService.success(msgBody, this.alert);
  }
  pageChanged(event) {
    this.pageConfig.currentPage = event;
  }


}
