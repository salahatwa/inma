import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { OrderDetails } from './../../../../../core/models/models';
import { AlertService } from '../../../alert/alert.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html'
})
export class OrderHistoryComponent implements OnInit {
  pageConfig = {
    itemsPerPage: 3,
    currentPage: 1,
    totalItems: 0
  };
  alert = { id: 'order-history-alert' + Math.random().toString(36).substring(2) };

  @Input() omsRefNum:string;
  @Input() orderHistoryList: OrderDetails[];

  constructor(public activeModal: NgbActiveModal, private notifyService: AlertService, private translateService: TranslateService) {
  }

  ngOnInit(): void {
    this.pageConfig.totalItems = this.orderHistoryList?.length;
    let msgBody = this.translateService.instant('notify.loadOrderHistorySuccess');
    this.notifyService.success(msgBody, this.alert);
  }

  pageChanged(event) {
    this.pageConfig.currentPage = event;
  }

}