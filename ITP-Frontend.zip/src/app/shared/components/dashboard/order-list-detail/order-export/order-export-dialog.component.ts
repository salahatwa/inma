import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { OrderDetails } from './../../../../../core/models/models';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Constant } from './../../../../../shared/utils/constant';
import { AlertService } from '../../../alert/alert.service';
import { TranslateService } from '@ngx-translate/core';

declare var html2pdf: any;

@Component({
  selector: 'app-order-export-dialog',
  templateUrl: './order-export-dialog.component.html'
})
export class OrderExportDialogComponent implements OnInit {

  alertId = { id: 'export-order-alert' };

  @Input() order: OrderDetails;
  constructor(public activeModal: NgbActiveModal,private alertService: AlertService,private translateService:TranslateService) {
    this.addScript('https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js');
  }

  ngOnInit(): void {
  }

  addScript(url) {
    var script = document.createElement('script');
    script.type = 'application/javascript';
    script.src = url;
    document.head.appendChild(script);
  }



  public downloadPDF(): void {
    var element = document.getElementById('htmlData');
    var opt = {
      margin: 1,
      filename: 'Order_' + this.order.omsRefNum + '.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
    html2pdf(element, opt);
  }


  public copy(): void {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = Constant.clipboardMsg(this.order);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.alertService.success(this.translateService.instant('notify.copiedToCliboard'), this.alertId);
  }

}
