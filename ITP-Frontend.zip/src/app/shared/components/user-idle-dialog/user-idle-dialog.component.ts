import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Config } from '../../utils/config';

@Component({
  selector: 'app-user-idle-dialog',
  templateUrl: './user-idle-dialog.component.html'
})
export class UserIdleDialogComponent implements OnInit {

  counter = 60;
  interval = 1000;
  value = 0;

  constructor(
    public activeModal: NgbActiveModal, private config: Config) {
    this.counter = config.sessionTimeOut;
  }

  ngOnInit(): void {

  }

}
