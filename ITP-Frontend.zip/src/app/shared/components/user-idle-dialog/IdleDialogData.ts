export interface IdleDialogData {
    countDown:number;
    stayLoggedIn: boolean;
  }