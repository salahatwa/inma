
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CustomerDetails } from '../models/models';
import { ApiService } from '../../shared/services/api.service';
import { HttpParams } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private apiService: ApiService) {

  }


  /**
   * getPortfolioDetailsByStockAndPortfolioNumber
   * 
   * @param poiNum poiNum
   * @param cif cif
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getCustomerDetails(poiNum: string, cif: string): Observable<CustomerDetails> {
    let params = new HttpParams();

    if (poiNum === null || poiNum === undefined || poiNum === "") {
      params = params.append("cif", cif);
    }

    if (cif === null || cif === undefined || cif === "") {
      params = params.append("poiNumber", poiNum);
    }

    return this.apiService.get(`/customer/details`, params).pipe(map(
      data => {
        return data;
      }
    ));

  }

}