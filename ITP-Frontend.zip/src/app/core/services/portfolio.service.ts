
import { Inject, Injectable, Optional } from '@angular/core';
import {
  HttpClient, HttpHeaders, HttpParams,
  HttpResponse, HttpEvent
} from '@angular/common/http';

import { Observable, Subject } from 'rxjs';

import { PortfolioDetails } from '../models/models';
import { ApiService } from './../../shared/services/api.service';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class PortfolioService {

  constructor(private apiService: ApiService) {

  }



  /**
   * getAllPortfolioDetailsForPoiNumber
   * 
   * @param poiNumber poiNumber
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getAllPortfolios(poiNumber: string): Observable<PortfolioDetails[]> {

    if (poiNumber === null || poiNumber === undefined) {
      throw new Error('Required parameter poiNumber was null or undefined when calling getAllPortfolioDetailsForPoiNumberUsingGET.');
    }

    return this.apiService.get(`/portfolio/${encodeURIComponent(String(poiNumber))}/localPortfolios`).pipe(map(
      data => {
        return data;
      }
    ));

  }

  /**
   * getPortfolioDetailsByStockAndPortfolioNumber
   * 
   * @param portfolioNumber portfolioNumber
   * @param stockSymbol stockSymbol
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getPortfolioDetails(stockSymbol: string, portfolioNumber: string): Observable<PortfolioDetails> {

    if (portfolioNumber === null || portfolioNumber === undefined) {
      throw new Error('Required parameter portfolioNumber was null or undefined when calling getPortfolioDetailsByStockAndPortfolioNumberUsingGET.');
    }

    if (stockSymbol === null || stockSymbol === undefined) {
      throw new Error('Required parameter stockSymbol was null or undefined when calling getPortfolioDetailsByStockAndPortfolioNumberUsingGET.');
    }


    return this.apiService.get(`/portfolio/${encodeURIComponent(String(stockSymbol))}/${encodeURIComponent(String(portfolioNumber))}/details`).pipe(map(
      data => {
        return data;
      }
    ));

  }

  public getPortfolioDetailsByPortfolioNumber(portfolioNumber: string): Observable<PortfolioDetails> {

    if (portfolioNumber === null || portfolioNumber === undefined) {
      throw new Error('Required parameter portfolioNumber was null or undefined when calling getPortfolioDetailsByStockAndPortfolioNumberUsingGET.');
    }

    return this.apiService.get(`/portfolio/${encodeURIComponent(String(portfolioNumber))}/details`).pipe(map(
      data => {
        return data;
      }
    ));

  }

}