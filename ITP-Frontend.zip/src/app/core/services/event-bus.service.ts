import { Injectable } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { EventData } from '../models/event';

@Injectable({
  providedIn: 'root'
})
export class EventBusService {
  private subject$ = new Subject();
  public subjectData = this.subject$.asObservable();

  constructor() { }

  /**
   * Observer to put data into specific Observable with custom mandatory event name
   * @param event  
   */
  emit(event: EventData) {
    this.subject$.next(event);
  }

  back() {
    return this.subjectData;
  }
  /**
   * Subscriber Listener on specific event name , listen by event name and return data
   * @param eventName  
   * @param action 
   */
  on(eventName: string, action: any): Subscription {
    return this.subject$.pipe(
      filter((e: EventData) => e.event === eventName),
      map((e: EventData) => e)).subscribe(action);
  }
}
