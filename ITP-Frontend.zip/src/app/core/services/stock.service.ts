import { Inject, Injectable, Optional } from '@angular/core';

import { Observable, Subject } from 'rxjs';

import { StockDetails, EventData, Events } from '../models/models';

import { ApiService } from './../../shared/services/api.service';
import { map } from 'rxjs/operators';
import { EventBusService } from './event-bus.service';
import { Constant } from './../../shared/utils/constant';


@Injectable({
  providedIn: 'root'
})
export class StockService {


  constructor(private apiService: ApiService, private eventBus: EventBusService) {

  }



  /**
   * getStockDetails
   * 
   * @param symbol symbol
   */
  public getStockDetails(symbol: string): Observable<StockDetails> {

    if (symbol === null || symbol === undefined) {
      throw new Error('Required parameter symbol was null or undefined when calling getStockDetailsUsingGET.');
    }


    return this.apiService.get(`/stock/${encodeURIComponent(String(symbol))}/details/${encodeURIComponent('TDWL')}`).pipe(map(
      data => {
        return data;
      }
    ));
  }

}
