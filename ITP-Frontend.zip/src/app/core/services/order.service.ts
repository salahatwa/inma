import { Inject, Injectable, Optional } from '@angular/core';
import {
  HttpClient, HttpHeaders, HttpParams,
  HttpResponse, HttpEvent
} from '@angular/common/http';

import { Observable, Subject } from 'rxjs';


import { CommissionRequest, OrderInquiryRequest, OrderRequest, CommissionResponse, OrderResponse } from '../models/models';
import { ApiService } from './../../shared/services/api.service';
import { map } from 'rxjs/operators';
import { OrderDetails, OrderList } from '../models/OrderDetails';
import { OrderCancelRs } from '../models/OrderCancelRs';



@Injectable({
  providedIn: 'root'
})
export class OrderService {


  constructor(private apiService: ApiService) {

  }


  /**
   * executeOrder
   * 
   * @param ordReq ordReq
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public executeOrder(ordReq: OrderRequest): Observable<OrderDetails> {

    if (ordReq === null || ordReq === undefined) {
      throw new Error('Required parameter ordReq was null or undefined when calling executeOrderUsingPOST.');
    }

    return this.apiService.post(`/order/execute`, ordReq).pipe(map(
      data => {
        return data;
      }
    ));

  }

  /**
  * updateOrder
  * 
  * @param ordReq ordReq
  * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
  * @param reportProgress flag to report request and response progress.
  */
  public updateOrder(ordReq: OrderRequest): Observable<OrderDetails> {

    if (ordReq === null || ordReq === undefined) {
      throw new Error('Required parameter ordReq was null or undefined when calling executeOrderUsingPOST.');
    }

    return this.apiService.put(`/order/update`, ordReq).pipe(map(
      data => {
        return data;
      }
    ));

  }

  /**
   * getCommissionDetails
   * 
   * @param commReq commReq
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getCommissionDetails(commReq: CommissionRequest): Observable<any> {

    if (commReq === null || commReq === undefined) {
      throw new Error('Required parameter commReq was null or undefined when calling getCommissionDetailsUsingPOST.');
    }

    return this.apiService.post(`/order/commission/details`, commReq).pipe(map(
      data => {
        return data;
      }
    ));
  }

  /**status
   * getOrderStatus
   * 
   * @param ordRefNum ordRefNum
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public getOrderStatus(ordRefNum: string): Observable<OrderDetails> {

    if (ordRefNum === null || ordRefNum === undefined) {
      throw new Error('Required parameter ordRefNum was null or undefined when calling getOrderStatusUsingGET.');
    }

    return this.apiService.get(`/order/${encodeURIComponent(String(ordRefNum))}/status`).pipe(map(
      data => {
        return data;
      }
    ));
  }

  /**
   * inquiryOrders
   * 
   * @param inqReq inqReq
   * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
   * @param reportProgress flag to report request and response progress.
   */
  public inquireOrders(inqReq: OrderInquiryRequest): Observable<any> {

    if (inqReq === null || inqReq === undefined) {
      throw new Error('Required parameter inqReq was null or undefined when calling inquireOrders Using POST.');
    }

    return this.apiService.post(`/order/inquiry`, inqReq).pipe(map(
      data => {
        return data;
      }
    ));

  }
  public getOrderDetails(portfolioNumber: string, omsRefNumber: string): Observable<OrderDetails> {

    if (portfolioNumber === null || portfolioNumber === undefined) {
      throw new Error('Required parameter portfolioNumber was null or undefined when calling getOrderDetailsGET.');
    }
    if (omsRefNumber === null || omsRefNumber === undefined) {
      throw new Error('Required parameter omsRefNumber was null or undefined when calling getOrderDetailsGET.');
    }

    return this.apiService.get(`/order/${encodeURIComponent(String(omsRefNumber))}/${encodeURIComponent(String(portfolioNumber))}/details`).pipe(map(
      data => {
        return data;
      }
    ));

  }

  public getOutstandingOrders(inqReq: OrderInquiryRequest): Observable<any> {
    if (inqReq.portfolioNum === null || inqReq.portfolioNum === undefined) {
      throw new Error('Required parameter portfolioNumber was null or undefined when calling getOutstandingOrders.');
    }

    return this.apiService.post(`/order/outstandingOrders`, inqReq).pipe(map(
      data => {
        return data;
      }
    ));
  }

  public cancelOrder(portfolioNumber: string, omsRefNumber: string): Observable<OrderDetails> {

    if (portfolioNumber === null || portfolioNumber === undefined) {
      throw new Error('Required parameter portfolioNumber was null or undefined when calling cancel order.');
    }
    if (omsRefNumber === null || omsRefNumber === undefined) {
      throw new Error('Required parameter omsRefNumber was null or undefined when calling cancel order.');
    }

    return this.apiService.delete(`/order/${encodeURIComponent(String(omsRefNumber))}/${encodeURIComponent(String(portfolioNumber))}`).pipe(map(
      data => {
        return data;
      }
    ));

  }

  public getOrderHistory( omsRefNumber: string): Observable<OrderDetails[]> {

    if (omsRefNumber === null || omsRefNumber === undefined) {
      throw new Error('Required parameter omsRefNumber was null or undefined when calling get order history.');
    }

    return this.apiService.get(`/order/${encodeURIComponent(String(omsRefNumber))}/history`).pipe(map(
      data => {
        return data;
      }
    ));

  }

}
