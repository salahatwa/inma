export interface LoginRequest { 
    password?: string;
    username?: string;
}
