export interface TradeSec {
    symbol?: string;

    avgCostPrice?: string;

    mrktPrice?: string;

    availQuantity?: string;

    secEnName?: string;

    ownedQuantity?: string;

    totalMrktVal?: string;

    realizedProfitLoss?: string;

    realizedProfitLossPercen?: string;

    unsettledSellQuantity?: string;

    pledgedQuantity?: string;

    unrealizedProfitLossPercen?: string;

    unsettledBuyQuantity?: string;

    outstandBuyQuantity?: string;

    outstandSellQuantity?: string;

    secArName?: string;

    totalCost?: string;

    unrealizedProfitLoss?: string;
}