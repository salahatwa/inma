export interface CustomerDetails {
    cif?: string;
    fatherName?: string;
    gender?: string;
    residenceCountryCode?: string;
    city?: string;
    nextKYCReviewDt?: string;
    poiIssueDt?: string;
    poiType?:string;
    grandFatherName?: string;
    postalCode?: string;
    phoneList?: PhoneList[];
    samaStatus?: string;
    birthPlace?: string;
    poBox?: string;
    poiIssueDtHjr?: string;
    nationalityCode?: string;
    relMngrId?: string;
    relMngrNameEn?: string;
    countryCode?: string;
    isPrimary?: string;
    familyName?: string;
    segment?: string;
    sector?: string;
    email?: string;
    addrType?: string;
    branchId?: string;
    birthDt?: string;
    nextKYCReviewDtHjr?: string;
    legalStatus?: string;
    fullName?: string;
    poiExpDtHjr?: string;
    poiExpDt?: string;
    relMngrNameAr?: string;
    poiIssuePlace?: string;
    firstName?: string;
    langPref?: string;
    addrLine2?: string;
    poiNum?: string;
    custType?: string;
    openDtHjr?: string;
    openDt?: string;
    shortName?: string;
    maritalStatus?: string;
    alinmaId?: string;
    custStatus?: string;
}


export interface PhoneList {
    phoneCountryCode?: string;
    phoneType?: string;
    phoneNum?: string;
    phoneCategory?:string;
    phoneAreaCode?:string;
}
