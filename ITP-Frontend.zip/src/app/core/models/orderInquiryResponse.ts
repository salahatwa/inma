import { OrderDetails } from './OrderDetails';
import { RecCtrlOut } from './recCtrlOut';

export interface OrderInquiryResponse{
    ordersList: OrderDetails[];
    recCtrlOut: RecCtrlOut;
}