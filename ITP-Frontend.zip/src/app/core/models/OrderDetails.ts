export interface OrderList {
    portfolioNum?: string;
    ordersDetailsList?: OrderDetails[];
    matchedRecs?:number;
    listType?:number;
}

export interface OrderDetails {
    avgPrice: string;
    bankCommiss: string;
    broker: string;
    brokerCommiss: string;
    cif: string;
    curAmt: CurAmt;
    dealerId: string;
    excQty: string;
    excTotalAmt: string;
    executionInfoList: ExecutionInfoList[];
    expDt: string;
    maxFloor: string;
    mrktAuthrzd: string;
    mrktCode: string;
    mrktPrice: string;
    mrktRefNum: string;
    omsRefNum: string;
    ordCommiss: string;
    ordDt: string;
    ordDtHjr: string;
    ordQty: string;
    ordSide: string;
    ordStatus: string;
    ordTm: string;
    ordType: string;
    portfolioNum: string;
    rmnngQty: string;
    samaAcctNum: string;
    scId: string;
    secShortNameAr: string;
    secShortNameEn: string;
    symbol: string;
    tadCommiss: string;
    taxInfo: TaxInfo;
    tifType: string;
    usrId: string;
	amtLcl: string;
	curRate: string;
	ordRejectReason: string;
    minFillQty: string;
    stopPrice: String;
}

export interface ExecutionInfoList {
    bankCommission: string;
    brokerCommission: string;
    executedAmount: string;
    executedPrice: string;
    executedQuantity: string;
    executionDate: string;
    executionRefNumber: string;
    marketCommission: string;
    settlementDate: string;
    taxInfo: TaxInfo;
    totalAmt: string;
}

export interface TaxInfo {
    taxAmt: string;
    taxPercen: string;
    taxType: string;
    invoiceNum:String;

}

export interface CurAmt {
    amt: string;
    curCode: string;
    amtLcl: string;
	curRate: string;
}
