// Here we are defining an interface for a Function that accepts two arguments and
// returns nothing (in this case, it's the typical Node.js callback pattern).

export class EventData {
    event: string;
    eventCallBack: string;
    value: any;
    success: boolean = true;
    errMsg: string;
    constructor(event, value?: any, eventCallBack?: string, success?: boolean, errMsg?: string) {
        this.event = event;
        this.eventCallBack = eventCallBack;
        this.value = value;
        this.success = (success != undefined) ? success : true;
        this.errMsg = errMsg;
    }
    set errorMsg(errMsg: string) {
        this.errMsg = errMsg;
    }
}

/**
   * Events constant for emit and listen events
   */
export class Events {
    // boilerplate 
    constructor(private event: string) {
    }

    toString() {
        return this.event;
    }

    /**
     * STOCK DETAILS EVENTS FOR CREATE-UPDATE ORDER
     */
    static GET_STOCK_DETAILS_CREATE_ORDER = new Events("GET_STOCK_DETAILS_CREATE_ORDER").toString();
    static GET_STOCK_DETAILS_WEBSOCKET = new Events("GET_STOCK_DETAILS_WEBSOCKET").toString();
    static GET_STOCK_DETAILS_CREATE_ORDER_CALLBACK = new Events("GET_STOCK_DETAILS_CREATE_ORDER_CALLBACK").toString();
    static GET_STOCK_DETAILS_UPDATE_ORDER = new Events("GET_STOCK_DETAILS_UPDATE_ORDER").toString();
    static GET_STOCK_DETAILS_UPDATE_ORDER_CALLBACK = new Events("GET_STOCK_DETAILS_UPDATE_ORDER_CALLBACK").toString();

    /**
     * PORTFOLIO DETAILS EVENTS FOR CREATE-UPDATE ORDER
     */
    static GET_PORTFOLIO_DETAILS_CREATE_ORDER = new Events("GET_PORTFOLIO_DETAILS_CREATE_ORDER").toString();
    static GET_PORTFOLIO_DETAILS_CREATE_ORDER_CALLBACK = new Events("GET_PORTFOLIO_DETAILS_CREATE_ORDER_CALLBACK").toString();
    static GET_PORTFOLIO_DETAILS_UPDATE_ORDER = new Events("GET_PORTFOLIO_DETAILS_UPDATE_ORDER").toString();
    static GET_PORTFOLIO_DETAILS_UPDATE_ORDER_CALLBACK = new Events("GET_PORTFOLIO_DETAILS_UPDATE_ORDER_CALLBACK").toString();

    /**
     * Commission Events For CREATE- UPDATE ORDER
     */

    static GET_COMMISSION_DETAILS_CREATE_ORDER = new Events("GET_COMMISSION_DETAILS_CREATE_ORDER").toString();
    static GET_COMMISSION_DETAILS_CREATE_ORDER_CALLBACK = new Events("GET_COMMISSION_DETAILS_CREATE_ORDER_CALLBACK").toString();
    static GET_COMMISSION_DETAILS_UPDATE_ORDER = new Events("GET_COMMISSION_DETAILS_UPDATE_ORDER").toString();
    static GET_COMMISSION_DETAILS_UPDATE_ORDER_CALLBACK = new Events("GET_COMMISSION_DETAILS_UPDATE_ORDER_CALLBACK").toString();


}