export interface CommissionRequest { 
    orderQty: number;
    orderSide: string;
    orderType: number;
    portfolioNum: string;
    stockSymbol: string;
    unitPrice?: number;
}

export interface CommissionResponse
{
    bankCommVATPercentage?:string;
	totalComm?:string;
	totTradeAmt?:string;
	bankComm?:string;
	bankCommVAT?:string;
	exchangeFees?:string;
}
