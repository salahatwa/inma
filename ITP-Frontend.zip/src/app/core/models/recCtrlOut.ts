export interface RecCtrlOut{
    matchedRecs?: number;
    sentRecs?: number; 
}