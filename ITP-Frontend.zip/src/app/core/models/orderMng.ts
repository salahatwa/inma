export interface OrderRequest { 
    omsRefNum?:string;
    expDt?: string;
    minFillQty?: number;
    orderQty?: number;
    orderSide?: string;
    orderType?: string;
    stockSymbol?: string;
    tifType?: number;
    unitPrice?: number;
    portfolioNum?: string;
    action:string;
}

export interface OrderResponse { 
    ordRefNum?: string;
}
