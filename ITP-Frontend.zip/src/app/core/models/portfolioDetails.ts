

import {TradeSec} from  '../models/models';

export interface PortfolioDetails { 
    discountRate?: string;
    totalUnrealizedProfitLos?: string;
    samaAcctNum?: string;
    excSellAmt?: string;
    excBuyAmt?: string;
    availBal?: string;
    outstandSellAmt?: string;
    totalMrktVal?: string;
    mobileNum?: string;
    portfolioNum?: string;
    buyingPwr?: string;
    poiNum?: string;
    totalRealizedProfitLoss?: string;
    portfolioPositionAmt?: string;
    portfolioName?: string;
    totalCost?: string;
    outstandBuyAmt?: string;
    acctNum?:string;
    marginLimit?:String ;
    tradeSecList?: TradeSec[]; 
}


