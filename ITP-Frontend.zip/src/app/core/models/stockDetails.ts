export interface StockDetails { 
    bestAskPrice?: string;
    bestAskQty?: string;
    bestBidPrice?: string;
    bestBidQty?: string;
    lastPrice?: string;
    loserAlert?: string;
    loserCompany?: string;
    maxPriceLimit?: string;
    minPriceLimit?: string;
    mlenabled?: string;
    mrktCode?: string;
    openPrice?: string;
    prevClosure?: string;
    priceChangeAmt?: string;
    priceChangeRate?: string;
    riskRate?: string;
    secArName?: string;
    secEnName?: string;
    settlementDays?: string;
    symbol?: string;
    tradable?: string;
    tradableRights?: string;
    tradableRightsAlert?: string;
    tradedVol?: string;
}
