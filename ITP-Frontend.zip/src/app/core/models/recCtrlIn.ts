export interface RecCtrlIn { 
    maxRecs?: number;
    offset?: number;
}
