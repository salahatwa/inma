import { DtRange } from './dtRange';
import { RecCtrlIn } from './recCtrlIn';

export interface OrderInquiryRequest { 
    dtRange?: DtRange;
    ordRefNum?: string;
    ordStatus?: string;
    orderSide?: string;
    stockSymbol?: string;
    portfolioNum?: string;
    recCtrlIn?: RecCtrlIn;
    myOrders?: boolean;
}
