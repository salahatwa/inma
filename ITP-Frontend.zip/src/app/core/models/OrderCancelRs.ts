export interface OrderCancelRs{
    orderDeleted : boolean;
}