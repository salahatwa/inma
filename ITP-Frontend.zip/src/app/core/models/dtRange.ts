export interface DtRange { 
    endDt?: string;
    startDt?: string;
}
