import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserIdleService } from 'angular-user-idle';
import { Subscription } from 'rxjs';
import { UserService } from './core/services/user.service';
import { UserIdleDialogComponent } from './shared/components/user-idle-dialog/user-idle-dialog.component';
import { UtilsService } from './shared/services/utils.service';
import { Config } from './shared/utils/config';


@Component({
  selector: 'app-inma-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  private subscription: Subscription;
  public spinnerPos: string = 'left';
  public progressDir: string = 'ltr+';
  env = new Config();

  constructor(private router: Router,
    private utilService: UtilsService,
    private userIdle: UserIdleService,
    private userService: UserService,
    private modalService: NgbModal,
    private config: Config
  ) {
    this.utilService.loadDefaultSetting();
    this.reloadDir();
    this.userService.populate();

    router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        var title = this.getTitle(router.routerState, router.routerState.root).join('-');
        this.utilService.setDocTitle(title, true);
      }
    });
  }


  /**
   * auto reload direction on language change
   */
  reloadDir() {
    // setup listener to listen if language changed
    this.subscription = this.utilService.changeLangDir$.subscribe((data) => {
      if (data === 'ar') {
        this.spinnerPos = 'left';
        this.progressDir = 'ltr+';
      }
      else {
        this.spinnerPos = 'right';
        this.progressDir = 'rtl+';
      }
    });

    // check by defualt lang
    let lang: string = this.utilService.getCurrentLang();
    if (lang && lang != null && lang != '' && lang === 'ar') {
      this.spinnerPos = 'left';
      this.progressDir = 'ltr+';
    }
    else {
      this.spinnerPos = 'right';
      this.progressDir = 'rtl+';
    }
  }



  // collect that title data properties from all child routes
  // there might be a better way but this worked for me
  getTitle(state, parent) {
    var data = [];
    if (parent && parent.snapshot.data && parent.snapshot.data.title) {
      data.push(parent.snapshot.data.title);
    }

    if (state && parent) {
      data.push(... this.getTitle(state, state.firstChild(parent)));
    }
    return data;
  }

  ngOnInit() {
    console.log('Application: '+this.env.name);
    console.log('Application Desc: '+this.env.description);
    console.log('Application api url: '+this.env.api);
    console.log('Application version: '+this.env.version);
    //Start watching for user inactivity.
    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe(count => {
      if (count == 1) {
        const dialogRef = this.modalService.open(UserIdleDialogComponent, { backdrop: 'static', keyboard: false });
        dialogRef.result.then(result => {
          if (result) {
            this.userIdle.resetTimer();
          } else {
            this.modalService.dismissAll();
            this.userService.logout();
          }
        }).catch((res) => {
          
        });
      }
      if (count == this.config.sessionTimeOut) {
        this.modalService.dismissAll();
        this.userIdle.stopWatching();
        this.userService.logout();
      }
    });

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => {
      this.modalService.dismissAll();
      this.userIdle.stopWatching();
      this.userService.logout();
    });
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
