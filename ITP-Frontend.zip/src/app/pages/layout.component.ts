import { Component, OnInit } from '@angular/core';
import { fadeAnimation } from '../shared/utils/fade.animation';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
  animations: [fadeAnimation]
})
export class LayoutComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
   
  }

  public getRouterOutletState(outlet) {
    return outlet.isActivated ? outlet.activatedRoute : '';
  }

 

}
