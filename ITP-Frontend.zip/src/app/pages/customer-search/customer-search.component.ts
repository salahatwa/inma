import { Component, OnInit } from '@angular/core';
import { CustomerDetails } from './../../core/models/models';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { CustomerService } from './../../core/services/customer.service';
import { finalize } from 'rxjs/operators';
import { AlertService } from './../../shared/components/alert/alert.service';
import { TranslateService } from '@ngx-translate/core';
import { Constant } from './../../shared/utils/constant';
import { UtilsService } from './../../shared/services/utils.service';

@Component({
  selector: 'app-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.scss']
})
export class CustomerSearchComponent implements OnInit {

  maskNum = Constant.NUMBER_REGEX;

  isLoading: boolean;
  customer: CustomerDetails;

  customerSearchForm: FormGroup;
  alertId = { id: 'customerSearch-alert' + Math.random().toString(36).substring(2) };

  constructor(private formBuilder: FormBuilder, private utilService: UtilsService, private customerService: CustomerService, private translateService: TranslateService, private notifyService: AlertService) { }

  ngOnInit(): void {
    this.customerSearchForm = this.formBuilder.group({
      poiNum:  new FormControl(''),
      cif:  new FormControl('')
    }, { validator: this.atLeastOneValueRequired });
  }



  getCustomersDetails() {
    let req = this.customerSearchForm.value;
    this.isLoading = true;
    this.customerService.getCustomerDetails(req.poiNum, req.cif).pipe(finalize(() => {
      this.isLoading = false;
    }))
      .subscribe(data => {
        this.customer = data;
        let msgBody = this.translateService.instant('notify.clientSearch', { name: this.customer.fullName });
        this.notifyService.success(msgBody, this.alertId);

      },
        err => { this.notifyService.error(err.message, this.alertId); }
      );
  }

  atLeastOneValueRequired(group: FormGroup): { [s: string]: boolean } {
    if (group) {
      if (group.controls['poiNum'].value || group.controls['cif'].value) {
        return null;
      }
    }
    return { 'oneValueRequired': true };
  }

  clear() {
    this.customerSearchForm.reset();
  }

  onFormValueChange(controlName: string) {
    this.customerSearchForm.controls[controlName].setValue('');
    this.customer = {};
  }



  public getManagerName() {
    if (!this.customer)
      return '';

    if (this.utilService.getCurrentLang() == 'ar') {
      return this.customer.relMngrNameAr;
    } else
      return this.customer.relMngrNameEn;
  }

}
