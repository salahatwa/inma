import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerSearchComponent } from './customer-search.component';
import { SharedModule } from './../../shared/modules/shared.module';
import { AuthModule } from './../../shared/services/auth/auth.module';



@NgModule({
  declarations: [CustomerSearchComponent],
  imports: [
    SharedModule,
    AuthModule,
    CommonModule
  ]
})
export class CustomerSearchModule { }
