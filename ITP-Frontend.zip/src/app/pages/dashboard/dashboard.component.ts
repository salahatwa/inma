import { AfterViewInit, Component, OnInit } from '@angular/core';
import { OrderList } from './../../core/models/models';
import { UtilsService } from './../../shared/services/utils.service';


@Component({
  selector: 'app-inma-dashboard',
  templateUrl: './dashboard.component.html',
  styles: []
})
export class DashboardComponent implements OnInit, AfterViewInit {

  orderList: OrderList = {};
  

  constructor(public utilService: UtilsService) {
    this.utilService.setDocTitle('dashboard.title', true);
  }

  ngOnInit() {

  }

  ngAfterViewInit() {
  }

  setOrderListValue(event: OrderList) {
    this.orderList = event;
  }


}
