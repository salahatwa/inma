import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/modules/shared.module';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { AuthModule } from './../../shared/services/auth/auth.module';
import { EnterOrderComponent } from './enter-order/enter-order.component';

@NgModule({
  declarations: [DashboardComponent, EnterOrderComponent],
  imports: [
    SharedModule,
    AuthModule,
    DashboardRoutingModule
  ],
  providers: []
})
export class DashboardModule { }
