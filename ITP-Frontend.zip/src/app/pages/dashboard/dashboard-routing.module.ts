import { NgModule } from '@angular/core';
import { AuthGuard } from '../../shared/services/auth/auth-guard.service';



@NgModule({
  imports: [
  ],
  // declarations: [DashboardComponent],
  providers: [
    AuthGuard,
  ],
  exports: [
    // DashboardComponent
  ]

})
export class DashboardRoutingModule { }
