import { AfterViewInit, Component, ElementRef, EventEmitter, OnDestroy, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { CommissionRequest, CommissionResponse, EventData, Events, OrderInquiryRequest, OrderInquiryResponse, OrderList, OrderRequest, PortfolioDetails, StockDetails } from './../../../core/models/models';
import { OrderService } from './../../../core/services/api';
import { EventBusService } from './../../../core/services/event-bus.service';
import { AlertService } from './../../../shared/components/alert/alert.service';
import { ConfirmOrderDialogComponent } from './../../../shared/components/dashboard/app-dialogs/confirm-order-dialog/confirm-order-dialog.component';
import { UtilsService } from './../../../shared/services/utils.service';
import { Constant } from './../../../shared/utils/constant';
import { dateConditionallyRequiredValidator, priceConditionallyRequiredValidator, quanityValidator, tickSize } from './../../../shared/utils/validator';
@Component({
  selector: 'app-enter-order',
  templateUrl: './enter-order.component.html',
  styleUrls: ['./enter-order.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EnterOrderComponent implements OnInit, AfterViewInit, OnDestroy {

  // Mask expression to restric user to enter valid date format
  maskDate = Constant.DATE_REGEX;
  maskNum = Constant.NUMBER_REGEX;
  alertId = { id: 'enter-order-alert' }

  isLoading = false;//hold action for any events on enter order component
  orderForm: FormGroup;
  stockDetails: StockDetails;
  commissionDetails: CommissionResponse;
  portfolioDetails: PortfolioDetails;
  minPriceValue: any = Constant.MIN_PRICE_VALUE;
  maxPriceValue: any = Constant.MAX_PRICE_VALUE;
  selectedOrderSide: string = Constant.BUY;
  selectedOrderType: string = Constant.LIMIT_PRICE;
  selectedTifType: string = Constant.TODAY_ONLY;
  tifTypeValues: any;//Validatity
  orderDateTValue;

  @ViewChild("stockSymbol") stockSymbolField: ElementRef;
  @ViewChild("portfolioNum") portfolioNumField: ElementRef;
  @ViewChild("orderSide") orderSideField: ElementRef;
  @ViewChild("orderType") orderTypeField: ElementRef;
  @ViewChild("orderPrice") orderPriceField: ElementRef;
  @ViewChild("orderQty") orderQtyField: ElementRef;
  @ViewChild("orderTifType") orderTifTypeField: ElementRef;
  @ViewChild("orderDate") orderDateField: ElementRef;
  @ViewChild("orderDeclarQty") orderDeclarQtyField: ElementRef;
  @ViewChild("orderSubmit") orderSubmitBtn: ElementRef;

  /**
   * Declaring events that sent output to child components
   */
  @Output() orderListEvent = new EventEmitter<OrderList>();

  stockSubscribition: Subscription;
  portfolioSubscribition: Subscription;
  commissionSubscribition: Subscription;


  constructor(protected alertService: AlertService, private utilService: UtilsService, private formBuilder: FormBuilder, private modalService: NgbModal,
    private translateService: TranslateService,
    private orderService: OrderService, private eventBus: EventBusService) { }

  ngOnInit(): void {
    this.initOrderForm();
    this.addGetStockDetailsListener();
    this.addGetPortfolioDetailsListener();
    this.addCommissionDetailsListener();
  }


  /**
   * Focus on stock symbol after Initialization
   */
  ngAfterViewInit() {
    // this.stockSymbolField.nativeElement.
    this.stockSymbolField.nativeElement.blur();
    this.stockSymbolField.nativeElement.focus();
  }

  ngOnDestroy() {
    this.stockSubscribition.unsubscribe();
    this.portfolioSubscribition.unsubscribe();
    this.commissionSubscribition.unsubscribe();
  }

  /**
    * Listen to call back events from stock details component
   */
  addGetStockDetailsListener() {
    this.stockSubscribition = this.eventBus.on(Events.GET_STOCK_DETAILS_CREATE_ORDER_CALLBACK, (result: EventData) => {
      this.isLoading = false;
      this.utilService.enableFormField(this.orderForm, 'stockSymbol');
      if (!result.success) {
        this.stockSymbolField.nativeElement.blur();
        this.stockSymbolField.nativeElement.focus();
        this.stockDetails = {};
        this.alertService.error(result.errMsg, this.alertId);
        return;
      }
      this.alertService.success(this.translateService.instant('notify.getStockDetails'), this.alertId);
      this.stockDetails = result.value;
      this.orderSideField.nativeElement.focus();
      this.addPriceValidations();
    });
  }

  /**
     * Listen to call back events from portfolio details component
    */
  addGetPortfolioDetailsListener() {
    this.portfolioSubscribition = this.eventBus.on(Events.GET_PORTFOLIO_DETAILS_CREATE_ORDER_CALLBACK, (result: EventData) => {
      this.isLoading = false;
      this.utilService.enableFormField(this.orderForm, 'portfolioNum');
      if (!result.success) {
        this.portfolioNumField.nativeElement.blur();
        this.portfolioNumField.nativeElement.focus();
        this.portfolioDetails = {};
        this.alertService.error(result.errMsg, this.alertId);
        return;
      }

      this.alertService.success(this.translateService.instant('notify.getPortfolioDetails'), this.alertId);
      this.portfolioDetails = result.value;
      this.orderTypeField.nativeElement.focus();

      /**
       * send portfolio num to order list component to display search button
       *  search button to get outstanding orders for this portfolioNum
       * */
      this.orderListEvent.emit({
        portfolioNum: this.portfolioDetails.portfolioNum,
        ordersDetailsList: []
      });
    });
  }


  /**
     * Listen to call back events from portfolio details component
    */
  addCommissionDetailsListener() {
    this.commissionSubscribition = this.eventBus.on(Events.GET_COMMISSION_DETAILS_CREATE_ORDER_CALLBACK, (result: EventData) => {
      this.isLoading = false;
      this.utilService.enableFormField(this.orderForm, 'orderQty');
      if (!result.success) {
        this.orderQtyField.nativeElement.blur();
        this.orderQtyField.nativeElement.focus();
        this.commissionDetails = {};
        this.alertService.error(result.errMsg, this.alertId);
        return;
      }

      this.alertService.success(this.translateService.instant('notify.getCommissionDetails'), this.alertId);
      this.commissionDetails = result.value;
      this.orderTifTypeField.nativeElement.focus();
    });
  }


  /**
     * Listen to key press event to reset component details
     * Ex: when user type any thing on stock input this method 
     * will listen to new typed value ,
     * so we will reset stock detail component
     */
  onStockValueChange() {
    this.eventBus.emit(new EventData(Events.GET_STOCK_DETAILS_CREATE_ORDER));
    this.stockDetails = {};
    this.onPortfolioValueChange();
    this.addPriceValidations();
  }

  /**
    * Reset Portfolio details on typing event
    */
  onPortfolioValueChange() {
    this.eventBus.emit(new EventData(Events.GET_PORTFOLIO_DETAILS_CREATE_ORDER));
    this.orderListEvent.emit({ ordersDetailsList: [] });
    this.portfolioDetails = {};
  }

  /**
   * Reset  Commission details on typing evenr
   */
  onOrderQtyValueChange() {
    this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_CREATE_ORDER));
    this.commissionDetails = {};
  }



  /**
   * Confirm order dialog summary
   */
  confirmOrderDialog() {

    if (this.selectedOrderSide == Constant.BUY) {
      let totalDeal: number = +this.commissionDetails?.totTradeAmt;
      let buyinPower: number = +this.portfolioDetails?.buyingPwr;
      if (buyinPower < totalDeal) {
        this.alertService.error(this.translateService.instant('enter_order.validations.buyPower'), this.alertId);
        return;
      }
    }

    let req: OrderRequest = {
      stockSymbol: this.orderForm.get('stockSymbol').value,
      portfolioNum: this.orderForm.get('portfolioNum').value,
      orderSide: this.orderForm.get('orderSide').value,
      orderType: this.orderForm.get('orderType').value,
      unitPrice: this.orderForm.get('orderPrice').value,
      orderQty: this.orderForm.get('orderQty').value,
      tifType: this.orderForm.get('orderTifType').value,
      expDt: this.orderForm.get('orderDate').value,
      minFillQty: this.orderForm.get('orderDeclarQty').value,
      action: Constant.ADD_ORDER_ACTION
    }


    const dialogRef = this.modalService.open(ConfirmOrderDialogComponent, { scrollable: true, size: 'lg' });
    dialogRef.componentInstance.order = req;
    dialogRef.result.then(result => {
      if (result) {
        this.isLoading = true;
        this.orderService.executeOrder(result)
          .pipe(finalize(() => {
            this.isLoading = false;
          })
          ).subscribe(
            data => {
              //reset form
              this.clear();

              this.alertService.success(this.translateService.instant('notify.ordExecution', { ordRefNum: data.omsRefNum }), this.alertId);


              this.orderListEvent.emit({
                portfolioNum: req.portfolioNum,
                ordersDetailsList: [data],
                matchedRecs: 1
              });


            },
            err => {
              this.alertService.error(err.message, this.alertId);
            }
          );
      }
    }).catch((res) => {

    });


  }



  getOrderSideNextElm(event: any) {
    event.preventDefault();
    // this.orderSideField.close();
    this.portfolioNumField.nativeElement.focus();
  }

  getOrderTypeNextElm(event: any) {
    event.preventDefault();
    if (this.selectedOrderType == Constant.MARKET_PRICE) {
      this.orderForm.controls['orderPrice'].setValue('');
      this.orderQtyField.nativeElement.focus();
    }
    else
      this.orderPriceField.nativeElement.focus();
  }

  getOrderPriceNextElm() {
    let priceControl = this.orderForm.get('orderPrice');
    if (priceControl.errors) {
      this.orderPriceField.nativeElement.blur();
      this.orderPriceField.nativeElement.focus();
    } else {
      this.orderQtyField.nativeElement.focus();
    }

  }

  getTifTypeNextElm(event: any) {
    // event.preventDefault();
    if (this.selectedTifType == Constant.CUSTOM_DATE) {
      this.orderDateField.nativeElement.blur();
      this.orderDateField.nativeElement.focus();
    }
    else
      this.orderDeclarQtyField.nativeElement.focus();
  }


  getOrderDateNextElm(event: any) {
    let ordDateControl = this.orderForm.get('orderDate');
    if (ordDateControl.value && ordDateControl.valid) {
      event.preventDefault();
      this.orderDeclarQtyField.nativeElement.focus();

    } else {
      this.orderDateField.nativeElement.blur();
      this.orderDateField.nativeElement.focus();
    }
  }

  getOrderDeclarQtyNextElm() {
    event.preventDefault();
    this.orderSubmitBtn.nativeElement.focus();
  }

  handleKeyEvent(value: any, action: string) {

  }

  /**
  * return stock details
  * @param symbol 
  */
  getStockDetail(symbol: string) {

    let symbolControl = this.orderForm.get('stockSymbol');
    if (symbolControl.errors) {
      this.stockSymbolField.nativeElement.blur();
      this.stockSymbolField.nativeElement.focus();
      return;
    }

    this.isLoading = true;
    this.utilService.disableFormField(this.orderForm, 'stockSymbol');

    /**
     * send symbol to stock-details components , stock details will get data for given symbol
     * and return result again to enter-order by call back event 
     * call back event listen to stock details when fire result back
     * and  result back handled in ngOnInit component for enter-order
     */
    this.eventBus.emit(new EventData(Events.GET_STOCK_DETAILS_CREATE_ORDER, symbol, Events.GET_STOCK_DETAILS_CREATE_ORDER_CALLBACK));
  }

  getPortfolioDetail(portfolioNum: string) {
    let stockControl = this.orderForm.get('stockSymbol');
    let portfolioControl = this.orderForm.get('portfolioNum');

    if (stockControl.errors) {
      this.stockSymbolField.nativeElement.blur();
      this.stockSymbolField.nativeElement.focus();
      return;
    }

    if (portfolioControl.errors) {
      this.portfolioNumField.nativeElement.blur();
      this.portfolioNumField.nativeElement.focus();
      return;
    }

    this.isLoading = true;
    this.utilService.disableFormField(this.orderForm, 'portfolioNum');

    /**
     * send symbol,portfolioNum to PORTFOLIO-details components , PORTFOLIO details will get data for given [symbol ,portfolioNum]
     * and return result again to enter-order by call back event 
     * call back event listen to stock details when fire result back
     * and  result back handled in ngOnInit component for enter-order
     */
    this.eventBus.emit(new EventData(Events.GET_PORTFOLIO_DETAILS_CREATE_ORDER, { symbol: stockControl.value, portfolioNum: portfolioNum }, Events.GET_PORTFOLIO_DETAILS_CREATE_ORDER_CALLBACK));
  }

  /**
   * Get commission details when click enter on Qty Field
   * @param qty 
   */
  getCommissionDetail(qty: number) {
    if (qty && qty > 0) {
      //Validate price in case of Limit price
      if (this.selectedOrderType == Constant.LIMIT_PRICE) {
        let ordPriceControl = this.orderForm.get('orderPrice');

        if (ordPriceControl.errors) {
          this.orderPriceField.nativeElement.blur();
          this.orderPriceField.nativeElement.focus();
          return;
        }
        else {
          this.orderQtyField.nativeElement.blur();
          this.orderQtyField.nativeElement.focus();
        }
      }


      if (this.orderForm.get('orderQty').errors) {
        this.orderQtyField.nativeElement.blur();
        this.orderQtyField.nativeElement.focus();
        return;
      }

      let commReq: CommissionRequest = {
        orderQty: qty,
        stockSymbol: this.orderForm.get('stockSymbol').value,
        portfolioNum: this.orderForm.get('portfolioNum').value,
        orderSide: this.orderForm.get('orderSide').value,
        orderType: this.orderForm.get('orderType').value,
        unitPrice: this.orderForm.get('orderPrice').value
      }

      if (commReq.stockSymbol == 'undefined' || commReq.stockSymbol == '' || commReq.stockSymbol == null) {
        this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_CREATE_ORDER));
        this.eventBus.emit(new EventData(Events.GET_STOCK_DETAILS_CREATE_ORDER));
        this.stockDetails = {};
        this.stockSymbolField.nativeElement.blur();
        this.stockSymbolField.nativeElement.focus();
        return;
      }

      if (commReq.portfolioNum == 'undefined' || commReq.portfolioNum == '' || commReq.portfolioNum == null) {
        this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_CREATE_ORDER));
        this.eventBus.emit(new EventData(Events.GET_PORTFOLIO_DETAILS_CREATE_ORDER));
        this.portfolioNumField.nativeElement.blur();
        this.portfolioNumField.nativeElement.focus();
        return;
      }


      this.isLoading = true;
      this.utilService.disableFormField(this.orderForm, 'orderQty');
      this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_CREATE_ORDER, commReq, Events.GET_COMMISSION_DETAILS_CREATE_ORDER_CALLBACK));

    } else {
      this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_CREATE_ORDER));
      this.orderQtyField.nativeElement.blur();
      this.orderQtyField.nativeElement.focus();
    }

  }

  /**
   * 
   * @param event Clear form value
   */
  clear() {
    this.tifTypeValues = Constant.tifTypeLPrice;
    this.selectedOrderType = Constant.LIMIT_PRICE;
    this.selectedTifType = this.tifTypeValues[0].value;
    //reset disabled controls before reset form
    this.orderTypeChange(this.selectedOrderType);
    this.orderTifTypeChange(this.selectedTifType);
    this.orderForm.reset();
    this.initOrderForm();
    this.stockSymbolField.nativeElement.focus();
    this.eventBus.emit(new EventData(Events.GET_STOCK_DETAILS_CREATE_ORDER));
    this.eventBus.emit(new EventData(Events.GET_COMMISSION_DETAILS_CREATE_ORDER));
    this.eventBus.emit(new EventData(Events.GET_PORTFOLIO_DETAILS_CREATE_ORDER));
    this.orderListEvent.emit({ ordersDetailsList: [] });
    this.stockDetails = {};
    this.portfolioDetails = {};
    this.commissionDetails = {};
  }

  /**
   * Initialize order form default values , validations
   */
  initOrderForm() {
    /**
    * Intialize TifType List depend on OrderType
    */
    this.tifTypeValues = Constant.tifTypeLPrice;
    this.selectedOrderSide = Constant.BUY;
    this.selectedOrderType = Constant.LIMIT_PRICE;
    this.selectedTifType = this.tifTypeValues[0].value;

    this.orderForm = this.formBuilder.group({
      stockSymbol: ['', [Validators.required]],
      orderSide: [this.selectedOrderSide, Validators.required],
      portfolioNum: ['', [Validators.required]],
      orderType: [this.selectedOrderType, Validators.required],
      orderPrice: [{ value: null, disabled: ((this.selectedOrderType === Constant.MARKET_PRICE) ? true : false) }, [
        priceConditionallyRequiredValidator,
        (control: AbstractControl) => Validators.max(this.maxPriceValue)(control),
        (control: AbstractControl) => Validators.min(this.minPriceValue)(control)
        , tickSize]],
      orderQty: ['', [Validators.required,
      (control: AbstractControl) => quanityValidator((this.portfolioDetails?.tradeSecList && this.portfolioDetails?.tradeSecList[0] && this.portfolioDetails?.tradeSecList[0]?.ownedQuantity) ? (+this.portfolioDetails?.tradeSecList[0].ownedQuantity) : 0)(control)]],
      orderTifType: [this.selectedTifType, Validators.required],
      orderDate: [{ value: null, disabled: (this.selectedTifType == Constant.CUSTOM_DATE ? false : true) }, [dateConditionallyRequiredValidator,
        Validators.pattern(Constant.DatePattern),
      ]],
      orderDeclarQty: ['']
    });

  }

  /**
   * This method listen to select event onChange
   * To change color of enter order component depend on OrderSide
   * If orderSide == SPR it should be green else it will be red
   * Adding price validations , Max , Min value returned from stoack details
   * @param event 
   */
  orderSideChange(event: any) {
    this.selectedOrderSide = event;
    this.addPriceValidations();
    this.orderForm.get('orderQty').updateValueAndValidity();
  }

  addPriceValidations() {
    if (this.stockDetails && this.selectedOrderSide == Constant.BUY) {
      this.maxPriceValue = this.stockDetails.maxPriceLimit;
      this.minPriceValue = 1;
    }
    else if (this.stockDetails && this.selectedOrderSide == Constant.SELL) {
      this.maxPriceValue = 1000000;
      this.minPriceValue = this.stockDetails.minPriceLimit;
    } else {
      this.minPriceValue = Constant.MIN_PRICE_VALUE;
      this.maxPriceValue = Constant.MAX_PRICE_VALUE;
    }
  }


  /**
   * This method listen to select event onChange
   * To change color of enter order component depend on OrderType
   * If orderType == 1 (Market Price) it should be green else it will be red
   * orderType==2 (Limit Price)
   * @param event 
   */
  orderTypeChange(event: any) {
    this.selectedOrderType = event;
    let priceControl = this.orderForm.controls['orderPrice'];

    if (this.selectedOrderType == Constant.MARKET_PRICE) {
      priceControl.disable();
      this.tifTypeValues = Constant.tifTypeMPrice;
    } else {
      priceControl.enable();
      this.tifTypeValues = Constant.tifTypeLPrice;
    }

  }


  orderTifTypeChange(event: any) {
    this.selectedTifType = event;
    if (this.selectedTifType == Constant.CUSTOM_DATE)
      this.orderForm.controls['orderDate'].enable();
    else {
      this.orderForm.controls['orderDate'].setValue('');
      this.orderForm.controls['orderDate'].disable();
    }

  }
}
