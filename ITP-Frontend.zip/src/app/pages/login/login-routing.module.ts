import { NgModule } from '@angular/core';

@NgModule({
  imports: [
  ],
  declarations: [],
  providers: [],
  exports: [
  ]
})
export class LoginRoutingModule { }
