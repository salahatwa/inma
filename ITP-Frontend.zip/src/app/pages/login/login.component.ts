import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserIdleService } from 'angular-user-idle';
import { UtilsService } from '../../shared/services/utils.service';
import { UserService } from './../../core/services/user.service';
import { AlertService } from './../../shared/components/alert/alert.service';
import { RSAUtilsService } from './../../shared/services/rsautils.service';


@Component({
  selector: 'app-inma-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: []
})
export class LoginComponent {
  hide = true;
  title: String = '';
  isSubmitting = false;
  authForm: FormGroup;
  selectedLang: string = 'ar';

  constructor(
    private router: Router,
    private userService: UserService,
    private alertService: AlertService,
    private rsaUtil:RSAUtilsService,
    private fb: FormBuilder,
    private utilService: UtilsService, private userIdle: UserIdleService
  ) {
    this.utilService.setDocTitle('form.button.login', true);
    this.selectedLang = this.utilService.getCurrentLang();
  }

  ngOnInit() {
    this.userIdle.stopWatching();
    this.authForm = this.fb.group({
      'username': ['', Validators.required],
      'password': ['', Validators.required]
    });
  }

  submitForm() {
    this.isSubmitting = true;

    const credentials = this.authForm.value;
    this.rsaUtil.encrypt(credentials.password).subscribe(data=>{
      credentials.password=data;

      this.userService
      .attemptAuth(credentials)
      .subscribe(
        data => {
          this.router.navigate(['/dashboard']);
          this.utilService.setDocTitle('dashboard.title', false);
          this.isSubmitting = false;
          this.userIdle.startWatching();
        },
        err => {
          this.isSubmitting = false;
          this.alertService.error(err.message)
        }
      );
      
    },
    err=>{
      this.isSubmitting = false;
      this.alertService.error(err)
    });


   

  }

  switchLang() {
    this.selectedLang = this.utilService.getCurrentLang();
    if (this.selectedLang == "ar")
      this.selectedLang = this.utilService.setLang("en");
    else if (this.selectedLang == "en")
      this.selectedLang = this.utilService.setLang("ar");
  }

}
