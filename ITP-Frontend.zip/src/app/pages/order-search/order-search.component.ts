import { DatePipe, formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrderInquiryRequest, OrderInquiryResponse } from './../../core/models/models';
import { OrderList } from './../../core/models/OrderDetails';
import { OrderService } from './../../core/services/api';
import { AlertService } from './../../shared/components/alert/alert.service';
import { UtilsService } from './../../shared/services/utils.service';
import { Constant } from './../../shared/utils/constant';
import { CustomDateParserFormatter, CustomAdapter } from './../../shared/utils/date-util';
import { NgbDateParserFormatter, NgbDateAdapter, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { validateDate } from './../../shared/utils/validator';

@Component({
  selector: 'app-order-search',
  templateUrl: './order-search.component.html',
  styleUrls: ['./order-search.component.scss'],
  providers: [
    { provide: NgbDateAdapter, useClass: CustomAdapter },
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
    DatePipe
  ]
})
export class OrderSearchComponent implements OnInit {
  isSubmitting = false;
  alertId = { id: 'search-order-alert-un' };
  today=new Date();
  public maxDate = {year:this.today.getFullYear(),month: (this.today.getMonth()+1), day: this.today.getDate()};

  ordersInquiryForm: FormGroup;
  orderTrades: OrderList = {};


  orderInquiryRequest: OrderInquiryRequest;


  constructor(private utilService: UtilsService, private formBuilder: FormBuilder,
    private orderService: OrderService, private alertService: AlertService,
    private ngbCalendar: NgbCalendar, private dateAdapter: NgbDateAdapter<string>) {
    this.utilService.setDocTitle('profile.title', true);
  }

  ngOnInit(): void {
    this.buildForm();
  }

  clear() {
    this.ordersInquiryForm.reset();
    this.buildForm();
  }



  buildForm() {
    this.ordersInquiryForm = this.formBuilder.group({
      fromDate: [this.dateAdapter.toModel(this.ngbCalendar.getToday())],
      toDate: [this.dateAdapter.toModel(this.ngbCalendar.getToday())],
      orderSide: [''],
      orderStatus: [''],
      stockSymbol: [''],
      portfolioNum: [''],
      orderRefNum: [''],
      myOrders: [false]
    }, { validator: validateDate });
  }


  inquireOrders() {
    this.isSubmitting = true;
    this.orderInquiryRequest = {
      dtRange: {
        startDt: this.ordersInquiryForm.get('fromDate').value,
        endDt: this.ordersInquiryForm.get('toDate').value
      },
      orderSide: this.ordersInquiryForm.get('orderSide').value,
      ordStatus: this.ordersInquiryForm.get('orderStatus').value,
      stockSymbol: this.ordersInquiryForm.get('stockSymbol').value,
      portfolioNum: this.ordersInquiryForm.get('portfolioNum').value,
      ordRefNum: this.ordersInquiryForm.get('orderRefNum').value,
      recCtrlIn: {
        maxRecs: Constant.PAGINATION_MAX_RECS,
        offset: 0
      },
      myOrders: this.ordersInquiryForm.get('myOrders').value
    }

    // inquire  orders
    this.orderService.inquireOrders(this.orderInquiryRequest).pipe().subscribe(
      data => {
        let inquiryResponse: OrderInquiryResponse = data;
        this.orderTrades.ordersDetailsList = inquiryResponse?.ordersList;
        this.orderTrades.matchedRecs = inquiryResponse?.recCtrlOut?.matchedRecs;
        this.orderTrades.listType = Constant.ORDER_TRADES_LIST;
        this.orderTrades = JSON.parse(JSON.stringify(this.orderTrades));
        this.isSubmitting = false;
      },
      err => {
        this.isSubmitting = false;
        this.orderTrades.ordersDetailsList = [];
        this.orderTrades.matchedRecs = 0;
        this.orderTrades.listType = Constant.ORDER_TRADES_LIST;
        this.orderTrades = JSON.parse(JSON.stringify(this.orderTrades));
        this.alertService.error(err.message, this.alertId);
      }
    );
  }
}
