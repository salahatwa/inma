import { Component, OnDestroy, OnInit } from '@angular/core';
import { WebSocketService } from '../../shared/services/websocket.service';
import { StockDetails, Events, EventData } from './../../core/models/models';
import { EventBusService } from './../../core/services/event-bus.service';
import { Subscription } from 'rxjs';
import { UtilsService } from './../../shared/services/utils.service';

@Component({
  selector: 'app-live-prices',
  templateUrl: './live-prices.component.html',
  styleUrls: ['./live-prices.component.scss']
})
export class LivePricesComponent implements OnInit, OnDestroy {

  stockSubscribition: Subscription;
  
  stocks:StockDetails[]=[];



  constructor(private utilService:UtilsService,private webSocketService: WebSocketService,private eventBus:EventBusService) { }

  ngOnInit(): void {
    this.webSocketService._connect();
    this.stockDetailsListener();
  }


  
  /**
    * Listen to call back events from stock details component
   */
  stockDetailsListener() {
    this.stockSubscribition = this.eventBus.on(Events.GET_STOCK_DETAILS_WEBSOCKET, (result: EventData) => {
     
      if (!result.success) {
        return;
      }
      this.stocks=result.value;

      console.error(this.stocks);
      
    });
  }


  ngOnDestroy(): void {
    this.stockSubscribition.unsubscribe();
    this.webSocketService._disconnect();
  }



  connect() {
    this.webSocketService._connect();
  }


  sendMessage() {
    // this.webSocketService._send(this.name);
  }


  disconnect() {
    this.webSocketService._disconnect();
  }


  public getCompanyName(stock:StockDetails) {
    if (!stock)
      return '';

    if (this.utilService.getCurrentLang() == 'ar') {
      return stock.secArName;
    } else
      return stock.secEnName;
  }
}
