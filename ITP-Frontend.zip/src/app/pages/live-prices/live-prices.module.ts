import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LivePricesComponent } from './live-prices.component';
import { SharedModule } from './../../shared/modules/shared.module';
import { AuthModule } from './../../shared/services/auth/auth.module';



@NgModule({
  declarations: [LivePricesComponent],
  imports: [
    SharedModule,
    AuthModule,
    CommonModule
  ]
})
export class LivePricesModule { }
