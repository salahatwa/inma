import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/modules/shared.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { LayoutComponent } from './layout.component';
import { OrderSearchModule } from './order-search/order-search.module';
import { CustomerSearchModule } from './customer-search/customer-search.module';
import { LivePricesModule } from './live-prices/live-prices.module';

@NgModule({
  declarations: [LayoutComponent],
  imports: [
    SharedModule,
  ],exports:[
    LayoutComponent,
    DashboardModule,
    OrderSearchModule,
    CustomerSearchModule,
    LivePricesModule
  ]
})
export class LayoutModule { }
