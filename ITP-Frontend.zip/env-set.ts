// Configure Angular `environment.ts` file path
const writeFile = require('fs');


var targetPath = "";
var appEnv = process.argv[2];
var url = process.argv[3];
var envConfigFile = "";
var date = new Date();
var urlSuffix='api/v1';

console.log('Enviroment [' + appEnv + '] setting backend URL [' + url + ']');

if (url == undefined || url === null || url === ''||url==='%npm_config_url%') {
    console.log('Default enviroment picked up');
    url = 'http://localhost:9080/itp-core';
}


if (appEnv === "uat") {
    targetPath = './src/environments/environment.uat.ts';
    envConfigFile = `export const environment = {
        production: false,
        api: '${url}/${urlSuffix}',
        name:'itp_uat',
        description:'itp_uat_application ,last build time :${date}',
        version:'v1.0',
        sessionIdle:600,
        sessionTimeOut:10,
        sessionPing:120,
      };`;
}
else if (appEnv === "prod") {
    targetPath = './src/environments/environment.prod.ts';
    envConfigFile = `export const environment = {
        production: true,
        api: '${url}/${urlSuffix}',
        name:'itp_prod',
        description:'itp_prod_application ,last build time :${date}',
        version:'v1.0',
        sessionIdle:600,
        sessionTimeOut:10,
        sessionPing:120
    };`;
}

console.log('The file `environment.ts` will be written with the following content: \n');
console.log(envConfigFile);

writeFile.writeFile(targetPath, envConfigFile, function (err) {
    if (err) {
        throw console.error(err);
    } else {
        console.log(`Angular environment.ts file generated correctly at ${targetPath} \n`);
    }
});