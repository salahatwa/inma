const fs = require('fs');
const archiver = require('archiver');

const env=process.argv[2];
console.log('Building war for '+env+' enviroment');
// 1 or in dist folder run >> jar -cvf inma-itp-was.war *
const out = 'dist/itp_'+env+'_ui.war';

// 2
const output = fs.createWriteStream(out);
const archive = archiver('zip', {});

// 3
output.on('finish', () => {
    console.log('Packaging war (' + out + ') succeed ' + archive.pointer() + ' total bytes');
});

// 4
archive.pipe(output);

// 5
archive.bulk([{ expand: true, cwd: 'dist/inmainvest', src: ['**'], dest: '/'}]);

// 6
archive.finalize();