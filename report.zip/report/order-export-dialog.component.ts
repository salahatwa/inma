import { Component, Input, OnInit } from '@angular/core';
import { ExecutionInfoList, OrderDetails, OrderExport } from '@core/models/models';
import { OrderService } from '@core/services/order.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { AlertService } from '@shared/components/alert/alert.service';
import { UtilsService } from '@shared/services/utils.service';
import { Constant } from '@shared/utils/utility';
import { finalize } from 'rxjs/operators';

declare var html2pdf: any;

@Component({
  selector: 'app-order-export-dialog',
  templateUrl: './order-export-dialog.component.html',
  styleUrls: ['./order-export-dialog.component.scss']
})
export class OrderExportDialogComponent implements OnInit {

  alertId = { id: 'export-order-alert' };
  isLoading: boolean;

  curDate = new Date();

  @Input() order: OrderDetails;


  orderDtls: OrderExport;

  pageHeight = 200;

  constructor(private utilService: UtilsService, private orderService: OrderService, public activeModal: NgbActiveModal, private alertService: AlertService, private translateService: TranslateService) {
    this.addScript('./assets/js/html2pdf.bundle.js');
  }

  ngOnInit(): void {
    this.exportOrder();
  }

  addScript(url) {
    var script = document.createElement('script');
    script.type = 'application/javascript';
    script.src = url;
    document.head.appendChild(script);
  }

  exportOrder() {
    this.isLoading = true;
    this.orderService.exportOrder(this.order?.portfolioNum, this.order?.omsRefNum, this.order?.cif).pipe(finalize(() => {
      this.isLoading = false;
    })).subscribe((result) => {
      this.orderDtls = result;
    },
      err => {
        this.alertService.error(err.message, this.alertId);
      });
  }


  public downloadPDF(): void {
    var element = document.getElementById('htmlData');
    var opt = {
      margin: 0,
      filename: 'Order_' + this.order.omsRefNum + '.pdf',
      image: { type: 'jpeg', quality: 1 },
      html2canvas: { dpi: 95, scale: 5, letterRendering: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    html2pdf().from(element).set(opt).toPdf().get('pdf').then(function (pdf) {
      var totalPages = pdf.internal.getNumberOfPages();
      let i: number = 0;
      for (i = 1; i <= totalPages; i++) {
        pdf.setPage(i);

        this.pageHeight = pdf.internal.pageSize.getHeight();
      }


    }).save();


  }


  public copy(): void {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = Constant.clipboardMsg(this.order);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.alertService.success(this.translateService.instant('notify.copiedToCliboard'), this.alertId);
  }

  public getCompanyName(sec: OrderExport) {
    if (!sec?.etradeOrdDtlsDto)
      return '';
    if (this.utilService.getCurrentLang() == 'ar') {
      return sec.etradeOrdDtlsDto?.secShortNameAr;
    } else
      return sec.etradeOrdDtlsDto?.secShortNameEn;
  }


  public getOrderNetValue(exceutionInfo: ExecutionInfoList): number {
    let sum = 0;
    if (exceutionInfo?.executedAmount)
      sum += Number(exceutionInfo?.executedAmount);

    if (exceutionInfo?.bankCommission)
      sum += Number(exceutionInfo?.bankCommission);

    if (exceutionInfo?.marketCommission)
      sum += Number(exceutionInfo?.marketCommission);

    if (exceutionInfo?.taxInfo && exceutionInfo?.taxInfo?.taxAmt)
      sum += Number(exceutionInfo?.taxInfo?.taxAmt);

    return sum;
  }

  public getOrderTotalValue(exceutions: ExecutionInfoList[]): number {
    let sum = 0;
    if (exceutions)
      exceutions.forEach(exceutionInfo => {
        sum += this.getOrderNetValue(exceutionInfo);
      });

    return sum;
  }
}
