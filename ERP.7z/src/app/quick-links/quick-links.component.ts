import { QuickLinksService } from './quick-links.service';
import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-quick-links',
  templateUrl: './quick-links.component.html',
  styleUrls: ['./quick-links.component.scss']
})
export class QuickLinksComponent implements OnInit {
  linkList: any;
  message = '';
  showLoader = false;
  constructor(
    private readonly quickLinkService: QuickLinksService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit() {
    this.quickLinks();
  }
  quickLinks() {
    this.showLoader = true;
    this.quickLinkService.getQuickLinks().subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.linkList = response.keyValueSet;
        } else if (response.returnCode === '0') {
          this.message = response.returnMsg;
        }
      },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  openUrl(url) {
    window.open(url, '_blank');
  }
}
