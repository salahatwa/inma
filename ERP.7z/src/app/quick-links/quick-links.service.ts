import { Injectable } from '@angular/core';
import { CommonService } from '../shared/services/common.service';
import { UrlGeneratorService } from '../core/services/url-generator.service';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class QuickLinksService {
  constructor(
    private readonly common: CommonService,
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
  ) { }

  getQuickLinks(): Observable<any> {
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: userDetails.userName,
      language: this.common.getRequestLanguage(),
    };
    const url = this.url.getQuickLinkUrl();
    return this.http.post<any>(url, data);
  }
}
