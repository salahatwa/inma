import { CommonService } from '../shared/services/common.service';
import { Component, OnInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from './login.service';
import * as CryptoJS from '../../assets/AES/aes.js';
import { aesEnc } from '../shared/constants/globalConstants';
const encParam = aesEnc.first + aesEnc.second;
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  toast: any;
  language = 'en';
  formsubmit = false;
  invalidCredentials = false;
  showLoader = false;
  errorMsg: String;
  constructor(
    private readonly router: Router,
    private readonly formBuilder: FormBuilder,
    private loginService: LoginService,
    private readonly common: CommonService,
    public translate: TranslateService,
    private renderer: Renderer2
  ) {
    const token = localStorage.getItem('authToken');
    if (token && token !== null) {
      this.router.navigate(['/dashboard']);
    }
  }

  ngOnInit() {
    this.language = this.common.getLanguage();
    this.loginForm = this.formBuilder.group({
      userIdentifier: '',
      secretWord: ''
    });
  }
  login() {
    if (localStorage.getItem('authToken') && localStorage.getItem('userDetails')) {
      const toast = {
        'show': true,
        'status': 'failed',
        'message': 'Please logout from other tabs and try again'
      };
      this.common.showToast(toast);
      return false;
    }
    this.formsubmit = true;
    if (this.loginForm.valid) {
      this.common.setLanguage(this.language);
      this.showLoader = true;
      const cred = {
        parameter1: '',
        parameter2: '',
        deviceId: 'web',
        language: '',
      };
      const key = CryptoJS.enc.Hex.parse(encParam);
      // tslint:disable-next-line: max-line-length
      const encryptedUname = CryptoJS.AES.encrypt(this.loginForm.value.userIdentifier, key, { format: String, mode: CryptoJS.mode.ECB });
      // tslint:disable-next-line: max-line-length
      const encryptedPass = CryptoJS.AES.encrypt(this.loginForm.value.secretWord, key, { format: String, mode: CryptoJS.mode.ECB });
      const usernameEnc = encryptedUname.ciphertext.toString(CryptoJS.enc.Base64);
      const passwordEnc = encryptedPass.ciphertext.toString(CryptoJS.enc.Base64);
      cred.parameter1 = usernameEnc;
      cred.parameter2 = passwordEnc;
     // this.loginForm.controls.password.setValue(passwordEnc);
      cred.language = '';
      let language = 'AMERICAN';
      if (localStorage.getItem('language')) {
        const localLanguage = localStorage.getItem('language');
        if (localLanguage === 'ar') {
          language = 'ARABIC';
        }
      }
      cred.language = language;
      this.loginService.login(cred).subscribe(
        (response) => {
          // this.loginForm.controls.password.setValue('');
          if (response.returnCode === '0') {
            this.invalidCredentials = false;
            response.userDetailsTab[0].userName = this.loginForm.value.userIdentifier.toUpperCase();
            response.userDetailsTab[0].hrFlag = response.hrFlag;
            const value = JSON.stringify(response.userDetailsTab[0]);
            localStorage.setItem(
              'authToken',
               JSON.stringify({ 'accessToken': response.accessToken, 'refreshToken': response.refreshToken })
              );
              localStorage.setItem('userDetails', value);
              setTimeout(() => {
                this.router.navigate(['/dashboard']);
              }, 1);
          } else if (response.returnCode === '1') {
            localStorage.setItem('language', '');
            this.common.setLanguage(this.language);
            this.loginForm.reset();
            this.formsubmit = false;
            this.invalidCredentials = true;
            this.errorMsg = response.returnMsg;
          } else if (response.returnCode === '2') {
            localStorage.setItem('language', '');
            this.invalidCredentials = true;
            this.loginForm.reset();
            this.formsubmit = false;
            this.errorMsg = response.returnMsg;
          }
          this.showLoader = false;
        },
        (error) => {
          localStorage.setItem('language', '');
          this.showLoader = false;
        }
      );
    }
  }
  forgotPassword() {
    if(this.language === 'ar')
    window.open('http://usierp02.alinma.local:8000/OA_HTML/RF.jsp?function_id=28891&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=AR&params=Xx62lF9yqVz0ym8xEGSccwp0FD7LSCUHeVIgk4DVRvVwliNodL5DsOYv-Mnj4GSsCdTJ34k73xwEFD3CLI9S5TZrayxywtSyDna-o4Iov6riNJbxhc47ytcXQSiPGB.1QHOGLOnR7BQfanvXKTsO.BCOu2JcFqckv99oPR22Vbm0cSLVRrvKeR6iRaxX-TPvi0Gv9imoi8m.3W7.nKc.koyh9jLghzCoRbc7yggmxLhOPGfbooomMN6cpdMEYeifwnCpUe8tJVz-kebQtuD626-7e0TtwIIrH8wOoZ57i9Q&oas=evTkLRkihajsF0p6MhM_yQ', '_blank');
    else {
      window.open('http://usierp02.alinma.local:8000/OA_HTML/RF.jsp?function_id=28891&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&params=Xx62lF9yqVz0ym8xEGSccwp0FD7LSCUHeVIgk4DVRvVwliNodL5DsOYv-Mnj4GSsCdTJ34k73xwEFD3CLI9S5TZrayxywtSyDna-o4Iov6riNJbxhc47ytcXQSiPGB.1QHOGLOnR7BQfanvXKTsO.BCOu2JcFqckv99oPR22Vbm0cSLVRrvKeR6iRaxX-TPvi0Gv9imoi8m.3W7.nKc.koyh9jLghzCoRbc7yggmxLhOPGfbooomMN6cpdMEYeifwnCpUe8tJVz-kebQtuD626-7e0TtwIIrH8wOoZ57i9Q&oas=evTkLRkihajsF0p6MhM_yQ', '_blank');
    }
  }
  translateLang(language) {
    this.language = language;
    if (language === 'ar') {
      this.renderer.addClass(document.body, 'arabic');
    } else {
      this.renderer.removeClass(document.body, 'arabic');
    }
    this.translate.use(language);
  }
}
