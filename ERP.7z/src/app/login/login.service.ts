import { Injectable } from '@angular/core';
import { ApiServiceService } from '../shared/api-service.service';
import { HttpClient } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { UrlGeneratorService } from '../core/services/url-generator.service';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(
    private apiServiceService: ApiServiceService,
    private url: UrlGeneratorService,
    private http: HttpClient
  ) { }

  login(data): Observable<any> {
    const url = this.url.getLoginUrl();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }


}
