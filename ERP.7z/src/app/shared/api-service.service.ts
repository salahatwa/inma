import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  constructor(private readonly http: HttpClient) {
  }
  /**
  * @desc set headers for the api calls.
  */
  public getHeader() {
    const header = {
      'Content-Type': 'application/json', // for post and put only
    };
    return header;
  }
  /**
		* @desc Execute the post method.
		* @param apiUrl url of the api to be called.
		* @param requestBody requestbody to be set to the api.
		* @param successCallback succes callback for the api call function.
		* @param failureCallback failure callback for the api call function.
		*/
  public ExecutePost(apiUrl, requestBody, successCallback, failureCallback, Header = this.getHeader()) {
    this.http.post(apiUrl, requestBody, { headers: Header }).subscribe(response => {
      successCallback(response);
    }, error => {
      failureCallback(error);
    });
  }
/**
 * @desc Execute the get method.
 * @param apiUrl url of the api to be called.
 * @param requestBody requestbody to be set to the api.
 * @param successCallback succes callback for the api call function.
 * @param failureCallback failure callback for the api call function.
 */
  public ExecuteGet(apiUrl, successCallback, failureCallback, Header = this.getHeader()) {
    this.http.get(apiUrl, { headers: Header }).subscribe(response => {
      successCallback(response);
    }, error => {
    });
  }
}
