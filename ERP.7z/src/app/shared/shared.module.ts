import { ClickOutsideModule } from 'ng4-click-outside';
import { EditPersonalInfoComponent } from './../myprofile/personal-info/edit-personal-info/edit-personal-info.component';
import { ReturnLeaveComponent } from './../leave-management/return-leave/return-leave.component';
import { AddRequestComponent } from './../employee-request/add-request/add-request.component';
import { RequestDetailsComponent } from './../employee-request/request-details/request-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HasValueDirective } from './directives/has-value.directive';
import { NgModule } from '@angular/core';
import { SideNavComponent } from './side-nav/side-nav.component';
import { HeaderComponent } from './header/header.component';
import { CommonModule, DatePipe } from '@angular/common';
import { AddAttachmentComponent } from './add-attachment-dialog/add-attachment.component';
import { RouterModule } from '@angular/router';
import { AttachmentDetailDialogComponent } from './attachment-detail-dialog/attachment-detail-dialog.component';
import { LoaderComponent } from './loader/loader.component';
import { TranslateModule } from '@ngx-translate/core';
import { AttachmentViewComponent } from './attachment-view/attachment-view.component';
import { CustomTimePickerComponent } from 'src/app/shared/custom-time-picker/custom-time-picker.component';
import { MoreInfoComponent } from './more-info/more-info.component';
import { PersonalInfoComponent } from '../myprofile/personal-info/personal-info.component';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { FilterPipe } from './custom-pipes/filter.pipe';
import { CreateReturnLeaveComponent } from '../leave-management/return-leave/create-return-leave/create-return-leave.component';
import { AddDependentComponent } from '../myprofile/personal-info/add-dependent/add-dependent.component';
import { AbsenceSummaryComponent } from '../leave-management/absence-summary/absence-summary.component';
import { CreateAbsenceComponent } from '../leave-management/absence-summary/create-absence/create-absence.component';
import { MyDatePickerModule } from 'mydatepicker';
import { FormActionDirective } from './directives/form-action.directive';
import { PerformanceComponent } from '../performance/performance.component';
import { PerformanceDetailComponent } from '../performance/performance-detail/performance-detail.component';
import { TrackEmployeeObjectiveComponent } from '../performance/track-employee-objective/track-employee-objective.component';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    MyDatePickerModule,
    ClickOutsideModule,
    NgxMyDatePickerModule.forRoot()
  ],
  providers: [DatePipe],
  declarations: [
    SideNavComponent,
    HeaderComponent,
    AddAttachmentComponent,
    AttachmentDetailDialogComponent,
    HasValueDirective,
    LoaderComponent,
    AttachmentViewComponent,
    CustomTimePickerComponent,
    MoreInfoComponent,
    FilterPipe,
    RequestDetailsComponent,
    AddRequestComponent,
    CreateReturnLeaveComponent,
    ReturnLeaveComponent,
    PersonalInfoComponent,
    EditPersonalInfoComponent,
    AddDependentComponent,
    AbsenceSummaryComponent,
    CreateAbsenceComponent,
    FormActionDirective,
    PerformanceComponent,
    PerformanceDetailComponent,
    TrackEmployeeObjectiveComponent
  ],
  exports: [
    SideNavComponent,
    HeaderComponent,
    CommonModule,
    AddAttachmentComponent,
    AttachmentViewComponent,
    AttachmentDetailDialogComponent,
    HasValueDirective,
    LoaderComponent,
    TranslateModule,
    CustomTimePickerComponent,
    MoreInfoComponent,
    RequestDetailsComponent,
    AddRequestComponent,
    CreateReturnLeaveComponent,
    ReturnLeaveComponent,
    PersonalInfoComponent,
    EditPersonalInfoComponent,
    AddDependentComponent,
    AbsenceSummaryComponent,
    CreateAbsenceComponent,
    ClickOutsideModule,
    FilterPipe,
    FormActionDirective,
    PerformanceComponent,
    PerformanceDetailComponent,
    TrackEmployeeObjectiveComponent
  ],
})
export class SharedModule { }
