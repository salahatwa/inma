import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {
  userName = '';
  userDetails: any;
  userData: any;
  profileImg = 'assets/images/user-default.svg';
  logoutConfirm = false;
  userImageUrl = '';
  userImage: string;
  constructor(private readonly common: CommonService) {}
  ngOnInit() {
    this.userDetails =  this.common.getUserDetails();
    this.userName = this.userDetails.fullName;
    this.getUserImage();

    this.userImageUrl =
      'https://www.alinma.com/EmpPic/Human_Resources/EmployeePictures/Thumbs/' +
      this.userDetails.employeeNumber +
      '.jpg';
  }
  getUserImage() {
    this.userImage =
      'https://portal:6060/User%20Photos/Profile%20Pictures/ME_hmsaleh_LThumb.jpg';
  }
  logoutAlert() {
    this.logoutConfirm = true;
  }
  logout() {
    this.common.logout();
    this.logoutConfirm = false;
  }
  cancelAlert() {
    this.logoutConfirm = false;
  }
}
