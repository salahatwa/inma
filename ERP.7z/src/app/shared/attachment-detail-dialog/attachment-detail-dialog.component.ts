import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LeaveSummaryService } from 'src/app/leave-management/data-service/leave-summary.service';
import { saveAs } from 'file-saver';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-attachment-detail-dialog',
  templateUrl: './attachment-detail-dialog.component.html',
  styleUrls: ['./attachment-detail-dialog.component.scss']
})
export class AttachmentDetailDialogComponent implements OnInit {
  @Input() popupData: any;
  @Output() closeAttachment = new EventEmitter();
  constructor(
    private readonly leaveSummaryService: LeaveSummaryService,
    private readonly common: CommonService,
  ) { }

  ngOnInit() {
  }
  attachmentClose() {
    this.closeAttachment.next(false);
  }
  getaddAttachment(mediaId) {
    this.leaveSummaryService.getaddAttachment(mediaId).subscribe(
      (response) => {
        if (response.returnCode === '0') {
          this.saveFileInLocal(response);
        }
      },
      (error) => {
      }
    );
  }
  saveFileInLocal(file) {
      const blob = this.common.createBlob(file);
      saveAs(blob, file.fileName);
  }

}
