import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-custom-time-picker',
  templateUrl: './custom-time-picker.component.html',
  styleUrls: ['./custom-time-picker.component.scss']
})
export class CustomTimePickerComponent implements OnInit {
  @Input()
  timePickerData: any;

  @Output()
  emitTimePickerEvent = new EventEmitter();

  selectedHr;
  selectedMin;
  hoursList = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'];
  minsList = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59'];
  constructor() {


  }

  ngOnInit() {
    if (this.timePickerData && this.timePickerData.time) {
      const timeVar = this.timePickerData.time.split(':');
      this.selectedHr = timeVar[0];
      this.selectedMin = timeVar[1];
    }
  }
  selectHr(hr) {
    this.selectedHr = hr;
  }
  selectMin(min) {
    this.selectedMin = min;
  }
  okClicked() {
    this.timePickerData.event = 'ok';
    this.timePickerData.time = this.selectedHr +  ':' + this.selectedMin;
    this.emitTimePickerEvent.next(this.timePickerData);
  }
  cancelClicked() {
    this.timePickerData.event = 'cancel';
    this.timePickerData.time = this.selectedHr +  ':' + this.selectedMin;
    this.emitTimePickerEvent.next(this.timePickerData);
  }
}
