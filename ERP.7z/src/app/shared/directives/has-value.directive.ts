import { Directive, ElementRef, Renderer2, DoCheck, Input, OnChanges, HostListener } from '@angular/core';

@Directive({
  selector: '[appHasValue]'
})
export class HasValueDirective {
  // @Input() appHasValue;
  constructor(public el: ElementRef, public renderer: Renderer2) { }

  @HostListener('change') onChange() {
    if (this.el.nativeElement.value.length) {
      this.renderer.addClass(this.el.nativeElement.parentElement, 'has-value');
    } else {
      this.renderer.removeClass(this.el.nativeElement.parentElement, 'has-value');
    }
  }
}
