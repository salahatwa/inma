import { Directive, ElementRef, Renderer2, HostListener } from '@angular/core';

@Directive({
  selector: '[appFormAction]'
})
export class FormActionDirective {

  constructor(public el: ElementRef, public renderer: Renderer2) {
    const dynamicEndPoint = window.location.origin;
    if (dynamicEndPoint) {
          this.el.nativeElement.setAttribute('action', dynamicEndPoint);
    }
  }

}
