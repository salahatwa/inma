export const ConstantProvider = {
  FAILURE_MESSAGE: 'Something went wrong, please try after some time',
  REQUEST_SUCCESS: 'Request Created',
  DATE_FROMAT: 'dd-mmm-yyyy'
};
export const ToastFailed = {
  'show': true,
  'status': 'failed',
  'message': ConstantProvider.FAILURE_MESSAGE
};
export const ToastSuccess = {
  'show': true,
  'status': 'success',
  'message': ''
};
export const localStorageKey = {
  LANGUAGE: 'language',
  AUTH_TOKEN: 'authToken',
  HAS_ACTION: 'hasAction',
  ABSENCE_DETAILS: 'absenceDetails',
  PERSONAL_INFO: 'personalInfo',
  DEPENDANT: 'dependent'
};
export const aesEnc = {
  'first' : '788becf1635547f5',
  'second' : '9321b3f1a6f0ef28'
};
