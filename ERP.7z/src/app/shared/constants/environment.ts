import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvironmentProvider {
  public env = '';
  public baseURL = '';

  constructor() {
    const dynamicEndPoint = window.location.origin;
    this.env = 'AlinmaDynamic';
    switch (this.env) {
      case 'RVSDev':
        this.baseURL = 'http://192.168.4.12:9080';
        break;
      case 'AlinmaDev':
        this.baseURL = 'http://10.0.2.119:9083';
        break;
      case 'AlinmaUAT':
        this.baseURL = 'https://www.alinmauat.com/erp';
        break;
      case 'AlinmaDynamic':
        this.baseURL = dynamicEndPoint;
        break;
      case 'Monipally':
        this.baseURL = 'http://172.16.10.164:8080';
        break;
      case 'TokenRvs':
        this.baseURL = 'http://192.168.4.12:9080/token';
        break;
      case 'TokenAlinma':
        this.baseURL = 'http://10.0.2.119:9083/token';
        break;
      case 'Prod':
        this.baseURL = '';
        break;
    }
  }
}
