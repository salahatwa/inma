import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute, ActivationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  constructor(
    private readonly route: Router,
    private readonly router: ActivatedRoute,
    private readonly common: CommonService
  ) {
    /*this.route.events.subscribe(val => {
      if (this.router.snapshot.firstChild) {
        this.pageTitle = this.router.snapshot.firstChild.data.title;
        console.log(this.router.snapshot);
      }
    });*/
    this.route.events.pipe(
      filter(event => event instanceof ActivationEnd && event.snapshot.children.length === 0)).
      subscribe((event: ActivationEnd) => {
        this.pageTitle = event.snapshot.data.title;
      }
      );
  }

  public pageTitle: string;

  ngOnInit() {
    if (this.route.url === '/dashboard') {
      this.pageTitle = 'Dashboard';
    }
  }
}
