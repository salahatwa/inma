import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-attachment-view',
  templateUrl: './attachment-view.component.html',
  styleUrls: ['./attachment-view.component.scss']
})
export class AttachmentViewComponent implements OnInit {
  @Input() baseValue: any;
  @Output() cancel = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }
  attachDismiss() {
    this.cancel.next(false);

  }


}
