import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, Observable } from 'rxjs';
import { MonthSmall } from '../constants/month.constants';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  selectedSubordinate: any = {};
  language = '';
  private selectedUser = '';
  selectedFullName = '';
  private selectedUserId = '';
  private toastSubject = new Subject<any>();
  private deactivateSubject$ = new Subject<any>();
  selectedPlanDetails: any = {}
  constructor(
    private readonly router: Router,
  ) { }

  getUserDetails() {
    if (localStorage.getItem('userDetails')) {
      return (JSON.parse(localStorage.getItem('userDetails')));
    } else {
      return false;
    }
  }
  logout() {
    this.language = this.getLanguage();
    this.deactivateSubject$.next(true);
    if (localStorage.getItem('userDetails')) {
      localStorage.clear();
      this.setLanguage(this.language);
    }
    this.router.navigate(['/login']);
  }
  makeFormAsPrestine(): Observable<any> {
    return this.deactivateSubject$.asObservable();
  }
  showToast(toast) {
    this.toastSubject.next(toast);
  }
  getToast(): Observable<any> {
    return this.toastSubject.asObservable();
  }
  setLanguage(language) {
    localStorage.setItem('language', language);
  }
  getLanguage() {
    if (localStorage.getItem('language')) {
      return localStorage.getItem('language');
    }
  }
  formatDate(date): string {
    let formattedDate = '';
    const dateArray = date.split('-');
    if (!isNaN(dateArray[1])) {
      formattedDate = `${dateArray[1]}-${dateArray[0]}-${dateArray[2]}`;
    } else {
      formattedDate = date;
    }
    return formattedDate;
  }
  getAccessToken() {
    if (localStorage.getItem('authToken')) {
      return JSON.parse(localStorage.getItem('authToken')).accessToken;
    }
  }
  getRefreshToken() {
    if (localStorage.getItem('authToken')) {
      return JSON.parse(localStorage.getItem('authToken')).refreshToken;
    } else {
      this.logout();
    }
  }
  setUserIdForMngrAction(userId) {
    this.selectedUserId = userId;
    localStorage.setItem('selectedUserId', '');
    localStorage.setItem('selectedUserId', userId);
  }
  getUserIdForMngrAction() {
    let userName = '';
    if (this.selectedUserId) {
      userName = this.selectedUserId;
    } else if (localStorage.getItem('selectedUserId')) {
      userName = localStorage.getItem('selectedUserId');
    } else {
      userName = '';
    }
    return userName;
  }
  setUserNameForMngrAction(userName, fullName?) {
    this.selectedFullName = fullName;
    this.selectedUser = userName;
    localStorage.setItem('selectedUser', '');
    localStorage.setItem('selectedUser', userName);
    localStorage.setItem('selectedUserName', fullName);
  }
  getUserNameForMngrAction() {
    let userName = '';
    if (localStorage.getItem('selectedUser')) {
      userName = localStorage.getItem('selectedUser');
    } else {
      userName = '';
    }
    return userName;
  }
  getFullName() {
    if (localStorage.getItem('selectedUserName')) {
      return localStorage.getItem('selectedUserName');
    } else {
      return '';
    }
  }
  getPLanDetails() {
    if (localStorage.getItem('plan')) {
      return JSON.parse(localStorage.getItem('plan'));
    } else {
      return '';
    }
  }
  createBlob(file) {
    // tslint:disable-next-line:no-unused-expression
    'use strict';
    const b64toBlob = (b64Data, contentType = '', sliceSize = 512) => {
      const byteCharacters = atob(b64Data);
      const byteArrays = [];
      for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
        const slice = byteCharacters.slice(offset, offset + sliceSize);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
          byteNumbers[i] = slice.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
      }
      const blob = new Blob(byteArrays, { type: contentType });
      return blob;
    };
    const contentType = file.fileContentType;
    const b64Data = file.fileData;
    return b64toBlob(b64Data, contentType);
  }
  getRequestLanguage() {
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    return language;
  }
  formatDateToMMDDYYYY(date): string {
    let formattedDate = '';
    const dateArray = date.split('-');
    formattedDate = `${MonthSmall[dateArray[1]]}-${dateArray[0]}-${dateArray[2]}`;

    return formattedDate;
  }
}
