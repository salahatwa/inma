import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-add-attachment-dialog',
  templateUrl: './add-attachment.component.html',
  styleUrls: ['./add-attachment.component.scss']
})
export class AddAttachmentComponent implements OnInit {
  @Output() fileSelected = new EventEmitter();
  @Output() cancel = new EventEmitter();
  @Input() radio = false;
  title: string;
  comments = '';
  fileChoosed: any;
  url: string;
  attachmentType: string;
  showPopup = true;
  radioType = 'file';
  constructor() { }

  ngOnInit() {
  }
  onFileChange(event) {
    this.readFile(event.target);
  }
  readFile(inputFile: any): void {
    const file: File = inputFile.files[0];
    const fileReader: FileReader = new FileReader();
    fileReader.onload = () => {
      const base64File = fileReader.result;
      let extension: any = file.name.split('.');
      extension = extension[extension.length - 1];
      this.fileChoosed = {
        'attachmentName': file.name,
        'attachment': file.name,
        'fileData': (<string>base64File).split(',')[1],
        'fileDataFull': base64File,
        'attachmentType': file.type,
        'mediaId': null,
        'size': file.size,
        'extention': extension
      };
    };
    if (file) {
      fileReader.readAsDataURL(file);
    }
    if (file.size > 3000000) {
      this.fileChoosed = '';
    }
  }
  addSelectedFile() {
    if (this.fileChoosed && this.fileChoosed.fileData) {
      this.fileChoosed.title = this.title;
      this.fileChoosed.comments = this.comments;
      this.fileSelected.emit(this.fileChoosed);
      this.fileChoosed = '';
      this.title = '';
      this.comments = '';
    }
  }
  popupAction(event) {
    this.attachmentType = event;
    this.showPopup = false;
  }
  cancelAttachment() {
    this.cancel.next(false);
  }
  deleteAttachment() {
    this.fileChoosed = '';
  }
}
