import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyprofileComponent } from './myprofile.component';
import { PersonalInfoComponent } from './personal-info/personal-info.component';
import { EmploymentComponent } from './employment/employment.component';
import { SalaryComponent } from './salary/salary.component';
import { PayslipComponent } from './payslip/payslip.component';
import { PassportComponent } from './passport/passport.component';
import { EmergencyContactComponent } from './emergency-contact/emergency-contact.component';
import { AddDependentComponent } from './personal-info/add-dependent/add-dependent.component';
import { CanDeactivateGuard } from './../shared/services/can-deactivate-guard.service';
import { EditPersonalInfoComponent } from './personal-info/edit-personal-info/edit-personal-info.component';
import { AddPassportComponent } from './passport/add-passport/add-passport.component';
import { AddEmergencyContactComponent } from './emergency-contact/add-emergency-contact/add-emergency-contact.component';
import { AuthGuardService as AuthGuard } from './../core/services/auth-guard.service';

const routes: Routes = [
  {
    path: '', component: MyprofileComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'personal-info', pathMatch: 'full' },
      { path: 'personal-info', component: PersonalInfoComponent, data: { title: 'My Profile' } },
      { path: 'employment', component: EmploymentComponent, data: { title: 'My Profile' } },
      { path: 'salary', component: SalaryComponent, data: { title: 'My Profile' } },
      { path: 'payslip', component: PayslipComponent, data: { title: 'My Profile' } },
      { path: 'passport', component: PassportComponent, data: { title: 'My Profile' } },
      { path: 'emergency-contact', component: EmergencyContactComponent, data: { title: 'My Profile' } }
    ]
  },
  { path: 'personal-info/add-dependent', component: AddDependentComponent, canDeactivate: [CanDeactivateGuard] },
  { path: 'personal-info/edit-personal-info', component: EditPersonalInfoComponent, canDeactivate: [CanDeactivateGuard] },
  { path: 'add-passport', component: AddPassportComponent, canDeactivate: [CanDeactivateGuard] },
  { path: 'add-emergency-contact', component: AddEmergencyContactComponent, canDeactivate: [CanDeactivateGuard] }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MyprofileRoutingModule { }
