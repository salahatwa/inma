import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { EmploymentService } from '../data-services/employment.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-employment',
  templateUrl: './employment.component.html',
  styleUrls: ['./employment.component.scss']
})
export class EmploymentComponent implements OnInit, OnDestroy {
  showLoader = false;
  employmentDetails = [];
  showAddPassport: false;
  subscription$: Subscription;
  router: any;
  constructor(
    private employmentService: EmploymentService,
    private common: CommonService
  ) { }

  ngOnInit() {
    this.employment();
  }

  employment() {
    this.showLoader = true;
    const userName = this.common.getUserDetails().userName;

    const data = {
      'userName': userName
    };
    this.subscription$ = this.employmentService.employment(data).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.employmentDetails = response.employementDetailsTab;
          this.employmentDetails.map(function (item) {
            item.place = item.location;
          })
        }
      },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  ngOnDestroy(): void {
    this.subscription$.unsubscribe();
  }
}
