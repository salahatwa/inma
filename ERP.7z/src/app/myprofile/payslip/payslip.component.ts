import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { PayslipService } from '../data-services/payslip.service';
import { CommonService } from '../../shared/services/common.service';

@Component({
  selector: 'app-payslip',
  templateUrl: './payslip.component.html',
  styleUrls: ['./payslip.component.scss']
})
export class PayslipComponent implements OnInit {
  showPaySlip = false;
  showLoader = false;
  payslipDate = [];
  payslipDetail = [];
  selectedDate: string;
  totalEarnings = 0;
  totalDeduction = 0;
  totalPay = 0;
  employeeSummaryTab = [];
  payslipEarningTab = [];
  payslipDeductionTab = [];
  payslipElementTab = [];
  payslipBalancesTab = [];
  payslipAccruralTab = [];
  subscription$: Subscription;
  public myForm: FormGroup;
  selectedPayslip: boolean;
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly payslipData: PayslipService,
    private readonly common: CommonService
  ) { }

  ngOnInit() {
    this.getpayslipDate();
  }

  getpayslipDate() {
    this.showLoader = true;
    const userDetails = this.common.getUserDetails();
    const data = {
      'userName': userDetails.userName,
      'language': ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    this.subscription$ = this.payslipData.getpaySlipDateList(data).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        this.payslipDate = response.payslipDates;
      } else {
        this.payslipDate = [];
      }

    },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  getPayslipDetail(date) {
    this.selectedDate = date;
    this.showLoader = true;
    this.totalEarnings = 0;
    this.totalDeduction = 0;
    this.totalPay = 0;
    const userDetails = this.common.getUserDetails();
    const data = {
      'userName': userDetails.userName,
      'pDate': date,
      language: ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    this.subscription$ = this.payslipData.getpaySlipDetail(data).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        this.showPaySlip = true;
        this.employeeSummaryTab = response.employeeSummaryTab;
        this.payslipEarningTab = response.payslipEarningTab;
        this.payslipDeductionTab = response.payslipDeductionTab;
        this.payslipElementTab = response.payslipElementTab;
        this.payslipBalancesTab = response.payslipBalancesTab;
        this.payslipAccruralTab = response.payslipAccruralTab;
        this.payslipDetail = response.payslipPaymentTab;
        if (this.payslipEarningTab) {
          this.payslipEarningTab.forEach((value) => {
            this.totalEarnings = this.totalEarnings + value.ammount;
          });
        }
        if (this.payslipDeductionTab) {
          this.payslipDeductionTab.forEach((value) => {
            this.totalDeduction = this.totalDeduction + value.ammount;
          });
        }
        this.totalPay = this.totalEarnings - this.totalDeduction;
      } else {
        this.payslipDetail = [];
      }
    },
      (error) => {
        this.showLoader = false;
      }
    );
  }

  changePayslip(payslipValue) {
    this.selectedPayslip = true;
    this.getPayslipDetail(payslipValue);
  }
}
