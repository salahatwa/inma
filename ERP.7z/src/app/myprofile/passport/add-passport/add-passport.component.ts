import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Subject, Observable } from 'rxjs';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { FormGroup, FormBuilder, Validators, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RequestMetaService } from 'src/app/employee-request/data-services/request-meta.service';
import { SubmitRequestService } from 'src/app/employee-request/data-services/submit-request.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-passport',
  templateUrl: './add-passport.component.html',
  styleUrls: ['./add-passport.component.scss']
})
export class AddPassportComponent implements OnInit, OnDestroy {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  myOptions1: INgxMyDpOptions = {
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'su'
  };
  language = '';
  formSbmitted = true;
  reqName = '';
  moreInfo = false;
  errorMsg = '';
  backConfirm = false;
  confirm$: Subject<boolean> = new Subject<boolean>();
  formattedDate: string;
  attachmetReq = '';
  metaDataSubscription$: Subscription;
  saveRequestSubscription$: Subscription;
  dependentSubscription$: Subscription = new Subscription();
  private approverSubscription$: Subscription;
  requestForm: FormGroup;
  approverList = [];
  transactionId = '';
  showLoader = false;
  formDetails: { [k: string]: any } = {};
  metaData: any;
  validationMessage = '';
  showAddAttachment = false;
  uploadedFile = [];
  currentIndex: number;
  requestType: string;
  requestCode: string;
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly router: Router,
    private readonly metaService: RequestMetaService,
    private readonly reqSubmitService: SubmitRequestService,
    private readonly common: CommonService,
    private readonly datePipe: DatePipe
  ) { }

  ngOnInit() {
    this.requestType = 'EIT';
    this.requestCode = 'SA_PASSPORT';
    this.getSitEitMetaData();
    this.language = this.common.getLanguage();
  }
  /**
   * @desc this method is used to get the data for populating the form fields in create employee request
   */
  getSitEitMetaData() {
    this.showLoader = true;
    this.metaDataSubscription$ = this.metaService
      .getRequestMetaData(this.requestType, this.requestCode)
      .subscribe(
        response => {
          this.showLoader = false;
          if (response.returnCode === '0') {
            this.attachmetReq = response.attachementFlag;
            this.reqName = response.requestName;
            this.metaData = response.sitEitMetaDataTab;
            this.metaData.forEach(element => {
              element.hasValue = false;
              if (element.is_mandatory === 'N') {
                this.formDetails[element.application_column_name] = '';
              } else {
                this.formDetails[element.application_column_name] = [
                  '',
                  Validators.required
                ];
              }
            });
            // this.formDetails['userComments'] = '';
            this.requestForm = this.formBuilder.group(this.formDetails);
            this.metaData.forEach(element => {
              if (element.defaultValue && element.column_type !== 'DATE') {
                this.requestForm.controls[element.application_column_name].setValue(element.defaultValue);
                element.hasValue = true;
              } else if (element.defaultValue && element.defaultValue !== null && element.column_type === 'DATE') {
                this.requestForm.controls[element.application_column_name].setValue(element.defaultValue);
              }
            });
          }
        },
        () => {
          this.showLoader = false;
        }
      );
  }
  /**
   * @desc method to dynamically handle back in breadcrumbs
   */
  goBack() {
    this.router.navigate(['/myprofile/passport']);
  }
  /**
   * @decs method to get metadata of dependent fields of the clicked or changed field
   * @param index index of the clicked field metadata
   * @param event event to be passed in case of date picker as change is not detected in formgroup
   */
  checkForNextDependent(index: number, event?) {
    let currentDate;
    this.currentIndex = index;
    /**
     * event is checked in the case of date picker to get selected date
     */
    if (event) {
      if (event.date.year === 0) {
        currentDate = '';
      } else {
        if (event.date.month.toString().length === 1) {
          event.date.month = `0${event.date.month}`;
        }
        if (event.date.day.toString().length === 1) {
          event.date.day = `0${event.date.day}`;
        }
        currentDate = `${event.date.year}-${event.date.month}-${
          event.date.day
          } 00:00:00`;
      }
    }
    /**
     * to add class on datepicker input based on value
     */
    if (this.metaData[index].column_type === 'DATE' && event.date.year) {
      this.metaData[index].hasValue = true;
    } else if (
      this.metaData[index].column_type === 'DATE' &&
      !event.date.year
    ) {
      this.metaData[index].hasValue = false;
    }
    /**
     * loop over the fields from selected field to check dependent fields
     */
    if (this.metaData) {
      for (let i = index + 1; i < this.metaData.length; i++) {
        if (this.metaData[i].dependent_value_set_exists === 'Y') {
          const data = this.getPreviousFieldData(i, currentDate);
          this.dependentSubscription$.add(this.metaService.getDependentFlexValueSet(data).subscribe(
            response => {
              if (response.returnCode === '0') {
                if (this.metaData[i].column_type === 'DROPDOWN') {
                  this.metaData[i].flexValuesTab = response.flexValuesTab;
                } else if (response.defaultValue !== null && this.metaData[i].column_type === 'DATE') {
                  this.metaData[i].defaultValue = response.defaultValue;
                  this.requestForm.controls[this.metaData[i].application_column_name]
                    .setValue({ jsdate: new Date(this.common.formatDate(response.defaultValue)) });
                  this.metaData[i].hasValue = true;
                } else {
                  this.metaData[i].defaultValue = response.defaultValue;
                  this.requestForm.controls[this.metaData[i].application_column_name].setValue(response.defaultValue);
                  this.metaData[i].hasValue = true;
                }
              }
            },
            () => {
            }
          ));
        }
      }
    }
  }
  /**
   * @desc method to get the all field values from the passed index of metadata
   * @param index the index upto which the values are neededd
   * @param selectedDate formated date passed in the case of selected field is date
   */
  getPreviousFieldData(index, selectedDate) {
    const data = {
      userName: '',
      language: '',
      requestCode: this.requestCode,
      requestType: this.requestType,
      displayLabel: this.metaData[index].display_label,
      displayLabelCode: this.metaData[index].display_label_code,
      dependentFlexTab: []
    };
    /**
    * get the input values upto passed index but for date set input value as formatted date
    */
    for (let i = 0; i < index; i++) {
      let inputValue = '';
      if (
        this.requestForm.controls[this.metaData[i].application_column_name]
          .value && this.requestForm.controls[this.metaData[i].application_column_name]
            .value !== null &&
        this.requestForm.controls[this.metaData[i].application_column_name]
          .value.jsdate != null
      ) {
        const value = this.requestForm.controls[
          this.metaData[i].application_column_name
        ].value;
        // if (value.date.month.toString().length === 1) {
        //   value.date.month = `0${value.date.month}`;
        // }
        // if (value.date.day.toString().length === 1) {
        //   value.date.day = `0${value.date.day}`;
        // }
        const formattedDate = `${this.datePipe.transform(new Date(value.jsdate), 'yyyy-MM-dd')} 00:00:00`;
        inputValue = formattedDate;
      } else {
        inputValue = this.requestForm.controls[
          this.metaData[i].application_column_name
        ].value;
      }
      if (i === this.currentIndex && this.metaData[i].column_type === 'DATE') {
        inputValue = selectedDate;
      }
      const flexTab = {
        display_label: this.metaData[i].display_label,
        display_label_code: this.metaData[i].display_label_code,
        displayEndColumnName: this.metaData[i].displayEndColumnName,
        input_value: inputValue
      };
      data.dependentFlexTab.push(flexTab);
    }
    return data;
  }
  /**
   * desc method to submit the request based on SIT and EIT
   * @param requestForm the form with all input values
   */
  saveRequest(requestForm: NgForm) {
    if (this.requestForm.valid) {
      const issueDate = new Date(this.requestForm.value.PEI_INFORMATION3.jsdate);
      const expiryDate = new Date(this.requestForm.value.PEI_INFORMATION4.jsdate)
      if (issueDate.setHours(0, 0, 0, 0) > new Date().setHours(0, 0, 0, 0)) {
        const toast = {
          show: true,
          status: 'failed',
          message: 'Issue date should not be a future date'
        };
        this.common.showToast(toast);
        return;
      }
      if (issueDate.setHours(0, 0, 0, 0) >= expiryDate.setHours(0, 0, 0, 0)) {
        const toast = {
          show: true,
          status: 'failed',
          message: 'Issue date should not be greater than expiry date'
        };
        this.common.showToast(toast);
        return;
      }
      this.formSbmitted = true;
      this.showLoader = true;
      let formattedDate = '';
      const formArray = requestForm.value;
      for (const key of Object.keys(formArray)) {
        if (typeof formArray[key] === 'object') {
          if (formArray[key] && formArray[key].jsdate) {
            // if (formArray[key].date.month.toString().length === 1) {
            //   formArray[key].date.month = `0${formArray[key].date.month}`;
            // }
            // if (formArray[key].date.day.toString().length === 1) {
            //   formArray[key].date.day = `0${formArray[key].date.day}`;
            // }
            // formattedDate = `${formArray[key].date.year}-${
            //   formArray[key].date.month
            //   }-${formArray[key].date.day} 00:00:00`;
            formattedDate = `${this.datePipe.transform(new Date(formArray[key].jsdate), 'yyyy-MM-dd')} 00:00:00`;
            requestForm.value[key] = formattedDate;
          }
        }
      }
      if (this.requestType === 'EIT') {
        requestForm.value.informationType = this.requestCode;
        requestForm.value.informationCategory = this.requestCode;
        const data = {
          mobEITTab: [],
          userComments: '',
          eitAttachementTab: []
        };
        if (this.uploadedFile.length) {
          this.uploadedFile.forEach((file) => {
            const attachment = {
              title: file.title,
              documentId: file.documentId ? file.documentId : '',
              deleteFlag: '',
              description: file.description,
              attachementName: file.attachmentName,
              fileData: file.fileData,
              attachementType: file.attachmentType
            };
            data.eitAttachementTab.push(attachment);
          });
          data.mobEITTab.push(requestForm.value);
          this.sitEitApiCall(data, 'eit');
        } else if (this.attachmetReq === 'Y') {
          this.formSbmitted = false;
          this.showLoader = false;
          this.errorMsg = 'Attachment is mandatory for this request';
        } else {
          data.mobEITTab.push(requestForm.value);
          this.sitEitApiCall(data, 'eit');
        }
      } else {
        this.showLoader = false;
      }
    } else {
      this.formSbmitted = false;
      this.errorMsg = 'Please enter all required fields';
    }
  }
  /**
   * @desc api call for submitting sit and eit
   * @param data data to be submitted
   * @param type specify sit or eit
   */
  sitEitApiCall(data, type) {
    this.saveRequestSubscription$ = this.reqSubmitService.submitEitRequest(data, type).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.validationMessage = '';
          this.requestForm.reset();
          this.approverList = response.approverList;
          this.transactionId = response.transactionId;
          if (!this.approverList.length) {
            this.submitRquest('Y');
          }
        }
        if (response.returnCode === '1') {
          this.validationMessage = response.returnMsg;
        }
      },
      (error) => {
        this.validationMessage = '';
        this.showLoader = false;
      }
    );
  }

  submitRquest(action) {
    this.showLoader = true;
    const body = {
      'requestType': this.requestType,
      'submitFlag': action,
      'transactionId': this.transactionId,
    };
    this.approverSubscription$ = this.reqSubmitService.submitFinalRequest(body).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.requestForm.reset();
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.router.navigate(['/myprofile/passport']);
          this.common.showToast(toast);
        } else {
          this.approverList = [];
        }
      },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  /**
   * @desc method to check if router needed to be deactivated if any input is there in form
   */
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if (this.requestForm && this.requestForm.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }/**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.uploadedFile.push(file);
  }
  deleteFile(index) {
    this.uploadedFile.splice(index, 1);
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  moreInfoClicked() {
    this.moreInfo = true;
  }
  ngOnDestroy() {
    if (this.metaDataSubscription$) {
      this.metaDataSubscription$.unsubscribe();
      this.dependentSubscription$.unsubscribe();
    }
    if (this.saveRequestSubscription$) {
      this.saveRequestSubscription$.unsubscribe();
    }
    if (this.approverSubscription$) {
      this.approverSubscription$.unsubscribe();
    }
    this.confirm$.unsubscribe();
  }

}
