import { Component, OnInit, OnDestroy } from '@angular/core';
import { PersonalService } from '../../data-services/personal.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CommonService } from 'src/app/shared/services/common.service';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { tap, catchError } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { MonthSmall } from 'src/app/shared/constants/month.constants';
import { DatePipe, Location } from '@angular/common';
@Component({
  providers: [DatePipe],
  selector: 'app-add-dependent',
  templateUrl: './add-dependent.component.html',
})
export class AddDependentComponent implements OnInit, OnDestroy {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su',
    disableSince: { year: 0, month: 0, day: 0 }
  };
  myOptionsar: INgxMyDpOptions = {
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'su',
    disableSince: { year: 0, month: 0, day: 0 }
  };
  AddDependantForm: FormGroup;
  personalDetails: any = [];
  editPage = 'false';
  managerAction = false;
  selectedUser = '';
  titleList = [];
  language = '';
  formsubmit = false;
  uploadedFile = [];
  relationList = [];
  genderList = [];
  backConfirm = false;
  confirm$: Subject<boolean> = new Subject<boolean>();
  contactRelationshipId = null;
  showAddAttachment = false;
  constructor(
    private readonly personalService: PersonalService,
    private readonly formBuilder: FormBuilder,
    private readonly common: CommonService,
    private route: ActivatedRoute,
    private readonly url: UrlGeneratorService,
    private readonly http: HttpClient,
    private router: Router,
    private location: Location,
    private readonly datePipe: DatePipe
  ) {
    this.AddDependantForm = this.formBuilder.group({
      title: '',
      firstName: ['', Validators.required],
      familyName: ['', Validators.required],
      arabicFirstName: '',
      arabicFamilyName: '',
      arabicGrandFatherName: '',
      arabicFatherName: '',
      dateOfBirth: ['', Validators.required],
      // genderId: [''],
      // relationship: [''],
      genderId: ['', Validators.required],
      relationship: ['', Validators.required],
      relationStartDate: ['', Validators.required],
      fatherName: '',
      grandFatherName: '',
      civilId: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.editPage = params.edit;
    });
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.language = this.common.getLanguage();
    if (this.editPage === 'true') {
      this.setData();
    }
    this.common.makeFormAsPrestine().subscribe(
      () => {
        this.AddDependantForm.markAsPristine();
      }
    );
    this.getTitleList();
    this.getRelationList();
    this.getGenderList();
    const today = new Date();
    const month = today.getMonth() + 1;
    const year = today.getFullYear();
    const day = today.getDate() + 1;
    this.myOptions.disableSince = { year: year, month: month, day: day };
  }
  getTitleList() {
    this.titleList = [];
    const data = {
      type: 'TITLE_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe((response) => {
      this.titleList = response.keyValueSet;
    }, (error) => {
    });
  }
  getRelationList() {
    this.relationList = [];
    const data = {
      type: 'CONTACT_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe((response) => {
      this.relationList = response.keyValueSet;
    }, (error) => {
    });
  }
  getGenderList() {
    this.genderList = [];
    const data = {
      type: 'GENDER_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe((response) => {
      this.genderList = response.keyValueSet;
    }, (error) => {
    });
  }
  onTitleChange(id) {
    if (this.AddDependantForm.controls.relationship.value || this.AddDependantForm.controls.genderId.value) {
      const maleTitle = ['HH', 'MR.', 'PRINCE'];
      const maleTitleGender = ['HH', 'MR.', 'PRINCE', 'DR.', 'ENG.', 'HU_PROF'];
      const femaleTitle = ['MISS', 'MRS.', 'MS.', 'PRINCESS'];
      const femaleTitleGender = ['MISS', 'MRS.', 'MS.', 'PRINCESS', 'DR.', 'ENG.', 'HU_PROF'];
      const maleRelation = ['JP_FT', 'IN_SON', 'C', 'EMRG', 'P', 'S'];
      const femaleRelation = ['IN_D', 'JP_MT', 'WIFE', 'C', 'EMRG', 'P', 'S'];
      if (maleTitle.includes(id)) {
        if (!maleRelation.includes(this.AddDependantForm.controls.relationship.value)) {
          this.AddDependantForm.controls.relationship.setValue('');
          this.showRelationTitleMismatchToast();
        }
      } else if (femaleTitle.includes(id)) {
        if (!femaleRelation.includes(this.AddDependantForm.controls.relationship.value)) {
          this.AddDependantForm.controls.relationship.setValue('');
          this.showRelationTitleMismatchToast();
        }
      }
      if (this.AddDependantForm.controls.genderId.value === 'M') {
        if (!maleTitleGender.includes(id)) {
          this.AddDependantForm.controls.genderId.setValue('');
          this.showGenderTitleMismatchToast();
        }
      } else if (this.AddDependantForm.controls.genderId.value === 'F') {
        if (!femaleTitleGender.includes(id)) {
          this.AddDependantForm.controls.genderId.setValue('');
          this.showGenderTitleMismatchToast();
        }
      }
    }
  }
  onGenderChange(id) {
    if (this.AddDependantForm.controls.title.value) {
      const maleTitle = ['HH', 'MR.', 'PRINCE', 'DR.', 'ENG.', 'HU_PROF'];
      const femaleTitle = ['MISS', 'MRS.', 'MS.', 'PRINCESS', 'DR.', 'ENG.', 'HU_PROF'];
      if (id === 'M') {
        if (!maleTitle.includes(this.AddDependantForm.controls.title.value)) {
          this.AddDependantForm.controls.title.setValue('');
          this.showGenderTitleMismatchToast();
        }
      } else if (id === 'F') {
        if (!femaleTitle.includes(this.AddDependantForm.controls.title.value)) {
          this.AddDependantForm.controls.title.setValue('');
          this.showGenderTitleMismatchToast();
        }
      }
    }
  }
  onRelationshipChange(id) {
    if (this.AddDependantForm.controls.title.value) {
      const maleTitle = ['HH', 'MR.', 'PRINCE', 'DR.', 'ENG.', 'HU_PROF'];
      const femaleTitle = ['MISS', 'MRS.', 'MS.', 'PRINCESS', 'DR.', 'ENG.', 'HU_PROF'];
      const maleRelation = ['JP_FT', 'IN_SON'];
      const femaleRelation = ['IN_D', 'JP_MT', 'WIFE'];
      if (maleRelation.includes(id)) {
        if (!maleTitle.includes(this.AddDependantForm.controls.title.value)) {
          this.AddDependantForm.controls.title.setValue('');
          this.showRelationTitleMismatchToast();
        }
      } else if (femaleRelation.includes(id)) {
        if (!femaleTitle.includes(this.AddDependantForm.controls.title.value)) {
          this.AddDependantForm.controls.title.setValue('');
          this.showRelationTitleMismatchToast();
        }
      }
    }
  }
  showRelationTitleMismatchToast() {
    const toast = {
      'show': true,
      'status': 'failed',
      'message': 'Title and Relationship not matching'
    };
    this.common.showToast(toast);
  }
  showGenderTitleMismatchToast() {
    const toast = {
      'show': true,
      'status': 'failed',
      'message': 'Title and Gender not matching'
    };
    this.common.showToast(toast);
  }
  addDependent() {
    this.formsubmit = true;
    if (this.AddDependantForm.valid) {
      const data = {
        'dependentTab': [],
        'dependentAttachementTab': []
      };
      if (this.editPage === 'false') {
        this.contactRelationshipId = '';
      }
      const cred = this.AddDependantForm.value;
      if (
        this.AddDependantForm.value.relationStartDate &&
        this.AddDependantForm.value.relationStartDate.jsdate
      ) {
        cred.relationStartDate = this.datePipe.transform(new Date(this.AddDependantForm.value.relationStartDate.jsdate), 'yyyy-MM-dd');
      }
      if (
        this.AddDependantForm.value.dateOfBirth &&
        this.AddDependantForm.value.dateOfBirth.jsdate
      ) {
        cred.dateOfBirth = this.datePipe.transform(new Date(this.AddDependantForm.value.dateOfBirth.jsdate), 'yyyy-MM-dd');
      }
      this.AddDependantForm.value.relationEndDate = '';
      data.dependentTab.push(this.AddDependantForm.value);
      this.AddDependantForm.value.dependentAttachementTab = [];
      const userDetails = this.common.getUserDetails();
      const reqBody = {
        managerUserName: userDetails.userName,
        userName: this.managerAction ? this.selectedUser : userDetails.userName,
        dependentTab: [{
          contactRelationshipId: this.contactRelationshipId,
          relationStartDate: cred.relationStartDate,
          genderId: this.AddDependantForm.value.genderId,
          contactType: this.AddDependantForm.value.relationship,
          dateOfBirth: cred.dateOfBirth,
          fatherName: this.AddDependantForm.value.fatherName,
          grandFatherName: this.AddDependantForm.value.grandFatherName,
          familyName: this.AddDependantForm.value.familyName,
          firstName: this.AddDependantForm.value.firstName,
          middleName: this.AddDependantForm.value.middleName,
          title: this.AddDependantForm.value.title,
          civilId: this.AddDependantForm.value.civilId,
          emailAddress: this.AddDependantForm.value.emailAddress,
          arabicFirstName: this.AddDependantForm.value.arabicFirstName,
          arabicFatherName: this.AddDependantForm.value.arabicFatherName,
          arabicGrandFatherName: this.AddDependantForm.value.arabicGrandFatherName,
          arabicFamilyName: this.AddDependantForm.value.arabicFamilyName,
          relationEndDate: ''
        }],
        dependentAttachementTab: []
      };
      if (this.uploadedFile.length) {
        this.uploadedFile.forEach((file) => {
          const attachment = {
            title: file.title,
            documentId: file.documentId ? file.documentId : '',
            deleteFlag: '',
            description: file.description,
            attachementName: file.attachmentName,
            fileData: file.fileData,
            attachementType: file.attachmentType
          };
          reqBody.dependentAttachementTab.push(attachment);
        });
      }
      this.personalService.addDependentService(reqBody, this.managerAction, this.selectedUser).subscribe((response) => {
        let toast;
        if (response.returnCode === '0') {
          this.AddDependantForm.reset();
          toast = {
            'show': true,
            'status': 'success',
            'message': response.returnMsg
          };
          this.location.back();
        } else {
          toast = {
            'show': true,
            'status': 'failed',
            'message': response.returnMsg
          };
        }
        this.common.showToast(toast);
      },
        (error) => {
          const toast = {
            'show': true,
            'status': 'failed',
            'message': error.returnMsg
          };
          this.common.showToast(toast);
        });
    }
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  cancelAttachment(value) {
    this.showAddAttachment = value;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.uploadedFile.push(file);
  }
  deleteFile(index) {
    this.uploadedFile.splice(index, 1);
  }
  setData() {
    const data = JSON.parse(localStorage.getItem('dependent'));
    this.contactRelationshipId = data.relationshipId;
    this.AddDependantForm.controls.firstName.setValue(data.firstName);
    this.AddDependantForm.controls.familyName.setValue(data.familyName);
    this.AddDependantForm.controls.fatherName.setValue(data.fatherName);
    this.AddDependantForm.controls.grandFatherName.setValue(data.grandfatherName);
    this.AddDependantForm.controls.title.setValue(data.titleCode);
    this.AddDependantForm.controls.civilId.setValue(data.nationalIdentifier);
    this.AddDependantForm.controls.arabicFirstName.setValue(data.arabicFirstName);
    this.AddDependantForm.controls.arabicFatherName.setValue(data.arabicFatherName);
    this.AddDependantForm.controls.arabicGrandFatherName.setValue(data.arabicGrandFatherName);
    this.AddDependantForm.controls.arabicFamilyName.setValue(data.arabicFamilyName);
    this.AddDependantForm.controls.genderId.setValue(data.sexCode);
    this.AddDependantForm.controls.dateOfBirth.setValue({ jsdate: new Date(data.dateOfBirth) });
    this.AddDependantForm.controls.relationship.setValue(data.relationShipCode);
    this.AddDependantForm.controls.relationStartDate.setValue({ jsdate: new Date(data.relationStartDate) });
  }
  ngOnDestroy() {
    localStorage.setItem('dependent', '');
  }

  /**
  * @desc method to check if router needed to be deactivated if any input is there in form
  */
  canDeactivate(state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    if (this.AddDependantForm && this.AddDependantForm.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }/**
    * @desc popup cancel for navigating from page
    */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
    * @desc  popup confirm for navigating from page
    */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  gotoManagerPersonalInfo() {
    this.location.back();
  }
}
