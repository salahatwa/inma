import { Location, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { PersonalService } from '../../data-services/personal.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { CommonService } from 'src/app/shared/services/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { INgxMyDpOptions } from 'ngx-mydatepicker';

@Component({
  providers: [DatePipe],
  selector: 'app-edit-personal-info',
  templateUrl: './edit-personal-info.component.html',
  styleUrls: ['./edit-personal-info.component.scss']
})
export class EditPersonalInfoComponent implements OnInit {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  religionList = [];
  maritalStatusList = [];
  CountryList = [];
  PhoneTypeList = [];
  educationList = [];
  managerAction = false;
  selectedUser = '';
  EditPersonalInfo: FormGroup;
  backConfirm = false;
  confirm$: Subject<boolean> = new Subject<boolean>();
  editPage: String;
  personalInfo;
  showLoader = false;
  userDetails;
  formsubmit = false;
  newPhoneList = [];
  validationMessage = '';
  fullName = '';
  constructor(
    private readonly personalService: PersonalService,
    private readonly formBuilder: FormBuilder,
    private readonly common: CommonService,
    private route: ActivatedRoute,
    private router: Router,
    private readonly location: Location,
    private readonly datePipe: DatePipe
  ) {
    this.route.params.subscribe(params => {
      this.editPage = params.edit;
    });

    this.userDetails = this.common.getUserDetails();

    this.EditPersonalInfo = this.formBuilder.group({
      userName: [this.userDetails.userName, Validators.required],
      religionCode: ['', Validators.required],
      maritalStatus: ['', Validators.required],
      civilId: ['', Validators.required],
      country: ['', Validators.required],
      employeeNumber: ['', Validators.required],
      educationLevel: ['', Validators.required],
      effectiveDate: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.fullName = this.common.getFullName();
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }

    if (this.editPage === 'personal-info') {
      this.getReligionList();
      this.getMaritalStatusList();
      this.getCountryList();
      this.getEducationLevelList();
    } else {
      this.getPhoneTypeList();
    }
    if (this.editPage !== 'add-contact-info') {
      this.setData();
    } else {
      this.addPhone();
    }
  }
  getReligionList() {
    this.educationList = [];
    const data = {
      type: 'RELIGION_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe(
      response => {
        this.religionList = response.keyValueSet;
      },
      error => { }
    );
  }
  getEducationLevelList() {
    this.religionList = [];
    const data = {
      type: 'EDUCATION_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe(
      response => {
        this.educationList = response.keyValueSet;
      },
      error => { }
    );
  }
  getCountryList() {
    this.CountryList = [];
    const data = {
      type: 'COUNTRY_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe(
      response => {
        this.CountryList = response.keyValueSet;
      },
      error => { }
    );
  }
  getMaritalStatusList() {
    this.maritalStatusList = [];
    const data = {
      type: 'MARITAL_STATUS_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe(
      response => {
        this.maritalStatusList = response.keyValueSet;
      },
      error => { }
    );
  }
  getPhoneTypeList() {
    this.PhoneTypeList = [];
    const data = {
      type: 'PHONE_TYPE'
    };
    this.personalService.getKeyValueSetListService(data).subscribe(
      response => {
        this.PhoneTypeList = response.keyValueSet;
      },
      error => { }
    );
  }
  deleteContact(index) {
    if (this.editPage === 'add-contact-info') {
      if (this.newPhoneList) {
        this.newPhoneList[index].fadeOutLeft = true;
        this.newPhoneList.splice(index, 1);
      }
    } else {
      if (this.personalInfo && this.personalInfo.employeePhone) {
        this.personalInfo.employeePhone[index].fadeOutLeft = true;
        this.personalInfo.employeePhone.splice(index, 1);
      }
    }
  }
  saveInfo() {
    if (this.editPage === 'personal-info') {
      this.savePersonalInfo();
    } else {
      if (this.editPage === 'add-contact-info') {
        if (this.newPhoneList.length > 0) {
          let showError = false;
          this.newPhoneList.forEach(element => {
            if (element.phoneNumber == null || element.phoneType == null) {
              showError = true;
            }
          });
          showError
            ? (this.validationMessage = 'Please enter all required fields')
            : this.saveContactInfo();
        }
      } else {
        if (this.personalInfo.employeePhone.length > 0) {
          let showError = false;
          this.personalInfo.employeePhone.forEach(element => {
            if (element.phoneNumber == null || element.phoneType == null) {
              showError = true;
            }
          });
          showError
            ? (this.validationMessage = 'Please enter all required fields')
            : this.saveContactInfo();
        }
      }
    }
  }
  savePersonalInfo() {
    this.showLoader = true;
    this.formsubmit = true;
    const data = this.EditPersonalInfo.value;
    if (data.effectiveDate && data.effectiveDate.jsdate) {
      data.effectiveDate =  this.datePipe.transform(new Date(data.effectiveDate.jsdate), 'dd-MMM-yyyy');
    }
    this.personalService.editEmployeeDetails(data, this.managerAction, this.selectedUser).subscribe(
      response => {
        this.showLoader = false;
        let toast;
        if (response.returnCode === '0') {
          this.EditPersonalInfo.reset();
          toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.location.back();
        } else {
          toast = {
            show: true,
            status: 'failed',
            message: response.returnMsg
          };
        }
        this.common.showToast(toast);
      },
      error => {
        this.showLoader = false;
      }
    );
  }
  saveContactInfo() {
    this.showLoader = true;
    this.validationMessage = '';
    const data = {
      userName: this.userDetails.userName,
      employeePhone: null
    };
    if (this.editPage === 'add-contact-info') {
      data.employeePhone = this.newPhoneList;
    } else {
      this.personalInfo.employeePhone.forEach(phone => {
        const phoneDetails = this.PhoneTypeList.find(item => item.key === phone.phoneTypeCode);
        phone.phoneType = phoneDetails.value;
      });
      data.employeePhone = this.personalInfo.employeePhone;
    }
    this.personalService.editContactNumber(data, this.managerAction, this.selectedUser).subscribe(
      response => {
        this.showLoader = false;
        let toast;
        if (response.returnCode === '0') {
          this.EditPersonalInfo.reset();
          toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.location.back();
        } else {
          toast = {
            show: true,
            status: 'failed',
            message: response.returnMsg
          };
        }
        this.common.showToast(toast);
      },
      error => {
        this.showLoader = false;
      }
    );
  }
  addPhone() {
    this.newPhoneList.push({
      phoneId: null,
      phoneNumber: null,
      phoneType: null,
      phoneTypeCode: null,
      status: null
    });
  }
  setData() {
    if (
      localStorage.getItem('personalInfo') &&
      JSON.parse(localStorage.getItem('personalInfo'))[0]
    ) {
      const data = JSON.parse(localStorage.getItem('personalInfo'))[0];
      this.personalInfo = data;
      this.EditPersonalInfo.controls.religionCode.setValue(data.religionCode);
      this.EditPersonalInfo.controls.maritalStatus.setValue(
        data.maritalStatusCode
      );
      this.EditPersonalInfo.controls.country.setValue(data.nationalityCode);
      this.EditPersonalInfo.controls.educationLevel.setValue(
        data.educationLevelCode
      );
      this.EditPersonalInfo.controls.civilId.setValue(data.civilId);
      this.EditPersonalInfo.controls.effectiveDate.setValue({ jsdate: new Date(data.effectiveDate)});
    }
  }
  /**
   * @desc method to check if router needed to be deactivated if any input is there in form
   */
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if (this.EditPersonalInfo && this.EditPersonalInfo.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }
  /**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }
  /**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  checkSubmitEnabled() {
    const isDisable = true;
    for (let i = 0; i < this.personalInfo.employeePhone.length; i++) {
      if (this.personalInfo.employeePhone[i].status === null) {
        return false;
      }
    }
    return isDisable;
  }
  gotoManagerPersonalInfo() {
    this.location.back();
  }
  close() {
    this.location.back();
  }
}
