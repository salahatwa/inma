import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { PersonalService } from '../data-services/personal.service';
import { CommonService } from '../../shared/services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { INgxMyDpOptions, IMyDateModel } from 'ngx-mydatepicker';
import { ToastFailed } from 'src/app/shared/constants/globalConstants';
import { ToastSuccess } from 'src/app/shared/constants/globalConstants';

@Component({
  providers: [DatePipe],
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.scss']
})
export class PersonalInfoComponent implements OnInit {
  personalDetails: any = [];
  personalPhoneDetails: any = [];
  personalAddressDetails: any = [];
  language = '';
  managerAction = false;
  selectedUser = '';
  fullName = '';
  showLoader = false;
  empName: string;
  jobName: string;
  phonePending = false;
  dependentPending = false;
  personalInfo: Array<any>;
  public selectedDependent: any;
  public showDeleteAlert = false;
  private myForm: FormGroup;
  public selectedEndDate: String;
  dependentInfo: Array<any>;
  public selectedDate = null;
  myOptions: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd-mmm-yyyy',
  };
  myOptionsar: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd-mm-yyyy',
  };
  model: any = { date: { year: 2018, month: 10, day: 9 } };
  constructor(
    private readonly personalService: PersonalService,
    private readonly commonService: CommonService,
    private readonly route: Router,
    private readonly common: CommonService,
    private readonly datePipe: DatePipe,
    private formBuilder: FormBuilder,
  ) {
    this.myForm = this.formBuilder.group({
      // Empty string or null means no initial value. Can be also specific date for
      // example: {date: {year: 2018, month: 10, day: 9}} which sets this date to initial
      // value.

      endDate: ['', Validators.required]
      // other controls are here...
    });
  }

  ngOnInit() {
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.fullName = this.common.getFullName();
    if (this.route.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.getPersonalDetails();
    this.language = this.common.getLanguage();
  }
  getPersonalDetails() {
    const userDetails = this.commonService.getUserDetails();
    this.empName = userDetails.fullName;
    this.jobName = userDetails.jobName;
    this.showLoader = true;
    this.personalDetails = this.commonService.getUserDetails();
    const userName = this.personalDetails.userName;
    const data = {
      'userName': this.managerAction ? this.selectedUser : userName,
      'loggedInUser': userName
    };
    this.personalService.getPersonalDetailsService(data).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {

        this.personalInfo = response.empContactTab;
        this.dependentInfo = response.empDependentTab;
        this.personalPhoneDetails = this.personalInfo[0].employeePhone;
        this.personalAddressDetails = this.personalInfo[0].employeeAddress;
        this.dependentInfo.forEach(element => {
          if (element.status === 'Pending') {
            this.dependentPending = true;
          }
        });
      }
      this.personalPhoneDetails.forEach(element => {
        if (element.status === 'Pending') {
          this.phonePending = true;
        }
      });
    },
      (error) => {
        this.showLoader = false;
      });
  }
  editPersonalInfo(data) {
    const editValues = this.personalInfo;
    localStorage.setItem('personalInfo', JSON.stringify(editValues));
    if (this.route.url.includes('manager-self-service')) {
      this.route.navigate(['/manager-self-service/personal-info/update', { edit: data }]);
    } else {
      this.route.navigate(['/myprofile/personal-info/edit-personal-info', { edit: data }]);
    }

  }
  deleteDependentAlert(dependent, index) {
    this.selectedDependent = dependent;
    this.selectedDependent.index = index;
    this.showDeleteAlert = true;
  }

  deleteDependent(index) {
    this.showLoader = true;
    const dependent = this.selectedDependent;
    const data = {
      'managerUserName': this.personalDetails.userName,
      'userName': this.managerAction ? this.selectedUser : this.personalDetails.userName,
      'dependentTab': [
        {
          'contactRelationshipId': dependent.relationshipId,
          'relationStartDate': '',
          'genderId': '',
          'contactType': '',
          'dateOfBirth': '',
          'fatherName': '',
          'grandFatherName': '',
          'familyName': '',
          'firstName': '',
          'middleName': '',
          'title': '',
          'civilId': this.personalDetails.civilId,
          'emailAddress': '',
          'relationEndDate': this.datePipe.transform(new Date(this.selectedDate.formatted), 'yyyy-MM-dd'),
        }],
      'dependentAttachementTab': []
    };

    this.personalService.deleteDependentService(data, this.managerAction).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        const toast = ToastSuccess;
        toast.message = response.returnMsg;
        this.commonService.showToast(toast);
        this.showDeleteAlert = false;
        this.selectedDate = '';
        this.getPersonalDetails();
      } else {
        const toast = ToastFailed;
        toast.message = response.returnMsg;
        this.commonService.showToast(toast);
        this.showDeleteAlert = false;
        this.selectedDate = '';
      }
    },
      (error) => {
        this.showLoader = false;
      });
  }


  cancelDeleteAlert() {
    this.showDeleteAlert = false;
  }
  editDependent(dependent, index) {
    const editValues = this.dependentInfo[index];
    localStorage.setItem('dependent', JSON.stringify(editValues));
    if (this.managerAction) {
      this.route.navigate(['/manager-self-service/add-dependent', { edit: true }]);
    } else {
    this.route.navigate(['/myprofile/personal-info/add-dependent', { edit: true }]);
    }
  }
  addDependent() {
    if (this.managerAction) {
      this.route.navigate(['/manager-self-service/add-dependent']);
    } else {
    this.route.navigate(['/myprofile/personal-info/add-dependent']);
    }
  }

}
