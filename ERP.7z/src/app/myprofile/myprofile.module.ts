import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyprofileComponent } from './myprofile.component';
import { SharedModule } from '../shared/shared.module';
import { EmploymentComponent } from './employment/employment.component';
import { AddEmergencyComponent } from './personal-info/add-emergency/add-emergency.component';
import { PayslipComponent } from './payslip/payslip.component';
import { RouterModule } from '@angular/router';
import { EditPersonalInfoComponent } from './personal-info/edit-personal-info/edit-personal-info.component';
import { SalaryComponent } from './salary/salary.component';
import { PassportComponent } from './passport/passport.component';
import { AddPassportComponent } from './passport/add-passport/add-passport.component';
import { MyDatePickerModule } from 'mydatepicker';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgxMyDatePicker, NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { AddDependentComponent } from './personal-info/add-dependent/add-dependent.component';
import { EmergencyContactComponent } from './emergency-contact/emergency-contact.component';
import { AddEmergencyContactComponent } from './emergency-contact/add-emergency-contact/add-emergency-contact.component';
import { MyprofileRoutingModule } from './myprofile-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    FormsModule,
    MyDatePickerModule,
    ReactiveFormsModule,
    MyprofileRoutingModule,
    NgxMyDatePickerModule.forRoot()
  ],
  declarations: [
    MyprofileComponent,
    EmploymentComponent,
    AddEmergencyComponent,
    PayslipComponent,
    SalaryComponent,
    PassportComponent,
    AddPassportComponent,
    EmergencyContactComponent,
    AddEmergencyContactComponent
  ]
})
export class MyprofileModule { }
