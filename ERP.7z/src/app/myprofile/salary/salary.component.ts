import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { SalaryService } from '../data-services/salary.service';
@Component({
    selector: 'app-salary',
    templateUrl: './salary.component.html',
    styleUrls: ['./salary.component.scss']
})
export class SalaryComponent implements OnInit {
    salaryDetails: any = [];
    showLoader = false;
    constructor(
        private salaryService: SalaryService,
        private common: CommonService
    ) { }

    ngOnInit() {
        this.getSalaryDetails();
    }
    getSalaryDetails() {
        this.showLoader = true;
        const userDetails = this.common.getUserDetails();
        const userName = userDetails.userName;
        const data = {
            'userName': userName
        };
        this.salaryService.getSalaryDetailsService(data).subscribe((response) => {
            this.showLoader = false;
            if (response.returnCode === '0') {
                this.salaryDetails = response.salaryDetailsTab;
            }
        },
            (error) => {
                this.showLoader = false;
            });
    }
}
