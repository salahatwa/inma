import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PayslipService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient
  ) { }
  getpaySlipDateList(data): Observable<any> {
    const url = this.url.getworkpayslipDateUrl();
    return this.http.post<any>(url, data).pipe(
        tap((response) => {
        }),
        catchError((error) => {
            return throwError(error);
        })
    );
}

getpaySlipDetail(data): Observable<any> {
    const url = this.url.getworkpayslipDetailUrl();
    return this.http.post<any>(url, data).pipe(
        tap((response) => {
        }),
        catchError((error) => {
            return throwError(error);
        })
    );
}

}
