import { CommonService } from 'src/app/shared/services/common.service';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class PersonalService {

  constructor(
    private readonly url: UrlGeneratorService,
    private readonly http: HttpClient,
    private readonly common: CommonService
  ) { }

  getPersonalDetailsService(data): Observable<any> {
    const url = this.url.getPersonalDetailsUrl();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  getEmergencyContactDetails() {
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: userDetails.userName,
      language: '',
      analysisCriteriaId: '',
      extraInfoId: '',
      requestCode: 'XXX_HR_ADD_EMG_CONTACT',
      requestType: 'EIT'
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    const url = this.url.getSitEitDetails();
    return this.http.post<any>(url, data).pipe(
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  deleteDependentService(data, mngrAction): Observable<any> {
    let url = '';
    if (mngrAction) {
      url = this.url.getManagerActionsManageDependentUrl();
    } else {
     url = this.url.getDeleteDependentUrl();
    }
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }

  addDependentService(data, mngrAction, user?): Observable<any> {
    let url = '';
    if (mngrAction) {
      url = this.url.getManagerActionsManageDependentUrl();
    } else {
      url = this.url.getAddDependentUrl();
    }
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }

  editDependentService(data): Observable<any> {
    const url = this.url.getEditDependentUrl();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  getKeyValueSetListService(data): Observable<any> {
    const url = this.url.getKeyValueSetListUrl();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
  }
  editEmployeeDetails(data, mngrAction, user?): Observable<any> {
    let url = '';
    if (mngrAction) {
      data.selectedUserName = user;
      data.managerUserName = this.common.getUserDetails().userName;
      url = this.url.getManagerActionsEmpBaciInfoUrl();
    } else {
      data.userName = this.common.getUserDetails().userName;
      url = this.url.getEditEmployeeDetailsUrl();
    }
    return this.http.post<any>(url, data);
  }
  editContactNumber(data, mngrAction, user?): Observable<any> {
    let url = '';
    if (mngrAction) {
      data.managerUserName = this.common.getUserDetails().userName;
      data.selectedUserName = user;
      url = this.url.getManagerActionsEmpPhoneUrl();
    } else {
      url = this.url.getEditContactNumberUrl();
    }
    return this.http.post<any>(url, data);
  }
}
