import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { tap, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EmploymentService {
  employmentDetails = [];
  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient
  ) { }

  employment(data): Observable<any> {
    const url = this.url.getEmploymentUrl();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
        this.employmentDetails = response.employementDetailsTab;
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
}
