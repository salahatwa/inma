import { ExpenseLinesComponent } from './expense-claim/expense-lines/expense-lines.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeRequestComponent } from './employee-request.component';
import { AddCreditCardComponent } from './credit-card/add-credit-card/add-credit-card.component';
import { CreditCardComponent } from './credit-card/credit-card.component';
import { RequestDetailsComponent } from './request-details/request-details.component';
import { AddRequestComponent } from './add-request/add-request.component';
import { CanDeactivateGuard } from './../shared/services/can-deactivate-guard.service';
import { ResignationRequestComponent } from './resignation-request/resignation-request.component';
import { AddResignationRequestComponent } from './resignation-request/add-resignation-request/add-resignation-request.component';
import { EducationQualificationComponent } from './education-qualification/education-qualification.component';
import { RequestEducationQualificationComponent } from './education-qualification/request-education-qualification/request-education-qualification.component';
import { AddSubjectComponent } from './education-qualification/request-education-qualification/subject-information/add-subject/add-subject.component';
import { MyDocumentsComponent } from './my-documents/my-documents.component';
import { ExpenseClaimComponent } from './expense-claim/expense-claim.component';
import { RequestExpenseClaimComponent } from './expense-claim/request-expense-claim/request-expense-claim.component';
import { OfficialTripComponent } from './official-trip/official-trip.component';
import { RequestOfficialTripComponent } from './official-trip/request-official-trip/request-official-trip.component';
import { FinancingRequestComponent } from './financing-request/financing-request.component';
import { AddFinancingRequestComponent } from './financing-request/add-financing-request/add-financing-request.component';
import { OfficialTripRoutesComponent } from './official-trip/official-trip-routes/official-trip-routes.component';
// tslint:disable-next-line: max-line-length
import { EducationQualificationDetailsComponent } from './education-qualification/education-qualification-details/education-qualification-details.component';

const routes: Routes = [
  { path: '', component: EmployeeRequestComponent },
  { path: 'add-credit-card', component: AddCreditCardComponent, data: { title: 'Add Credit Card' } },
  // { path: 'credit-card', component: CreditCardComponent, data: { title: 'Credit Card' } },
  // { path: 'details/:code/:type', component: RequestDetailsComponent, data: { title: 'Employee Requests' } },
  // { path: 'add/:code/:type', component: AddRequestComponent, data: { title: 'Employee Requests' }, canDeactivate: [CanDeactivateGuard] },
  { path: 'resignation-request', component: ResignationRequestComponent, data: { title: 'Employee Requests' } },
  { path: 'add-resignation-request', component: AddResignationRequestComponent, data: { title: 'Employee Requests' } },
  { path: 'education-and-qualification', component: EducationQualificationComponent, data: { title: 'Employee Requests' } },
  { path: 'education-and-qualification-details', component: EducationQualificationDetailsComponent, data: { title: 'Employee Requests' } },
  { path: 'request-education-and-qualification', component: RequestEducationQualificationComponent, data: { title: 'Employee Requests' } },
  { path: 'add-subject', component: AddSubjectComponent, data: { title: 'Employee Requests' } },
  { path: 'my-document', component: MyDocumentsComponent, data: { title: 'Employee Requests' } },
  { path: 'expense-claim', component: ExpenseClaimComponent, data: { title: 'Employee Requests' } },
  { path: 'expense-claim/lines', component: ExpenseLinesComponent, data: { title: 'Employee Requests' } },
  {
    path: 'request-expense-claim', component: RequestExpenseClaimComponent, data: { title: 'Employee Requests' },
    canDeactivate: [CanDeactivateGuard]
  },
  { path: 'official-trip', component: OfficialTripComponent, data: { title: 'Official Trip' } },
  { path: 'official-trip/routes', component: OfficialTripRoutesComponent, data: { title: 'Official Trip' } },
  {
    path: 'request-official-trip', component: RequestOfficialTripComponent, data: { title: 'Officical Trip' },
    canDeactivate: [CanDeactivateGuard]
  },
  { path: 'credit-card', component: CreditCardComponent, data: { title: 'Credit Card Requests' } },
  { path: 'financing-request', component: FinancingRequestComponent, data: { title: 'Financing Request' } },
  { path: 'add-financing-request', component: AddFinancingRequestComponent, data: { title: 'Add Financing Request' } },
  { path: 'details/:code/:type', component: RequestDetailsComponent },
  { path: 'add/:code/:type', component: AddRequestComponent, canDeactivate: [CanDeactivateGuard] }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeRequestRoutingModule { }
