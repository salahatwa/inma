import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { ToastFailed } from './../shared/constants/globalConstants';
import { CommonService } from './../shared/services/common.service';
import { RequestListingService } from './data-services/request-listing.service';
import { EmpReqImages } from '../shared/constants/empReqImages.constants';

@Component({
  selector: 'app-employee-request',
  templateUrl: './employee-request.component.html',
  styleUrls: ['./employee-request.component.scss']
})
export class EmployeeRequestComponent implements OnInit, OnDestroy {
  requestList = [];
  subscription$: Subscription;
  imageUrl = [];
  deafaultImgUrl = 'assets/images/default_employee_request.svg';
  showLoader = false;
  constructor(
    private readonly requestService: RequestListingService,
    private readonly router: Router,
    private readonly common: CommonService
  ) { }

  ngOnInit() {
    this.getSitEitListings();
  }
  /**
   * method to get the SIT and EIT listing
   */
  getSitEitListings() {
    this.showLoader = true;
    this.subscription$ = this.requestService.getRequestList().subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          const request = response.sitEitListTab;
          const resignationWarningMsg = response.warningMessage ? response.warningMessage : '';
          localStorage.setItem('warningMsg', resignationWarningMsg);
          request.forEach((detail) => {
            if (EmpReqImages.indexOf(detail.requestCode) !== -1) {
              const image = `assets/images/${detail.requestCode}.svg`;
              detail.imageUrl = image;
            } else {
              const image = `assets/images/default_employee_request.svg`;
              detail.imageUrl = image;
            }
            this.requestList.push(detail);
          });
        }
      },
      () => {
        this.common.showToast(ToastFailed);
        this.showLoader = false;
      }
    );
  }
  navToRequestDetails(reqType: string, reqCode: string, reqName: string) {
    this.router.navigate(['/employee-request/details', reqType, reqCode]);
  }
  ngOnDestroy() {
    this.subscription$.unsubscribe();
  }
}
