import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable, Subject } from 'rxjs';
import { ActivatedRoute, Router, CanDeactivate } from '@angular/router';
import { INgxMyDpOptions } from 'ngx-mydatepicker';

import { RequestMetaService } from '../data-services/request-meta.service';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SubmitRequestService } from '../data-services/submit-request.service';
import { CanComponentDeactivate } from './../../shared/services/can-deactivate-guard.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { DatePipe, Location } from '@angular/common';

@Component({
  providers: [DatePipe],
  selector: 'app-add-request',
  templateUrl: './add-request.component.html',
  styleUrls: ['./add-request.component.scss']
})
export class AddRequestComponent implements OnInit, OnDestroy, CanComponentDeactivate {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  myOptions1: INgxMyDpOptions = {
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'su'
  };
  language = '';
  selectedUser = '';
  attachmetReq = '';
  formSbmitted = true;
  reqName = '';
  managerAction = false;
  learning = false;
  moreInfo = false;
  errorMsg = '';
  backConfirm = false;
  approverList = [];
  transactionId = '';
  private confirm$: Subject<boolean> = new Subject<boolean>();
  private routeSubscription$: Subscription;
  private metaDataSubscription$: Subscription;
  private saveRequestSubscription$: Subscription;
  private dependentSubscription$: Subscription = new Subscription;
  private approverSubscription$: Subscription = new Subscription;
  requestForm: FormGroup;
  showLoader = false;
  private formDetails: { [k: string]: any } = {};
  metaData: any;
  numberMax = 20;
  validationMessage = '';
  showAddAttachment = false;
  uploadedFile = [];
  private currentIndex: number;
  requestType: string;
  requestCode: string;
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly metaService: RequestMetaService,
    private readonly reqSubmitService: SubmitRequestService,
    private readonly common: CommonService,
    private readonly datePipe: DatePipe,
    private readonly location: Location
  ) { }

  ngOnInit() {
    this.routeSubscription$ = this.activeRoute.params.subscribe(params => {
      this.requestType = params['type'];
      this.requestCode = params['code'];
    });
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    } else if (this.router.url.includes('learning')) {
      this.learning = true;
    }
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.common.makeFormAsPrestine().subscribe(
      () => {
        this.requestForm.markAsPristine();
      }
    );
    this.getSitEitMetaData();
    this.language = this.common.getLanguage();
  }
  /**
   * @desc this method is used to get the data for populating the form fields in create employee request
   */
  getSitEitMetaData() {
    this.showLoader = true;
    this.metaDataSubscription$ = this.metaService
      .getRequestMetaData(this.requestType, this.requestCode, this.selectedUser, this.managerAction)
      .subscribe(
        response => {
          this.showLoader = false;
          if (response.returnCode === '0') {
            this.attachmetReq = response.attachementFlag;
            this.reqName = response.requestName;
            this.metaData = response.sitEitMetaDataTab;
            this.metaData.forEach(element => {
              element.hasValue = false;
              if (element.is_mandatory === 'N') {
                this.formDetails[element.application_column_name] = '';
              } else {
                this.formDetails[element.application_column_name] = [
                  '',
                  Validators.required
                ];
              }
            });
            // this.formDetails['userComments'] = '';
            this.requestForm = this.formBuilder.group(this.formDetails);
            this.metaData.forEach(element => {
              if (element.defaultValue && element.column_type !== 'DATE') {
                this.requestForm.controls[element.application_column_name].setValue(element.defaultValue);
                element.hasValue = true;
              } else if (element.defaultValue && element.defaultValue !== null && element.column_type === 'DATE') {
                this.requestForm.controls[element.application_column_name].setValue(element.defaultValue);
              }
            });
          }
        },
        () => {
          this.showLoader = false;
        }
      );
  }
  /**
   * @desc method to dynamically handle back in breadcrumbs
   */
  goBack() {
    //   if (!this.selectedUser) {
    //   this.router.navigate([
    //     '/employee-request/details',
    //     this.requestCode,
    //     this.requestType
    //   ]);
    // } else {
    //   this.location.back();
    // }
    this.location.back();
  }
  /**
   * @decs method to get metadata of dependent fields of the clicked or changed field
   * @param index index of the clicked field metadata
   * @param event event to be passed in case of date picker as change is not detected in formgroup
   */
  checkForNextDependent(index: number, event?) {
    let currentDate;
    this.currentIndex = index;
    /**
     * event is checked in the case of date picker to get selected date
     */
    if (event) {
      if (event.date.year === 0) {
        currentDate = '';
      } else {
        if (event.date.month.toString().length === 1) {
          event.date.month = `0${event.date.month}`;
        }
        if (event.date.day.toString().length === 1) {
          event.date.day = `0${event.date.day}`;
        }
        currentDate = `${event.date.year}-${event.date.month}-${
          event.date.day
          } 00:00:00`;
      }
    }
    /**
     * to add class on datepicker input based on value
     */
    if (this.metaData[index].column_type === 'DATE' && event.date.year) {
      this.metaData[index].hasValue = true;
    } else if (
      this.metaData[index].column_type === 'DATE' &&
      !event.date.year
    ) {
      this.metaData[index].hasValue = false;
    }
    /**
     * loop over the fields from selected field to check dependent fields
     */
    if (this.metaData) {
      for (let i = index + 1; i < this.metaData.length; i++) {
        if (this.metaData[i].dependent_value_set_exists === 'Y' || this.requestCode === 'AIC_HR_EDUCATION_ALLOWANCE_REQ') {
          const data = this.getPreviousFieldData(i, currentDate);
          this.dependentSubscription$.add(this.metaService.getDependentFlexValueSet(data, this.selectedUser, this.managerAction).subscribe(
            response => {
              if (response.returnCode === '0') {
                if (this.metaData[i].column_type === 'DROPDOWN') {
                  this.metaData[i].flexValuesTab = response.flexValuesTab;
                } else if (response.defaultValue !== null && this.metaData[i].column_type === 'DATE') {
                  this.metaData[i].defaultValue = response.defaultValue;
                  this.requestForm.controls[this.metaData[i].application_column_name]
                    .setValue({ jsdate: new Date(this.common.formatDate(response.defaultValue)) });
                  this.metaData[i].hasValue = true;
                } else {
                  this.metaData[i].defaultValue = response.defaultValue;
                  this.requestForm.controls[this.metaData[i].application_column_name].setValue(response.defaultValue);
                  this.metaData[i].hasValue = true;
                }
              }
            },
            () => {
            }
          ));
        }
      }
    }
  }
  /**
   * @desc method to get the all field values from the passed index of metadata
   * @param index the index upto which the values are neededd
   * @param selectedDate formated date passed in the case of selected field is date
   */
  getPreviousFieldData(index, selectedDate) {
    const data = {
      userName: '',
      language: '',
      requestCode: this.requestCode,
      requestType: this.requestType,
      displayLabel: this.metaData[index].display_label,
      displayLabelCode: this.metaData[index].display_label_code,
      dependentFlexTab: []
    };
    /**
    * get the input values upto passed index but for date set input value as formatted date
    */
    for (let i = 0; i < index; i++) {
      let inputValue = '';
      if (
        this.requestForm.controls[this.metaData[i].application_column_name]
          .value && this.requestForm.controls[this.metaData[i].application_column_name]
            .value !== null &&
        this.requestForm.controls[this.metaData[i].application_column_name]
          .value.jsdate != null
      ) {
        const value = this.requestForm.controls[
          this.metaData[i].application_column_name
        ].value;
        // if (value.date.month.toString().length === 1) {
        //   value.date.month = `0${value.date.month}`;
        // }
        // if (value.date.day.toString().length === 1) {
        //   value.date.day = `0${value.date.day}`;
        // }
        const formattedDate = `${this.datePipe.transform(new Date(value.jsdate), 'yyyy-MM-dd')} 00:00:00`;
        inputValue = formattedDate;
      } else {
        inputValue = this.requestForm.controls[
          this.metaData[i].application_column_name
        ].value;
      }
      if (i === this.currentIndex && this.metaData[i].column_type === 'DATE') {
        inputValue = selectedDate;
      }
      const flexTab = {
        display_label: this.metaData[i].display_label,
        display_label_code: this.metaData[i].display_label_code,
        displayEndColumnName: this.metaData[i].displayEndColumnName,
        input_value: inputValue
      };
      data.dependentFlexTab.push(flexTab);
    }
    return data;
  }
  /**
   * desc method to submit the request based on SIT and EIT
   * @param requestForm the form with all input values
   */
  saveRequest(requestForm: NgForm) {
    if (this.requestCode === 'XXX_HR_AD_HOC_COURSES_REQUEST' && requestForm.value.PEI_INFORMATION3 === '') {
      this.formSbmitted = false;
      this.showLoader = false;
      this.validationMessage = 'Please enter the course end date';
    } else if (this.requestForm.valid) {
      this.formSbmitted = true;
      this.showLoader = true;
      let formattedDate = '';
      const formArray = requestForm.value;
      for (const key of Object.keys(formArray)) {
        if (typeof formArray[key] === 'object') {
          if (formArray[key] && formArray[key].jsdate) {
            // if (formArray[key].date.month.toString().length === 1) {
            //   formArray[key].date.month = `0${formArray[key].date.month}`;
            // }
            // if (formArray[key].date.day.toString().length === 1) {
            //   formArray[key].date.day = `0${formArray[key].date.day}`;
            // }
            // formattedDate = `${formArray[key].date.year}-${
            //   formArray[key].date.month
            //   }-${formArray[key].date.day} 00:00:00`;
            formattedDate = `${this.datePipe.transform(new Date(formArray[key].jsdate), 'yyyy-MM-dd')} 00:00:00`;
            requestForm.value[key] = formattedDate;
          }
        }
      }
      if (this.requestType === 'EIT') {
        requestForm.value.informationType = this.requestCode;
        requestForm.value.informationCategory = this.requestCode;
        const data = {
          mobEITTab: [],
          userComments: '',
          eitAttachementTab: []
        };
        if (this.uploadedFile.length) {
          this.uploadedFile.forEach((file) => {
            const attachment = {
              title: file.title,
              documentId: file.documentId ? file.documentId : '',
              deleteFlag: '',
              description: file.comments,
              attachementName: file.attachmentName,
              fileData: file.fileData,
              attachementType: file.attachmentType
            };
            data.eitAttachementTab.push(attachment);
          });
          data.mobEITTab.push(requestForm.value);
          this.sitEitApiCall(data, 'eit');
        } else if (this.attachmetReq === 'Y') {
          this.formSbmitted = false;
          this.showLoader = false;
          this.errorMsg = 'Attachment is mandatory for this request';
        } else {
          data.mobEITTab.push(requestForm.value);
          this.sitEitApiCall(data, 'eit');
        }
      } else if (this.requestType === 'SIT') {
        const data = {
          flexStructure: this.requestCode,
          mobSITTab: [],
          mobSITAttachementTab: [],
          userComments: ''
        };
        if (this.uploadedFile.length) {
          this.formSbmitted = true;
          this.uploadedFile.forEach((file) => {
            const attachment = {
              title: file.title,
              documentId: file.documentId ? file.documentId : '',
              deleteFlag: '',
              description: file.comments,
              attachementName: file.attachmentName,
              fileData: file.fileData,
              attachementType: file.attachmentType
            };
            data.mobSITAttachementTab.push(attachment);
          });
          data.mobSITTab.push(requestForm.value);
          this.sitEitApiCall(data, 'sit');
        } else if (this.attachmetReq === 'Y') {
          this.formSbmitted = false;
          this.showLoader = false;
          this.errorMsg = 'Attachment is mandatory for this request';
        } else {
          data.mobSITTab.push(requestForm.value);
          this.sitEitApiCall(data, 'sit');
        }
      } else {
        this.showLoader = false;
      }
    } else {
      this.formSbmitted = false;
      this.errorMsg = 'Please enter all required fields';
    }
  }
  /**
   * @desc api call for submitting sit and eit
   * @param data data to be submitted
   * @param type specify sit or eit
   */
  sitEitApiCall(data, type) {
    this.saveRequestSubscription$ = this.reqSubmitService.submitEitRequest(data, type, this.managerAction, this.selectedUser).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          if (this.managerAction) {
            this.validationMessage = '';
            this.requestForm.reset();
            const toast = {
              show: true,
              status: 'success',
              message: response.returnMsg
            };
            this.location.back();
            this.common.showToast(toast);
          } else {
            this.approverList = response.approverList;
            this.transactionId = response.transactionId;
            if (!this.approverList.length) {
              this.submitRquest('Y');
            }
          }
        }
        if (response.returnCode === '1') {
          this.validationMessage = response.returnMsg;
        }
      },
      (error) => {
        this.validationMessage = '';
        this.showLoader = false;
      }
    );
  }
  submitRquest(action) {
    this.showLoader = true;
    const body = {
      'requestType': this.requestType,
      'submitFlag': action,
      'transactionId': this.transactionId,
    };
    this.approverSubscription$ = this.reqSubmitService.submitFinalRequest(body).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.requestForm.reset();
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.location.back();
          this.common.showToast(toast);
        } else if (response.returnCode === '7') {
          this.approverList = [];
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.common.showToast(toast);
        } else {
          this.approverList = [];
        }
      },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  gotoOvertimeDetials() {
    this.location.back();
  }
  roundNumber(item) {
    const number = this.requestForm.controls[item].value;
    if (number !== null && !isNaN(number) && !number.toString().includes('-')) {
      const roundedNumber = Math.round(number.toString().substring(0, 4));
      this.requestForm.controls[item].setValue(roundedNumber.toString());
    } else {
      this.requestForm.controls[item].setValue('');
    }
  }
  /**
   * @desc method to check if router needed to be deactivated if any input is there in form
   */
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if (this.requestForm && this.requestForm.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }/**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.uploadedFile.push(file);
  }
  deleteFile(index) {
    this.uploadedFile.splice(index, 1);
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  moreInfoClicked() {
    this.moreInfo = true;
  }
  ngOnDestroy() {
    this.routeSubscription$.unsubscribe();
    this.metaDataSubscription$.unsubscribe();
    this.dependentSubscription$.unsubscribe();
    if (this.saveRequestSubscription$) {
      this.saveRequestSubscription$.unsubscribe();
    }
    if (this.approverSubscription$) {
      this.approverSubscription$.unsubscribe();
    }
    this.confirm$.unsubscribe();
  }
}
