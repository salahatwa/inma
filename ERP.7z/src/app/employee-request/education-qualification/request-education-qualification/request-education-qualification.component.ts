import { Component, OnInit } from '@angular/core';
import { QualificationService } from '../../data-services/qualification.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';
import { Location, DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-request-education-qualification',
  templateUrl: './request-education-qualification.component.html',
  styleUrls: ['./request-education-qualification.component.scss']
})
export class RequestEducationQualificationComponent implements OnInit {
  tabIndex: number;
  metaData: any = [];
  showLoader: boolean;
  nextAction: any;
  hideActions = false;
  qualificationTab = {
    attendedEndDate: null,
    attendedStartDate: null,
    awardedDate: null,
    awardingBody: '',
    comments: '',
    completedAmount: '',
    completedUnits: '',
    endDate: null,
    fee: '',
    feeCurrency: '',
    fullTime: '',
    grade: '',
    groupRanking: '',
    qualificationId: '',
    reimbursementCondition: '',
    school: '',
    startDate: null,
    status: '',
    title: '',
    totalAmount: '',
    tutionMethod: null,
    type: ''
  };
  /*subjectTab = {
    endDate: '',
    grade: '',
    major: '',
    startDate: '',
    status: '',
    subjectName: ''
  };*/
  attachment = {
    attachementName: '',
    attachementType: '',
    deleteFlag: '',
    description: '',
    documentId: '',
    fileData: '',
    title: '',
  };
  form = {
    qualificationTab: [this.qualificationTab],
    subjectTab: [],
    attachmentTab: [],
    userName: this.common.getUserDetails().userName,
    language: this.common.getRequestLanguage()
  };
  validationMessage: string;
  dataCopy: any = {};
  constructor(
    private qualificationService: QualificationService,
    private common: CommonService,
    private location: Location,
    public readonly router: Router,
    private readonly datePipe: DatePipe
  ) { }

  ngOnInit() {
    this.tabIndex = 1;
  }
  next(submitFlag?: boolean) {
    /*if (this.tabIndex !== 3) {*/ // for skipping subject page
    if (submitFlag) {
      // if (this.tabIndex === 6) {
      this.nextAction = { action: true, tabIndex: 6, submit: true };
      // }
    } else {
      this.nextAction = { action: true, tabIndex: this.tabIndex, submit: false };
    }
    /*} else {
      this.tabIndex = this.tabIndex + 2;
    }*/
  }
  prev() {
    this.nextAction.action = false;
    /*if (this.tabIndex !== 5) {*/ // for skipping subject page
    this.tabIndex = this.tabIndex - 1;
    /*} else {
      this.tabIndex = this.tabIndex - 2;
    }*/
  }

  formSubmitted(value) {
    this.form = value;
    setTimeout(() => {
      if (this.tabIndex < 6) {
        this.tabIndex = this.tabIndex + 1; // tab index increase.
      }
      if (this.tabIndex === 6 && this.nextAction.submit) {
        this.submitRequest();
      }
    });
  }
  submitRequest() {
    this.showLoader = true;
    this.dataCopy = JSON.parse(JSON.stringify(this.form));
    this.dataCopy.subjectTab.forEach(element => {
      element.startDate = element.startDate ? `${this.datePipe.transform(element.startDate.jsdate, 'dd-MMM-yyyy')}` : '';
      element.endDate = element.endDate ? `${this.datePipe.transform(element.endDate.jsdate, 'dd-MMM-yyyy')}` : '';
    });
    if (this.dataCopy.qualificationTab[0].startDate && this.dataCopy.qualificationTab[0].startDate.jsdate) {
      this.dataCopy.qualificationTab[0].startDate =
        `${this.datePipe.transform(this.dataCopy.qualificationTab[0].startDate.jsdate, 'dd-MMM-yyyy')}`;
    }
    if (this.dataCopy.qualificationTab[0].endDate && this.dataCopy.qualificationTab[0].endDate.jsdate) {
      this.dataCopy.qualificationTab[0].endDate =
        `${this.datePipe.transform(this.dataCopy.qualificationTab[0].endDate.jsdate, 'dd-MMM-yyyy')}`;
    }
    if (this.dataCopy.qualificationTab[0].attendedEndDate && this.dataCopy.qualificationTab[0].attendedEndDate.jsdate) {
      this.dataCopy.qualificationTab[0].attendedEndDate =
        `${this.datePipe.transform(this.dataCopy.qualificationTab[0].attendedEndDate.jsdate, 'dd-MMM-yyyy')}`;
    }
    if (this.dataCopy.qualificationTab[0].attendedStartDate && this.dataCopy.qualificationTab[0].attendedStartDate.jsdate) {
      this.dataCopy.qualificationTab[0].attendedStartDate =
        `${this.datePipe.transform(this.dataCopy.qualificationTab[0].attendedStartDate.jsdate, 'dd-MMM-yyyy')}`;
    }
    if (this.dataCopy.qualificationTab[0].awardedDate && this.dataCopy.qualificationTab[0].awardedDate.jsdate) {
      this.dataCopy.qualificationTab[0].awardedDate =
        `${this.datePipe.transform(this.dataCopy.qualificationTab[0].awardedDate.jsdate, 'dd-MMM-yyyy')}`;
    }
    if (this.dataCopy.qualificationTab[0].fullTime == 'true') {
      this.dataCopy.qualificationTab[0].fullTime = 'Y';
    } else {
      this.dataCopy.qualificationTab[0].fullTime = 'N';
    }
    this.qualificationService.submitRequest(this.dataCopy).subscribe(
      response => {
        this.validationMessage = '';
        if (response.returnCode === '0') {
          const toast = ToastSuccess;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
          this.router.navigate(['/employee-request/education-and-qualification']);
        } else if (response.returnCode === '1') {
          this.tabIndex = 6;
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        } else {
          this.tabIndex = 6;
        }
        this.showLoader = false;
      },
      () => {
        this.tabIndex = 6;
        this.validationMessage = '';
        this.showLoader = false;
      }
    );
  }
  hideEducationActions(hide) {
    this.hideActions = hide;
  }
}
