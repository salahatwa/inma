import { Component, OnInit, Input, Output, ViewChild, EventEmitter, SimpleChanges } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription, Subject } from 'rxjs';
import { MetadataService } from 'src/app/employee-request/data-services/metadata.service';

@Component({
  selector: 'app-tution-information',
  templateUrl: './tution-information.component.html',
  styleUrls: ['./tution-information.component.scss']
})
export class TutionInformationComponent implements OnInit {
  @Input() metaData;
  @Input() nextAction;
  @Input() form;
  @Output() updatedForm = new EventEmitter();
  @ViewChild('resignationForm3') form1: NgForm;
  private metadataSubscriptionTution$: Subscription = new Subscription;
  counterTution$ = new Subject<number>();
  eduTution$: Subscription;
  formSubmit: boolean;
  showLoader: boolean;
  metaDataDropdown: any = [];
  constructor(
    private metadataService: MetadataService
  ) { }

  ngOnInit() {
    this.eduTution$ = this.counterTution$.subscribe(
      value => {
        if (value === 2) {
          this.showLoader = false;
        }
      }
    );
    this.getDropdownMetaData();
  }
  submitEducation(forms: NgForm) {
    this.formSubmit = true;
    if (forms.valid) {
      this.updatedForm.emit(this.form);
    }
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges) {
    // tslint:disable-next-line: forin
    for (const propName in changes) {
      const change = changes[propName];
      const curVal = change.currentValue;
      const prevVal = JSON.stringify(change.previousValue);
      const changeLog = `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`;
      if (propName === 'nextAction' && (curVal && curVal.action === true && curVal.tabIndex === 5)) {
        this.form1.ngSubmit.emit();
      }
    }
  }
  getDropdownMetaData() {
    this.showLoader = true;
    const types = ['TD', 'FC'];
    this.callMetaDataApi(types);
  }
  callMetaDataApi(typeArray: any) {
    let counter = 0;
    typeArray.forEach(type => {
      this.metadataSubscriptionTution$.add(this.metadataService.getMetadata(type).subscribe(
        response => {
          counter++;
          this.counterTution$.next(counter);
          if (response.res.returnCode === '0') {
            this.metaDataDropdown[response.type] = response.res.lookupTab;
          }
        },
        () => {
          counter++;
          this.counterTution$.next(counter);
        }
      ));
    });
  }
}
