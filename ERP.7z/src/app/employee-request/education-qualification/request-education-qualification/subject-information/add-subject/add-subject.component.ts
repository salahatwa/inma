import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription, Subject } from 'rxjs';
import { MetadataService } from 'src/app/employee-request/data-services/metadata.service';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { ConstantProvider as CONSTANT, ToastFailed } from './../../../../../shared/constants/globalConstants';

@Component({
  selector: 'app-add-subject',
  templateUrl: './add-subject.component.html',
  styleUrls: ['./add-subject.component.scss']
})
export class AddSubjectComponent implements OnInit {
  @Output() setSubject = new EventEmitter();
  @Input() editData;
  @Input() form;
  private metadataSubscriptionAddSubject$: Subscription = new Subscription;
  counterSub$ = new Subject<number>();
  eduSub$: Subscription;
  subjectTab: any = {
    endDate: '',
    grade: '',
    major: null,
    startDate: '',
    status: null,
    subjectName: null,
    subjectNameValue: '',
    majorName: '',
    statusName: '',
    id: null
  };
  showLoader: boolean;
  metaData: any = [];
  formSubmit: boolean;
  myOptions: INgxMyDpOptions = {
    dateFormat: CONSTANT.DATE_FROMAT,
    firstDayOfWeek: 'su'
  };
  constructor(
    private metadataService: MetadataService,
    private common: CommonService
  ) { }

  ngOnInit() {
    this.eduSub$ = this.counterSub$.subscribe(
      value => {
        if (value === 2) {
          this.showLoader = false;
          if (this.editData && this.editData.id) {
            // setTimeout(() => {
            this.setData(this.editData);
            // }, 2000);
          }
        }
      }
    );
    this.getDropdownMetaData();
  }
  setData(data) {
    this.subjectTab = {
      endDate: data.endDate,
      grade: data.grade,
      major: data.major,
      startDate: data.startDate,
      status: data.status,
      subjectName: data.subjectName,
      subjectNameValue: data.subjectNameValue,
      majorName: data.majorName,
      statusName: data.statusName,
      id: data.id
    };
  }
  addSubject(form: NgForm) {
    this.formSubmit = true;
    const data = this.form.qualificationTab[0];
    if ((this.subjectTab.startDate && this.subjectTab.endDate) &&
      (new Date(this.subjectTab.startDate.jsdate).setHours(0, 0, 0, 0) > new Date(this.subjectTab.endDate.jsdate).setHours(0, 0, 0, 0))) {
      const toast = ToastFailed;
      toast.message = 'Study start date should be greater than actual completion date';
      this.common.showToast(toast);
    } else if (((this.subjectTab.startDate && data.startDate) &&
      (new Date(this.subjectTab.startDate.jsdate) < new Date(data.startDate.jsdate))) ||
      (((this.subjectTab.endDate && data.endDate)) &&
        (new Date(this.subjectTab.endDate.jsdate) > new Date(data.endDate.jsdate)))) {
      const toast = ToastFailed;
      toast.message = 'Study start date and actual completion date should be inside qualification start date and completion date';
      this.common.showToast(toast);
    } else if (form.valid) {
      // this.subjectTab.subjectNameValue = this.subjectTab.subjectName.value,
      // this.subjectTab.subjectName = this.subjectTab.subjectName;
      this.subjectTab.subjectNameValue = this.metaData['SD'].filter(element => {
        return element.key === this.subjectTab.subjectName;
      });
      this.subjectTab.subjectNameValue = this.subjectTab.subjectNameValue[0].value;

      // this.subjectTab.majorName = this.subjectTab.major ? this.subjectTab.major.value : '';
      // this.subjectTab.major = this.subjectTab.major ? this.subjectTab.major.key : '';
      if (this.subjectTab.major) {
        this.subjectTab.majorName = this.metaData['SUB_MAJOR'].filter(element => {
          return element.key === this.subjectTab.major;
        });
        this.subjectTab.majorName = this.subjectTab.majorName[0].value;
      }
      // this.subjectTab.statusName = this.subjectTab.status.value;
      // this.subjectTab.status = this.subjectTab.status.key;
      this.subjectTab.statusName = this.metaData['SUB_STATUS'].filter(element => {
        return element.key === this.subjectTab.status;
      });
      this.subjectTab.statusName = this.subjectTab.statusName[0].value;

      this.setSubject.emit(this.subjectTab);
    }
  }
  getDropdownMetaData() {
    this.showLoader = true;
    const types = ['SD', 'SUB_STATUS', 'SUB_MAJOR'];
    this.callMetaDataApi(types);
  }
  callMetaDataApi(typeArray: any) {
    let counter = 0;
    typeArray.forEach(type => {
      this.metadataSubscriptionAddSubject$.add(this.metadataService.getMetadata(type).subscribe(
        response => {
          counter++;
          this.counterSub$.next(counter);
          if (response.res.returnCode === '0') {
            this.metaData[response.type] = response.res.lookupTab;
          }
        },
        () => {
          counter++;
          this.counterSub$.next(counter);
        }
      ));
    });
  }
  closeSubject() {
    this.setSubject.emit(false);
  }
}
