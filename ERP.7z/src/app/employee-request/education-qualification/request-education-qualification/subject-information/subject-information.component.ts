import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-subject-information',
  templateUrl: './subject-information.component.html',
  styleUrls: ['./subject-information.component.scss']
})
export class SubjectInformationComponent implements OnInit {
  // subjects = [];
  subjectId = 0;
  constructor(
    private readonly datePipe: DatePipe
  ) { }
  showAddSubject = false;
  data: any = {};
  @Input() nextAction;
  @Input() form;
  @Output() updatedForm = new EventEmitter();
  @Output() addSubjectPop = new EventEmitter();
  ngOnInit() {
  }
  setSubject(subjectTab) {
    if (subjectTab === false) {
      this.showAddSubject = false;
      this.addSubjectPop.emit(false);
    } else {
        subjectTab.startDateCopy = subjectTab.startDate ? `${this.datePipe.transform(subjectTab.startDate.jsdate, 'dd-MMM-yyyy')}` : '';
        subjectTab.endDateCopy = subjectTab.endDate ? `${this.datePipe.transform(subjectTab.endDate.jsdate, 'dd-MMM-yyyy')}` : '';
      if (subjectTab.id && subjectTab.id !== 0) {
        this.form.subjectTab[subjectTab.id - 1] = subjectTab;
      } else {
        subjectTab.id = this.subjectId + 1;
        this.subjectId++;
        this.form.subjectTab.push(subjectTab);
      }
      this.addSubjectPop.emit(false);
      this.showAddSubject = false;
    }
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges) {
    // tslint:disable-next-line: forin
    for (const propName in changes) {
      const change = changes[propName];
      const curVal = change.currentValue;
      const prevVal = JSON.stringify(change.previousValue);
      const changeLog = `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`;
      if (propName === 'nextAction' && (curVal && curVal.action === true && curVal.tabIndex === 4)) {
        this.updatedForm.emit(this.form);
      }
    }
  }
  showAddSubjectPopup() {
    this.data = {};
    this.showAddSubject = true;
    this.addSubjectPop.emit(true);
  }
  deleteSubject(indexSelected) {
    this.form.subjectTab = this.form.subjectTab.filter((element, index) => {
      return index !== indexSelected;
    });
  }
  editSubject(subjectInfo) {
    this.data = subjectInfo;
    this.showAddSubject = true;
    this.addSubjectPop.emit(true);
  }
}
