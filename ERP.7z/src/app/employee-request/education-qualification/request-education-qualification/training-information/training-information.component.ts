import { Component, OnInit, Input, EventEmitter, Output, ViewChild, SimpleChanges } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-training-information',
  templateUrl: './training-information.component.html',
  styleUrls: ['./training-information.component.scss']
})
export class TrainingInformationComponent implements OnInit {
  @Input() nextAction;
  @Input() form;
  @Output() updatedForm = new EventEmitter();
  @ViewChild('resignationForm5') form1: NgForm;
  formSubmit: boolean;
  showAddAttachment: boolean;
  showViewAttachmentSec: any;
  attachmentValidation: string;
  constructor() { }

  ngOnInit() {
  }
  submitEducation(forms: NgForm) {
    this.formSubmit = true;
    if (forms.valid) {
      this.updatedForm.emit(this.form);
    }
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges) {
    // tslint:disable-next-line: forin
    for (const propName in changes) {
      const change = changes[propName];
      const curVal = change.currentValue;
      const prevVal = JSON.stringify(change.previousValue);
      const changeLog = `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`;
      if (propName === 'nextAction' && (curVal && curVal.action === true && curVal.tabIndex === 6 && curVal.submit === true)) {
        this.form1.ngSubmit.emit();
      }
    }
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  cancelSelectedFile(event) {
    this.showAddAttachment = false;
  }
  attachDismiss(attach) {
    this.showViewAttachmentSec = attach;
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  fileDismiss() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    file.deleteFlag = '';
    file.attachementName = file.attachmentName;
    file.attachementType = file.attachmentType;
    file.documentId = 0;
    file.description = file.comments;
    this.form.attachmentTab.push(file);
    this.attachmentValidation = '';
  }
  deleteFile(index) {
    this.form.attachmentTab.splice(index, 1);
  }
}
