import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, ViewChild } from '@angular/core';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { NgForm } from '@angular/forms';
import { ConstantProvider as CONSTANT, ToastFailed } from '../../../../shared/constants/globalConstants';
import { QualificationService } from 'src/app/employee-request/data-services/qualification.service';
@Component({
  selector: 'app-school-information',
  templateUrl: './school-information.component.html',
  styleUrls: ['./school-information.component.scss']
})
export class SchoolInformationComponent implements OnInit {
  @Input() nextAction;
  @Input() form;
  @Output() updatedForm = new EventEmitter();
  @ViewChild('resignationForm2') form2: NgForm;
  formSubmit: boolean;
  myOptions: INgxMyDpOptions = {
    dateFormat: CONSTANT.DATE_FROMAT,
    firstDayOfWeek: 'su'
  };
  showSchoolListMetaData: any = [];
  showSchoolList = false;
  showLoader: boolean;
  showLoaderSearch: boolean;
  constructor(
    private qualificationService: QualificationService,
    private common: CommonService
  ) { }

  ngOnInit() {
    // this.getScools(); // avoid call school searhing API initialy
  }
  submitEducation(forms: NgForm) {
    this.formSubmit = true;
    const data = this.form.qualificationTab[0];
    if ((data.attendedStartDate && data.attendedEndDate) &&
      (new Date(data.attendedStartDate.jsdate).setHours(0, 0, 0, 0) > new Date(data.attendedEndDate.jsdate).setHours(0, 0, 0, 0))) {
      const toast = ToastFailed;
      toast.message = 'Attendance start date should be greater than attendance end date';
      this.common.showToast(toast);
    } else if (((data.attendedStartDate && data.startDate)
      && (new Date(data.attendedStartDate.jsdate) > new Date(data.startDate.jsdate))) ||
      (((data.attendedEndDate && data.endDate)) && (new Date(data.attendedEndDate.jsdate) < new Date(data.endDate.jsdate)))) {
      const toast = ToastFailed;
      toast.message = 'Attendance start date and Attendance end date should be outside of study start date and end date';
      this.common.showToast(toast);
    } else if (forms.valid) {
      this.updatedForm.emit(this.form);
    }
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges) {
    // tslint:disable-next-line: forin
    for (const propName in changes) {
      const change = changes[propName];
      const curVal = change.currentValue;
      const prevVal = JSON.stringify(change.previousValue);
      const changeLog = `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`;
      if (propName === 'nextAction' && (curVal && curVal.action === true && curVal.tabIndex === 2)) {
        this.form2.ngSubmit.emit();
      }
    }
  }
  getScools() {
    this.showSchoolListMetaData = [];
    this.showLoaderSearch = true;
    const data = {
      'searchText': this.form.qualificationTab[0].school,
      'type': 'SCHOOL'
    };
    this.qualificationService.getSchools(data).subscribe(
      response => {
        this.showLoaderSearch = false;
        if (response.returnCode === '0') {
          this.showSchoolListMetaData = response.lookupTab;
        }
      },
      () => {
        this.showLoaderSearch = false;
      }
    );
  }
  clickSchool() {
    this.showSchoolList = true;
  }
  changeSchool() {
    this.getScools();
    this.showSchoolList = true;
  }
  chooseSchool(data) {
    this.showSchoolList = false;
    this.form.qualificationTab[0].school = data.value;
  }
}
