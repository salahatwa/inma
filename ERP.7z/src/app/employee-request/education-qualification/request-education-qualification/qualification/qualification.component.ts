import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, Input, SimpleChanges, Output, EventEmitter, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { Subscription, Subject } from 'rxjs';
import { MetadataService } from 'src/app/employee-request/data-services/metadata.service';
import { ConstantProvider as CONSTANT, ToastFailed } from '../../../../shared/constants/globalConstants';

@Component({
  selector: 'app-qualification',
  templateUrl: './qualification.component.html',
  styleUrls: ['./qualification.component.scss']
})
export class QualificationComponent implements OnInit {
  private metadataSubscriptionEdu$: Subscription = new Subscription;
  counterEdu$ = new Subject<number>();
  subEdu$: Subscription;
  @Input() nextAction;
  @Input() form;
  @Output() updatedForm = new EventEmitter();
  @ViewChild('resignationForm1') form1: NgForm;
  formSubmit: boolean;
  myOptions: INgxMyDpOptions = {
    dateFormat: CONSTANT.DATE_FROMAT,
    firstDayOfWeek: 'su'
  };
  showLoader: boolean;
  metaData: any = [];
  constructor(
    private metadataService: MetadataService,
    private common: CommonService
  ) { }
  ngOnInit() {
    this.subEdu$ = this.counterEdu$.subscribe(
      value => {
        if (value === 2) {
          this.showLoader = false;
        }
      }
    );
    this.getDropdownMetaData();
  }
  submitEducation(forms: NgForm) {
    this.formSubmit = true;
    const data = this.form.qualificationTab[0];
    if ((data.startDate && data.endDate) &&
      (new Date(data.startDate.jsdate).setHours(0, 0, 0, 0) > new Date(data.endDate.jsdate).setHours(0, 0, 0, 0))) {
      const toast = ToastFailed;
      toast.message = 'Study start date should be greater than actual completion date';
      this.common.showToast(toast);
    } else if (forms.valid) {
      this.updatedForm.emit(this.form);
    }
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges) {
    // tslint:disable-next-line: forin
    for (const propName in changes) {
      const change = changes[propName];
      const curVal = change.currentValue;
      const prevVal = JSON.stringify(change.previousValue);
      const changeLog = `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`;
      if (propName === 'nextAction' && (curVal && curVal.action === true && curVal.tabIndex === 1)) {
        this.form1.ngSubmit.emit();
      }
    }
  }
  getDropdownMetaData() {
    this.showLoader = true;
    const types = ['QUALIF_TYPE', 'EDU_STATUS'];
    this.callMetaDataApi(types);
  }
  callMetaDataApi(typeArray: any) {
    let counter = 0;
    typeArray.forEach(type => {
      this.metadataSubscriptionEdu$.add(this.metadataService.getMetadata(type).subscribe(
        response => {
          counter++;
          this.counterEdu$.next(counter);
          if (response.res.returnCode === '0') {
            this.metaData[response.type] = response.res.lookupTab;
          }
        },
        () => {
          counter++;
          this.counterEdu$.next(counter);
        }
      ));
    });
  }
}
