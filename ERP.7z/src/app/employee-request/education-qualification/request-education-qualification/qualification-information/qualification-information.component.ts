import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, Input, EventEmitter, Output, ViewChild, SimpleChanges } from '@angular/core';
import { NgForm } from '@angular/forms';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { ConstantProvider as CONSTANT, ToastFailed } from '../../../../shared/constants/globalConstants';

@Component({
  selector: 'app-qualification-information',
  templateUrl: './qualification-information.component.html',
  styleUrls: ['./qualification-information.component.scss']
})
export class QualificationInformationComponent implements OnInit {
  @Input() metaData;
  @Input() nextAction;
  @Input() form;
  @Output() updatedForm = new EventEmitter();
  @ViewChild('resignationForm4') form1: NgForm;
  formSubmit: boolean;
  myOptions: INgxMyDpOptions = {
    dateFormat: CONSTANT.DATE_FROMAT,
    firstDayOfWeek: 'su'
  };
  constructor(
    private common: CommonService
  ) { }

  ngOnInit() {
  }
  submitEducation(forms: NgForm) {
    this.formSubmit = true;
    const data = this.form.qualificationTab[0];
    if ((data.awardedDate && data.attendedEndDate) &&
      (new Date(data.awardedDate.jsdate).setHours(0, 0, 0, 0) < new Date(data.attendedEndDate.jsdate).setHours(0, 0, 0, 0))) {
      const toast = ToastFailed;
      toast.message = 'Award end date should be greater than attendance end date';
      this.common.showToast(toast);
    } else if (forms.valid) {
      this.updatedForm.emit(this.form);
    }
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges) {
    // tslint:disable-next-line: forin
    for (const propName in changes) {
      const change = changes[propName];
      const curVal = change.currentValue;
      const prevVal = JSON.stringify(change.previousValue);
      const changeLog = `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`;
      if (propName === 'nextAction' && (curVal && curVal.action === true && curVal.tabIndex === 3)) {
        this.form1.ngSubmit.emit();
      }
    }
  }
}
