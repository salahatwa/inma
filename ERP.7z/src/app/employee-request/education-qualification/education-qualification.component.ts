import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';
import { EducationAndQualificationService } from '../data-services/education-and-qualification.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-education-qualification',
  templateUrl: './education-qualification.component.html',
  styleUrls: ['./education-qualification.component.scss']
})
export class EducationQualificationComponent implements OnInit {
  educationQualifcations: any = [];
  showLoader: boolean;
  subscriptionEducation$: Subscription;
  noDataFound: any;
  returnMsg: any;
  constructor(
    private educationAndQualificationService: EducationAndQualificationService,
    private readonly common: CommonService,
    private readonly router: Router,
  ) { }

  ngOnInit() {
    this.getEducationandQualifcationSummary();
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy() {
    if (this.subscriptionEducation$) {
      this.subscriptionEducation$.unsubscribe();
    }
  }
  getEducationandQualifcationSummary() {
    this.educationQualifcations = [];
    this.showLoader = true;
    const userDetails = this.common.getUserDetails();
    const data = {
      'userName': userDetails.userName,
      'language': this.common.getRequestLanguage()
    };
    this.subscriptionEducation$ = this.educationAndQualificationService.getEducationandQualifcationSummary(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.educationQualifcations = response.educationAndQualificationTab;
        } else {
          this.noDataFound = true;
          this.returnMsg = response.returnMsg;
        }
        this.showLoader = false;
      },
      error => {
        this.showLoader = false;
        this.noDataFound = true;
      }
    );
  }
  goToDetails(data) {
    this.educationAndQualificationService.qualificationDetails = data;
    this.router.navigate(['/employee-request/education-and-qualification-details']);
  }
}
