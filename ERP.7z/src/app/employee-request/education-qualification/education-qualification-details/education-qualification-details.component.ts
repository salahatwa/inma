import { Component, OnInit } from '@angular/core';
import { EducationAndQualificationService } from '../../data-services/education-and-qualification.service';

@Component({
  selector: 'app-education-qualification-details',
  templateUrl: './education-qualification-details.component.html',
  styleUrls: ['./education-qualification-details.component.scss']
})
export class EducationQualificationDetailsComponent implements OnInit {
  educationQualifcation: any = [];
  attachment = false;
  popupData: any;

  constructor(
    private educationAndQualificationService: EducationAndQualificationService,
  ) { }

  ngOnInit() {
    this.educationQualifcation = this.educationAndQualificationService.qualificationDetails;
  }
  viewDetails(data) {
    this.attachment = true;
    this.popupData = data;
  }
  closeAttachment(event) {
    this.attachment = event;
  }
}
