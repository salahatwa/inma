import { Component, OnInit } from '@angular/core';
import { ExpenseClaimService } from '../data-services/expense-claim.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-expense-claim',
  templateUrl: './expense-claim.component.html',
  styleUrls: ['./expense-claim.component.scss']
})
export class ExpenseClaimComponent implements OnInit {
  showLoader = false;
  expenseClaimdetails: any = [];
  noSummary = false;
  message = '';
  constructor(
    private expenseClaimService: ExpenseClaimService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getSummary();
  }
  getSummary() {
    this.showLoader = true;
    this.expenseClaimService.getExpenseClaimSummary().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.expenseClaimdetails = response.expenseDetailsTab;
        } else if (response.returnCode === '9') {
          this.expenseClaimdetails = [];
          this.noSummary = true;
          this.message = response.returnMsg;
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  navToLines(index): void {
    this.router.navigate(['/employee-request/expense-claim/lines'], { queryParams: { id: index }});
  }
}
