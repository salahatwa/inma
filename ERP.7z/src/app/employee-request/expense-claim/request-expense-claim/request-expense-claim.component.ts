import { map } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { CommonService } from './../../../shared/services/common.service';
import { Location, DatePipe } from '@angular/common';
import { ExpenseClaimService } from './../../data-services/expense-claim.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';
import { INgxMyDpOptions } from 'ngx-mydatepicker';

@Component({
  providers: [DatePipe],
  selector: 'app-request-expense-claim',
  templateUrl: './request-expense-claim.component.html',
  styleUrls: ['./request-expense-claim.component.scss']
})
export class RequestExpenseClaimComponent implements OnInit {
  forms: any = {
    expenseId: '',
    expensePurpose: '',
    expenseLineDetails: [],
    expenseAttachementDetails: []
  };
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  validationMessage = '';
  attachmentValidation: string;
  showAddAttachment = false;
  showViewAttachmentSec = false;
  submitted = false;
  showLoader = false;
  backConfirm = false;
  canDeactivateFlag = false;
  // uploadedFile = [];
  base64TOView = '';
  index: number;
  private confirm$: Subject<boolean> = new Subject<boolean>();
  totalAmount = 0;
  constructor(
    private expenseClaimService: ExpenseClaimService,
    private location: Location,
    private common: CommonService,
    private readonly datePipe: DatePipe
  ) { }

  ngOnInit() {
  }
  submitrequest(form: NgForm) {
    this.submitted = true;
    this.forms.expenseLineDetails.forEach(element => {
      element.submitted = true;
    });
    /*let attachmentFlag = true;
    if (this.forms.expenseLineDetails.length) {
      this.forms.expenseLineDetails.forEach(element => {
        if (!element.attachmentTab.length) {
          this.validationMessage = 'Please add attachment for all expenses';
          attachmentFlag = false;
          return;
        }
      });
    }*/
    if (!this.forms.expenseLineDetails.length) {
      const toast = ToastFailed;
      toast.message = 'Please add a line before submitting';
      this.common.showToast(toast);
    } else if (form.valid) {
      if (this.forms.expenseLineDetails.length) {
        this.forms.expenseLineDetails.forEach(element => {
          if (element.expenseDate.jsdate) {
            element.expenseDate = `${this.datePipe.transform(element.expenseDate.jsdate, 'dd-MMM-yyyy')}`;
          }
        });
      }
      this.forms.expenseLineDetails.forEach((element, index) => {
        if (element.attachmentTab.length) {
          element.expenceDetailId = index.toString();
          const attachment = element.attachmentTab.map(item => ({ ...item, expenceDetailId: index.toString() }));
          this.forms.expenseAttachementDetails = [...this.forms.expenseAttachementDetails, ...attachment];
        }
        delete element.attachmentTab;
      });
      this.showLoader = true;
      this.expenseClaimService.submitExpenseClaim(this.forms).subscribe(
        response => {
          if (response.returnCode === '0') {
            this.canDeactivateFlag = true;
            const toast = ToastSuccess;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
            this.location.back();
          } else if (response.returnCode === '1') {
            //this.validationMessage = response.returnMsg;
            this.canDeactivateFlag = true;
            const toast = ToastFailed;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
            this.location.back();
          } else {
            this.location.back();
          }
          this.showLoader = false;
        },
        () => {
          this.location.back();
          this.validationMessage = '';
          this.showLoader = false;
        }
      );
    }
  }
  calculateTotalAmount() {
    this.totalAmount = this.forms.expenseLineDetails.reduce((accumulator, currentValue) =>
      accumulator + +currentValue.amount, 0
    );
  }
  addLine() {
    if (this.forms.expensePurpose) {
      this.forms.expenseLineDetails.push({
        amount: '',
        attachmentTab: [],
        description: '',
        expenseDate: '',
        expenceDetailId: '',
        submitted: false,
        additionalParam: ''
      });
    } else {
      const toast = ToastFailed;
      toast.message = 'Please add an expense purpose to add lines';
      this.common.showToast(toast);
    }
  }
  deleteLine(index) {
    if (index > -1) {
      this.forms.expenseLineDetails.splice(index, 1);
      this.totalAmount = this.forms.expenseLineDetails.reduce((accumulator, currentValue) =>
        accumulator + +currentValue.amount, 0
      );
    }
  }
  addAttachment(index) {
    this.index = index;
    this.showAddAttachment = true;
  }
  cancelSelectedFile(event) {
    this.showAddAttachment = false;
  }
  attachDismiss(attach) {
    this.showViewAttachmentSec = attach;
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  fileDismiss() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    // this.uploadedFile.push(file);
    const data = {
      'attachementName': file.attachmentName,
      'attachementType': file.attachmentType,
      'deleteFlag': 'N',
      'description': file.comments,
      'documentId': null,
      'fileData': file.fileData,
      'title': file.title
    };
    this.forms.expenseLineDetails[this.index].attachmentTab.push(data);
    this.attachmentValidation = '';
  }
  deleteFile(index, fileIndex) {
    // this.uploadedFile.splice(index, 1);
    this.forms.expenseLineDetails[fileIndex].attachmentTab.splice(index, 1);
  }
  viewIndexBasedAttachment(valArr) {
    this.showViewAttachmentSec = false;
    if (valArr != null) {
      this.base64TOView = valArr.fileData;
      this.showViewAttachmentSec = true;
    }
  }
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if ((this.forms.expensePurpose || this.forms.expenseLineDetails.length) && !this.canDeactivateFlag) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }

  }/**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
}
