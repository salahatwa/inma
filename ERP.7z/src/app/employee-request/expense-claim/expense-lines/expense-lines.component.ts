import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ExpenseClaimService } from '../../data-services/expense-claim.service';

@Component({
  selector: 'app-expense-lines',
  templateUrl: './expense-lines.component.html',
  styleUrls: ['./expense-lines.component.scss']
})
export class ExpenseLinesComponent implements OnInit {
  expenseClaimLineData: any = [];
  sub$: Subscription;
  id: number;
  showLoader = false;
  attachment = false;
  popupData: any;
  constructor(
    private expenseClaimService: ExpenseClaimService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.showLoader = true;
    this.sub$ = this.route
      .queryParams
      .subscribe(
        params => {
          this.showLoader = false;
          this.id = +params['id'];
          const data = this.expenseClaimService.expenseClaimData;
          if (this.id > (data.length - 1)) {
            this.router.navigate(['/employee-request/expense-claim']);
          } else {
            this.expenseClaimLineData = data[this.id].expenseLineTab;
          }
        },
        () => {
          this.showLoader = false;
          this.router.navigate(['/employee-request/expense-claim']);
        });
  }
  viewDetails(data) {
    this.attachment = true;
    this.popupData = data;
  }
  closeAttachment(event) {
    this.attachment = event;
  }
}
