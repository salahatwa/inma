import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { Observable, throwError } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CardInstructionsService {

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }

  creditCardInfo(data): Observable<any> {
    const url = this.url.getcreditCardInfo();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {

      }),
      catchError((error) => {

        return throwError(error);
      })
    );
  }
}
