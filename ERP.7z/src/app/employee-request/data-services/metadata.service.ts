import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MetadataService {

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }
  getMetadata(dropdownType): Observable<any> {
    const body = {
      type: dropdownType,
      userName: this.common.getUserDetails().userName,
      language: this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC'
    };
    const url = this.url.getResignationResonsUrl();
    return this.http.post<any>(url, body).pipe(
      map(response => {
        const value = {
          type: body.type,
          res: response
        };
        return value;
      })
    );
  }
}
