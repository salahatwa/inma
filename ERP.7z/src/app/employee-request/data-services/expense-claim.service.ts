import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable, pipe } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ExpenseClaimService {
  expenseClaimData: any = [];
  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }
  getExpenseClaimSummary(): Observable<any> {
    const body = {
      userName: this.common.getUserDetails().userName,
      language: this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC'
    };
    const url = this.url.getExpenseClaimSummaryUrl();
    return this.http.post<any>(url, body).pipe(
      tap((response) => {
        this.expenseClaimData = response.expenseDetailsTab;
      })
    );
  }
  submitExpenseClaim(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    data.type = 'SUBMITTED';
    const url = this.url.getExpenseSubmitUrl();
    return this.http.post<any>(url, data);
  }
}
