import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class RequestMetaService {
  userDetails: any;

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }
  getRequestMetaData(requestType: string, requestCode: string, user?: string, mngrAction?: boolean): Observable<any> {
    this.userDetails = this.common.getUserDetails();
    const data = {
      userName: mngrAction ? user : this.userDetails.userName,
      loggedInUser: this.userDetails.userName,
      language: '',
      requestCode: '',
      requestType: ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    data.requestType = requestType;
    data.requestCode = requestCode;
    const url = this.url.getSitEitMetaData();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {

      }),
      catchError((error) => {

        return throwError(error);
      })
    );
  }
  getDependentFlexValueSet(body, user?, mngrAction?): Observable<any> {
    const url = this.url.getDependentFlexValueSetUrl();
    const userDetails = this.common.getUserDetails();
    body.userName = mngrAction ? user : userDetails.userName;
    body.loggedInUser = this.userDetails.userName;
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }

    body.language = language;
    return this.http.post<any>(url, body);
  }
}
