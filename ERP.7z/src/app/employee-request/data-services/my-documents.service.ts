import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class MyDocumentsService {

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }
  getDocumentsSummary(): Observable<any> {
    const body = {
      userName: this.common.getUserDetails().userName,
      language: this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC'
    };
    const url = this.url.getMyDocumentsSummaryUrl();
    return this.http.post<any>(url, body);
  }
  createMyDocument(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    const url = this.url.getCreateMyDocumentsUrl();
    return this.http.post<any>(url, data);
  }
}
