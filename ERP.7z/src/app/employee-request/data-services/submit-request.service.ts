import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SubmitRequestService {

  constructor(
    private readonly http: HttpClient,
    private readonly common: CommonService,
    private readonly url: UrlGeneratorService
  ) { }

  submitEitRequest(body, type, mngrAction?, user?): Observable<any> {
    const userDetails = this.common.getUserDetails();
    // const body = {
    //   'userName': userDetails.userName,
    //   'processName': '',
    // }
    body.userName = userDetails.userName;
    body.selectedUser = user;
    let url;
    if (mngrAction) {
      url = this.url.getManagerActionsSitUrl();
    } else {
      if (type === 'eit') {
        url = this.url.getEitSubmitUrlV2();
      } else {
        url = this.url.getSitSubmitUrlV2();
      }
    }
    return this.http.post<any>(url, body);
  }
  submitFinalRequest(body): Observable<any> {
    const userDetails = this.common.getUserDetails();
    body.userName = userDetails.userName;
    const url = this.url.getEmployeeRequestSubmitUrl();
    return this.http.post<any>(url, body);
  }
}
