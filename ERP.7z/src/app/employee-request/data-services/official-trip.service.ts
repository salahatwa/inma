import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OfficialTripService {
  officialTripData: any = [];
  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) {}
  getOfficialTripRequestSummary(): Observable<any> {
    const body = {
      userName: this.common.getUserDetails().userName,
      language: this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC'
    };
    const url = this.url.getOfficialTripSummaryUrl();
    return this.http.post<any>(url, body).pipe(
      tap((response) => {
        this.officialTripData = response.officialTripDetails;
      })
  );
  }
  submitRequest(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    const url = this.url.getOfficialTripSubmitUrl();
    return this.http.post<any>(url, data);
  }
}
