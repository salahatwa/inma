import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { CommonService } from '../../shared/services/common.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RequestDetailsService {

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }

  getRequestdetails(requestType: string, requestCode: string, user?: string, mngrAction?: boolean): Observable<any> {
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: mngrAction ? user : userDetails.userName,
      loggedInUser: userDetails.userName,
      language: '',
      analysisCriteriaId: '',
      extraInfoId: '',
      requestCode: '',
      requestType: ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    data.requestType = requestType;
    data.requestCode = requestCode;
    const url = this.url.getSitEitDetails();
    return this.http.post<any>(url, data);
  }
}
