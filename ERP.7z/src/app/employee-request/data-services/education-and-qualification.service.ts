import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class EducationAndQualificationService {
  qualificationDetails: any = [];

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient
  ) {

  }
  getEducationandQualifcationSummary(data): Observable<any> {
    const url = this.url.getEducationandQualifcationSummaryUrl();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
}
