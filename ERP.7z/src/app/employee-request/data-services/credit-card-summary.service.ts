import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { Observable, throwError } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CreditCardSummaryService {

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }

  creditCardSummary(data): Observable<any> {
    const url = this.url.getcreditCardSummary();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
        console.log(response);
      }),
      catchError((error) => {
        console.log(error);
        return throwError(error);
      })
    );
  }
}
