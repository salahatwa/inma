import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { CommonService } from '../../shared/services/common.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RequestListingService {
  userDetails: any;
  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }

  getRequestList(): Observable<any> {
    this.userDetails = this.common.getUserDetails();
    const data = {
      userName: this.userDetails.userName,
      language : 'AMERICAN',
      pDeviceType: 'WEB'
    };
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        data.language = 'ARABIC';
      }
    }
    const url = this.url.getRequestListingUrl();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {

      }),
      catchError((error) => {

        return throwError(error);
      })
    );
  }
}
