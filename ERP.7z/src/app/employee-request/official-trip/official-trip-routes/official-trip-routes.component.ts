import { Subscription } from 'rxjs';
import { OfficialTripService } from './../../data-services/official-trip.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-official-trip-routes',
  templateUrl: './official-trip-routes.component.html',
  styleUrls: ['./official-trip-routes.component.scss']
})
export class OfficialTripRoutesComponent implements OnInit, OnDestroy {
  officialTripData: any = [];
  sub$: Subscription;
  id: number;
  showLoader = false;
  constructor(
    private officaiTripService: OfficialTripService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.showLoader = true;
    this.sub$ = this.route
      .queryParams
      .subscribe(params => {
        this.showLoader = false;
        this.id = +params['id'];
        const data = this.officaiTripService.officialTripData;
        if (this.id > (data.length - 1)) {
          this.router.navigate(['/employee-request/official-trip']);
        } else {
          this.officialTripData = data[this.id].officialTripRoutes;
        }
      },
        () => {
          this.showLoader = false;
          this.router.navigate(['/employee-request/official-trip']);
        });
  }
  ngOnDestroy() {
    this.sub$.unsubscribe();
  }
}
