import { Router } from '@angular/router';
import { OfficialTripService } from './../data-services/official-trip.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-official-trip',
  templateUrl: './official-trip.component.html',
  styleUrls: ['./official-trip.component.scss']
})
export class OfficialTripComponent implements OnInit {
  officialTripData: any = [];
  noSummary = false;
  showLoader = false;
  message = '';
  constructor(
    private officialTripService: OfficialTripService,
    private router: Router
  ) { }

  ngOnInit() {
    this.getOfficialRequestData();
  }
  getOfficialRequestData() {
    this.showLoader = true;
    this.officialTripService.getOfficialTripRequestSummary().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.officialTripData = response.officialTripDetails;
          this.officialTripService.officialTripData = response.officialTripDetails;
        } else if (response.returnCode === '9') {
          this.officialTripService.officialTripData = [];
          this.noSummary = true;
          this.message = response.returnMsg;
        }
        this.showLoader = false;
      },
      () => {
        this.officialTripService.officialTripData = [];
        this.showLoader = false;
      }
    );
  }
  navToRoutes(index): void {
    this.router.navigate(['/employee-request/official-trip/routes'], { queryParams: { id: index }});
  }
}
