import { Location, DatePipe } from '@angular/common';
import { CommonService } from './../../../shared/services/common.service';
import { MetadataService } from './../../data-services/metadata.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { NgForm } from '@angular/forms';
import { Subject, Observable, Subscription } from 'rxjs';
import { OfficialTripService } from '../../data-services/official-trip.service';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';

@Component({
  providers: [DatePipe],
  selector: 'app-request-official-trip',
  templateUrl: './request-official-trip.component.html',
  styleUrls: ['./request-official-trip.component.scss']
})
export class RequestOfficialTripComponent implements OnInit, OnDestroy {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  forms: any = {
    officialTripTab: [{
      officialTripType: '',
      destinationType: '',
      title: '',
      employeeName: this.common.getUserDetails().fullName,
      backToWork: '',
      commetmentAmount: '',
      commetmentUOM: '',
      commetmentRequired: '',
      commetmentPeriod: '',
      destinationCity: '',
      country: '',
    }],
    routsTab: []
  };
  metaData: any = [];
  submitted = false;
  showLoader = false;
  backConfirm = false;
  sub$: Subscription;
  validationMessage = '';
  userName = '';
  counter$ = new Subject<number>();
  submitSubscripiton$: Subscription;
  private confirm$: Subject<boolean> = new Subject<boolean>();
  private metadataSubscription$: Subscription = new Subscription;
  sumbittedFlag = false;
  constructor(
    private metadataService: MetadataService,
    private officialTripService: OfficialTripService,
    private common: CommonService,
    private location: Location,
    private readonly datePipe: DatePipe,
  ) { }

  ngOnInit() {
    this.sub$ = this.counter$.subscribe(
      value => {
        if (value === 8) {
          this.showLoader = false;
        }
      }
    );
    this.getDropdownMetaData();
    this.userName = this.common.getUserDetails().userName;
  }
  getDropdownMetaData() {
    this.showLoader = true;
    const types = ['COUNTRY', 'COMMETMENT_UOM', 'COMMETMENT_REQ', 'OT', 'DT', 'BTW', 'TC', 'AC'];
    this.callMetaDataApi(types);
  }
  callMetaDataApi(typeArray: any) {
    let counter = 0;
    typeArray.forEach(type => {
      this.metadataSubscription$.add(this.metadataService.getMetadata(type).subscribe(
        response => {
          counter++;
          this.counter$.next(counter);
          if (response.res.returnCode === '0') {
            this.metaData[response.type] = response.res.lookupTab;
          }
        },
        () => {
          counter++;
          this.counter$.next(counter);
        }
      ));
    });
  }
  addRoute() {
    if (!this.forms.officialTripTab[0].destinationType) {
      const toast = ToastFailed;
      toast.message = 'A value must be entered for Destination Type';
      this.common.showToast(toast);
    } else {
      this.forms.routsTab.push({
        'eventStart': '',
        'eventEnd': '',
        'actualDays': null,
        'flightFrom': '',
        'flightTo': '',
        'flightDateFrom': '',
        'flightDateTo': '',
        'ticketsRequeired': '',
        'accommodationRequired': '',
        'submitted': false
      });
    }
  }
  deleteRoutes(index) {
    if (index > -1) {
      this.forms.routsTab.splice(index, 1);
    }
  }
  submitrequest(form: NgForm) {
    this.submitted = true;
    this.forms.routsTab.forEach(element => {
      element.submitted = true;
    });
    if (form.valid) {
      if (this.forms.routsTab.length) {
        this.forms.routsTab.forEach(element => {
          if (element.eventStart.jsdate) {
            element.eventStart = `${this.datePipe.transform(element.eventStart.jsdate, 'yyyy-MM-dd')} 00:00:00`;
          }
          if (element.eventEnd.jsdate) {
            element.eventEnd = `${this.datePipe.transform(element.eventEnd.jsdate, 'yyyy-MM-dd')} 00:00:00`;
          }
          if (element.flightDateFrom.jsdate) {
            element.flightDateFrom = `${this.datePipe.transform(element.flightDateFrom.jsdate, 'yyyy-MM-dd')} 00:00:00`;
          }
          if (element.flightDateTo.jsdate) {
            element.flightDateTo = `${this.datePipe.transform(element.flightDateTo.jsdate, 'yyyy-MM-dd')} 00:00:00`;
          }
        });
      }
      this.showLoader = true;
      this.forms.type = 'SUBMITED';
      this.forms.requestId = '';
      this.submitSubscripiton$ = this.officialTripService.submitRequest(this.forms).subscribe(
        response => {
          this.showLoader = false;
          this.validationMessage = '';
          if (response.returnCode === '0') {
            const toast = ToastSuccess;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
            this.sumbittedFlag = true;
            this.location.back();
          } else if (response.returnCode === '1') {
            this.validationMessage = response.returnMsg;
          }
        },
        () => {
          this.validationMessage = '';
          this.showLoader = false;
        }
      );
    }
  }
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    let checkDirty = false;
    Object.keys(this.forms.officialTripTab[0]).forEach(element => {
      if (this.forms.officialTripTab[0][element]) {
        checkDirty = true;
        return;
      }
    });
    if ((this.forms.routsTab.length > 1 || checkDirty) && !this.sumbittedFlag) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }

  }/**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  ngOnDestroy() {
    this.sub$.unsubscribe();
    this.metadataSubscription$.unsubscribe();
    if (this.submitSubscripiton$) {
      this.submitSubscripiton$.unsubscribe();
    }
  }
}
