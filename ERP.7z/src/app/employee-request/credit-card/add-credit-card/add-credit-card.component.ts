import { Component, OnInit } from '@angular/core';
import {
  NgForm,
  FormGroup,
  FormBuilder,
  FormControl,
  Validators
} from '@angular/forms';
import { CommonService } from 'src/app/shared/services/common.service';
import { AddCreditCardService } from '../../data-services/add-credit-card.service';
import { CardInstructionsService } from '../../data-services/card-instructions.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-credit-card',
  templateUrl: './add-credit-card.component.html',
  styleUrls: ['./add-credit-card.component.scss']
})
export class AddCreditCardComponent implements OnInit {
  addCreditCard: FormGroup;
  errorMessage: string;
  showAddAttachment = false;
  metaData: any;
  formsubmit = false;
  validationMessage = '';
  language = '';
  showLoader = false;
  creditCardCheck = false;
  approverList = [];
  transactionId = '';
  uploadedFile = [];
  getcardinfo = [];
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly common: CommonService,
    public readonly router: Router,
    private readonly addCreditCardService: AddCreditCardService,
    private readonly creditCardInfoService: CardInstructionsService
  ) { }

  ngOnInit() {
    this.creditCardInfo();
    this.language = this.common.getLanguage()
    this.addCreditCard = this.formBuilder.group({
      comments: '',
      mobileNumber: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      officeNumber: ['', [Validators.required, Validators.pattern('^[0-9]*$')]]
    });
  }

  submitCreditCard() {
    this.formsubmit = true;
    if (this.addCreditCard.valid) {
      this.showLoader = true;
      const userDetails = this.common.getUserDetails();
      const data = {
        creditCardTab: [
          {
            comments: this.addCreditCard.value.comments,
            mobileNumber: this.addCreditCard.value.mobileNumber + '',
            officeNumber: this.addCreditCard.value.officeNumber + ''
          }
        ],
        submitFlag: null,
        requestId: null,
        userName: userDetails.userName
      };
      this.addCreditCardService.addCreditcard(data).subscribe(
        response => {
          this.showLoader = false;
          if (response.returnCode === '0') {
             this.errorMessage = '';
            // this.common.showToast({
            //   show: true,
            //   status: 'success',
            //   message: response.returnMsg
            // });
            // this.router.navigate(['/employee-request/credit-card']);
            this.approverList = response.approverList;
            this.transactionId = response.transactionId;
             if (!this.approverList.length) {
              this.submitRquest();
            }
          }
          if (response.returnCode === '1') {
            this.errorMessage = response.returnMsg;
          }
        },
        error => {
          this.showLoader = false;
        }
      );
    }

  }
submitRquest() {
  this.showLoader = true;
  const userDetails = this.common.getUserDetails();
  const data = {
    creditCardTab: [
      {
        comments: this.addCreditCard.value.comments,
        mobileNumber: this.addCreditCard.value.mobileNumber + '',
        officeNumber: this.addCreditCard.value.officeNumber + ''
      }
    ],
    submitFlag: 'Y',
    requestId: this.transactionId,
    userName: userDetails.userName
  };
  this.addCreditCardService.addCreditcard(data).subscribe(
    response => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        this.errorMessage = '';
        this.common.showToast({
          show: true,
          status: 'success',
          message: response.returnMsg
        });
        this.router.navigate(['/employee-request/credit-card']);
      }
      if (response.returnCode === '1') {
        this.errorMessage = response.returnMsg;
      }
    },
    error => {
      this.showLoader = false;
    }
  );
}
  creditCardInfo() {
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: userDetails.userName,
      language: ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;

    this.creditCardInfoService.creditCardInfo(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.getcardinfo = response.creditCardInstructionTab;
          this.errorMessage = '';

        }
        if (response.returnCode === '1') {
          this.errorMessage = response.returnMsg;
        }
      },
      error => {
        this.common.showToast({
          show: true,
          status: 'failed',
          message: error.returnMsg
        });
      }
    );

  }
}
