import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';
import { CreditCardSummaryService } from '../data-services/credit-card-summary.service';

@Component({
  selector: 'app-credit-card',
  templateUrl: './credit-card.component.html',
  styleUrls: ['./credit-card.component.scss']
})
export class CreditCardComponent implements OnInit {
  errorMessage: string;
  showAddAttachment = false;
  getCreditDetails = [];
  validationMessage = '';

  constructor(
    private readonly common: CommonService,
    private readonly creditCardService : CreditCardSummaryService
  ) { }

  ngOnInit() {
    this.creditCardDetails();
  }

  creditCardDetails(){
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: userDetails.userName,
      language: ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;

    this.creditCardService.creditCardSummary(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.getCreditDetails = response.creditcardSummaryTab;
          this.errorMessage = '';
        }
        if (response.returnCode === '1') {
          this.errorMessage = response.returnMsg;
        }
      },
      error => {
        console.log(error);
        this.common.showToast({
          show: true,
          status: 'failed',
          message: error.returnMsg
        });
      }
    );

  }

}
