import { Component, OnInit } from '@angular/core';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { ResignationService } from '../../data-services/resignation.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/shared/services/common.service';
import { Location, DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';

@Component({
  selector: 'app-add-resignation-request',
  templateUrl: './add-resignation-request.component.html',
  styleUrls: ['./add-resignation-request.component.scss']
})
export class AddResignationRequestComponent implements OnInit {
  showAddAttachment = false;
  uploadedFile = [];
  resignationForm: FormGroup;
  formsubmit: boolean;
  subscriptionResignation$: Subscription;
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  warningMsg = '';
  reasonsMetaData: any = [];
  showLoader = false;
  resignationDetails: any = [];
  resignedData: any = [];
  constructor(
    private resignationService: ResignationService,
    private formBuilder: FormBuilder,
    private common: CommonService,
    private location: Location,
    private readonly datePipe: DatePipe,
  ) { }


  ngOnInit() {
    this.warningMsg = localStorage.getItem('warningMsg') || '';
    this.getReasons();
    this.fetchRegistrationDetails();
    this.resignationForm = this.formBuilder.group({
      terminationDate: { jsdate: new Date() },
      effectiveDate: { jsdate: new Date() },
      reason: '',
      resignComments: ''
    });
  }
  getReasons() {
    this.showLoader = true;
    this.resignationService.getReasons().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.reasonsMetaData = response.lookupTab;
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  fetchRegistrationDetails() {
    this.showLoader = true;
    this.resignationService.fetchRegistrationDetails().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.resignationDetails = response.resignDetails[0];
            this.resignedData = response.resignTab;
          if (this.resignedData[0] && this.resignedData[0].value) {
            this.resignationForm.controls.terminationDate.setValue({ jsdate:
              new Date(this.resignedData[0].value)}
            );
            this.resignationForm.controls.terminationDate.disable();
          }
          if (this.resignedData[1] && this.resignedData[1].value) {
            this.resignationForm.controls.effectiveDate.setValue({ jsdate:
              new Date(this.resignedData[1].value)}
            );
            this.resignationForm.controls.effectiveDate.disable();
          }
          if (this.resignedData[2] && this.resignedData[2].value) {
            this.resignationForm.controls.reason.setValue(this.resignedData[2].value);
            this.resignationForm.controls.reason.disable();
          }
          if (this.resignedData[3] && this.resignedData[3].value) {
            this.resignationForm.controls.resignComments.setValue(this.resignedData[3].value);
            this.resignationForm.controls.resignComments.disable();
          }
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  saveRequest(form) {
    const data = Object.assign(this.resignationForm.value);
    data.mode = 'C';
    data.userName = this.common.getUserDetails().userName;
    //data.additionalComments = this.resignationForm.value.resignComments;
    data.attachmentTab = this.uploadedFile;
    if (this.resignationForm.value.effectiveDate.jsdate) {
      data.effectiveDate = this.datePipe.transform(this.resignationForm.value.effectiveDate.jsdate, 'yyyy-MM-dd');
    }
    if (this.resignationForm.value.terminationDate.jsdate) {
      data.additionalComments = this.datePipe.transform(this.resignationForm.value.terminationDate.jsdate, 'yyyy-MM-dd');
    } else {
      data.additionalComments = this.resignationForm.value.terminationDate;
    }

    this.formsubmit = true;
    if (form.valid) {
      this.subscriptionResignation$ = this.resignationService.createOfficialTrip(data).subscribe(
        response => {
          if (response.returnCode === '0') {
            const toast = ToastSuccess;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
            this.location.back();
          } else {
            const toast = ToastFailed;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
          }
          this.showLoader = false;
        },
        error => {
          this.showLoader = false;
        }
      );
    }
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.uploadedFile.push(file);
  }
  deleteFile(index) {
    this.uploadedFile.splice(index, 1);
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy() {
    if (this.subscriptionResignation$) {
      this.subscriptionResignation$.unsubscribe();
    }
  }
}
