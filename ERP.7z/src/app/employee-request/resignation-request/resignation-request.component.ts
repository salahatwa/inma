import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resignation-request',
  templateUrl: './resignation-request.component.html',
  styleUrls: ['./resignation-request.component.scss']
})
export class ResignationRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
