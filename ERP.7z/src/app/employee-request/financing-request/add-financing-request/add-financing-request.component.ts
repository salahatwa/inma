import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/shared/services/common.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';

@Component({
  selector: 'app-add-financing-request',
  templateUrl: './add-financing-request.component.html',
  styleUrls: ['./add-financing-request.component.scss']
})
export class AddFinancingRequestComponent implements OnInit {
  financeRequest: FormGroup;
  errorMessage: string;
  formsubmit = false;
  productTypes;
  questionsTab: any = [];
  additionalTab: any = [];
  financeDeclaration: any = [];
  financeInstruction: any = [];
  showLoader;
  requestId;
  itemKey;
  medicalDetailsFlag = false;
  questionsNotCompleted = false;
  additionalCommentsFlag = true;

  approverList: any = [];
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly common: CommonService,
    private readonly router: Router,
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
  ) { }

  ngOnInit() {
    this.financeRequest = this.formBuilder.group({
      comments: null,
      housingSupportMOH: [null, Validators.required],
      housingSupportREDF: [null, Validators.required],
      medicalDetails: null,
      typeCode: null
    });
    this.getFinaceProductType();
    this.getFinanceQuestionDetails();
  }

  isMedicalDetailsMandatory() {
    let flag = false;
    this.questionsNotCompleted = false;
    const answers = this.returnQuestionAnswers(this.questionsTab);
    answers.forEach(element => {
      if (element.employeeRespond === 'Yes') {
        flag = true;
      }
      if (!element.employeeRespond) {
        this.questionsNotCompleted = true;
      }
    });
    return flag;
  }

  submitFinanceRequest(subFlag) {
    this.approverList = [];
    this.formsubmit = true;
    this.medicalDetailsFlag = this.isMedicalDetailsMandatory();
    if (this.medicalDetailsFlag && this.financeRequest.controls.medicalDetails.value === null) {
      this.additionalCommentsFlag = false;
    } else {
      this.additionalCommentsFlag = true;
    }
/*     if (this.medicalDetailsFlag) {
      this.financeRequest.controls.medicalDetails.setValidators([Validators.required]);
    } */
    if (this.financeRequest.valid && !this.questionsNotCompleted  && this.additionalCommentsFlag) {
    const financeRequest = this.financeRequest.value;
    if (financeRequest.housingSupportMOH) {
          financeRequest.housingSupportMOH = 'Yes';
    } else {
          financeRequest.housingSupportMOH  = 'No';
    }
    if (financeRequest.housingSupportREDF) {
          financeRequest.housingSupportREDF = 'Yes';
    } else {
          financeRequest.housingSupportREDF  = 'No';
    }
    const data = {
      financeRequest: [financeRequest],
      questions: this.returnQuestionAnswers(this.questionsTab),
      requestId: null,
      subFlag: 'N',
      itemKey: null
    };
    if (subFlag === 'Y') {
      data.subFlag = 'Y';
      data.requestId = this.requestId;
      data.itemKey = this.itemKey;
    }
    this.showLoader = true;
    this.submitFinacingRequest(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          if (subFlag === 'Y') {
              this.errorMessage = '';
              this.common.showToast({
                show: true,
                status: 'success',
                message: response.returnMsg
              });
              this.router.navigate(['/employee-request/financing-request']);
          } else {
                this.requestId = response.requestId;
                this.itemKey = response.itemKey;
                this.approverList = response.approverTab;
              }
        }
        if (response.returnCode === '1') {
          this.errorMessage = response.returnMsg;
        }
        this.showLoader = false;
      },
      error => {
        this.common.showToast({
          show: true,
          status: 'failed',
          message: error.returnMsg
        });
        this.showLoader = false;
      }
    );
    }
  }
  returnQuestionAnswers(question) {
    const answers = [];
    question.forEach(element => {
      answers.push({
        employeeRespond: element.employeeRespond,
        questionNo: element.questionNumber
      });
    });
    return answers;
  }
  getFinanceQuestionDetails() {
      this.showLoader = true;
      this.getFinanceQuestionDetailsAPI().subscribe(response => {
        if (response.returnCode === '0') {
              this.questionsTab = response.questionsTab;
              this.additionalTab = response.additionalTab;
              this.financeDeclaration = response.financeDecelaration;
              this.financeInstruction = response.financeInstruction;
        }
        this.showLoader = false;
      }, error => {
        this.showLoader = false;
      });
   }
  /* get  Finance Question Details API */
  getFinanceQuestionDetailsAPI(): Observable<any> {
      const data = {
        language: '',
        userName: this.common.getUserDetails().userName
      };
      let language = 'AMERICAN';
      if (localStorage.getItem('language')) {
        const localLanguage = localStorage.getItem('language');
        if (localLanguage === 'ar') {
          language = 'ARABIC';
        }
      }
      data.language = language;
      const url = this.url.getFinanceQuestionDetailsUrl();
      return this.http.post<any>(url, data);
  }

  getFinaceProductType() {
    this.getFinaceProductTypeAPI().subscribe(response => {
      if (response.returnCode === '0') {
        this.productTypes = response.productType;
      }
    }, error => {

    });
   }
   /* get  Finace Product Type API */
  getFinaceProductTypeAPI(): Observable<any> {
      const data = {
          language: '',
          userName: this.common.getUserDetails().userName
      };
      let language = 'AMERICAN';
      if (localStorage.getItem('language')) {
        const localLanguage = localStorage.getItem('language');
        if (localLanguage === 'ar') {
          language = 'ARABIC';
        }
      }
      data.language = language;
      const url = this.url.getFinaceProductTypeUrl();
      return this.http.post<any>(url, data);
    }
  /* submit Finace Request API */
  submitFinacingRequest(data): Observable<any> {
      data.userName = this.common.getUserDetails().userName;
      let language = 'AMERICAN';
      if (localStorage.getItem('language')) {
        const localLanguage = localStorage.getItem('language');
        if (localLanguage === 'ar') {
          language = 'ARABIC';
        }
      }
      data.language = language;
      const url = this.url.getFinaceSubmitRequestUrl();
      return this.http.post<any>(url, data);
  }
}
