import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFinancingRequestComponent } from './add-financing-request.component';

describe('AddFinancingRequestComponent', () => {
  let component: AddFinancingRequestComponent;
  let fixture: ComponentFixture<AddFinancingRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFinancingRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFinancingRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
