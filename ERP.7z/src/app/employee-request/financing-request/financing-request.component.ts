import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-financing-request',
  templateUrl: './financing-request.component.html',
  styleUrls: ['./financing-request.component.scss']
})
export class FinancingRequestComponent implements OnInit {
  financeSummary = [];
  errorMessage;
  constructor(
    private readonly common: CommonService,
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
  ) { }

  ngOnInit() {
    this.getFinancingRequestDetails();
  }
  getFinancingRequestDetails(){
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: userDetails.userName,
      language: this.common.getRequestLanguage()
    };
    this.getFinancingRequestDetailsAPI(data).subscribe(
      response => {
        if (response.returnCode === "0") {
          this.financeSummary = response.financeSummary;
          this.errorMessage = "";
        }
        if (response.returnCode === "1") {
          this.errorMessage = response.returnMsg;
        }
      },
      error => {
      }
    );
  }
  getFinancingRequestDetailsAPI(data): Observable<any> {
    const url = this.url.getFinaceSummaryURL();
    return this.http.post<any>(url, data).pipe();
  }
}
