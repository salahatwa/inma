import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { RequestDetailsService } from '../data-services/request-details.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { ToastFailed } from 'src/app/shared/constants/globalConstants';

@Component({
  selector: 'app-request-details',
  templateUrl: './request-details.component.html',
  styleUrls: ['./request-details.component.scss']
})
export class RequestDetailsComponent implements OnInit, OnDestroy {
  private routeSubscription$: Subscription;
  private sitEitSubscription$: Subscription;
  selectedUser = '';
  showLoader = false;
  noSummary = false;
  managerAction = false;
  reqDetails = [];
  reqName = '';
  requestType: string;
  requestCode: string;
  addButton: string;
  constructor(
    private readonly requestDetailService: RequestDetailsService,
    private readonly activeRoute: ActivatedRoute,
    private readonly router: Router,
    private readonly common: CommonService
  ) { }

  ngOnInit() {
    this.routeSubscription$ = this.activeRoute.params.subscribe(params => {
      this.requestType = params['type'];
      this.requestCode = params['code'];
      if (this.requestCode === 'SA_IQAMA') {
        this.addButton = 'Update';
      } else {
        this.addButton = 'Add';
      }
    });
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.getSitEitDetails();
  }
  getSitEitDetails() {
    this.showLoader = true;
    this.sitEitSubscription$ = this.requestDetailService.getRequestdetails(this.requestType, this.requestCode, this.selectedUser, this.managerAction).subscribe(
      (response) => {

        this.showLoader = false;
        if (response.returnCode === '0') {
          this.reqName = response.requestName;
          this.reqDetails = response.sitEitSummaryTab;
        }
        if (response.returnCode === '9') {
          this.reqName = response.requestName;
          this.noSummary = true;
        }
        if (response.returnCode === '1') {
          this.reqName = response.requestName;
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  addRequest() {
    if (this.managerAction) {
      this.router.navigate(['/manager-self-service/add-overtime', this.requestCode, this.requestType]);
    } else {
      this.router.navigate(['/employee-request/add',
        this.requestCode, this.requestType]);
    }
  }
  ngOnDestroy() {
    if (this.routeSubscription$) {
      this.routeSubscription$.unsubscribe();
    }
    this.sitEitSubscription$.unsubscribe();
  }
}
