import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { EmployeeRequestComponent } from './employee-request.component';
import { SharedModule } from '../shared/shared.module';
import { RequestDetailsComponent } from './request-details/request-details.component';
import { AddRequestComponent } from './add-request/add-request.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { CreditCardComponent } from './credit-card/credit-card.component';
import { AddCreditCardComponent } from './credit-card/add-credit-card/add-credit-card.component';
import { ResignationRequestComponent } from './resignation-request/resignation-request.component';
import { AddResignationRequestComponent } from './resignation-request/add-resignation-request/add-resignation-request.component';
import { EducationQualificationComponent } from './education-qualification/education-qualification.component';
import { RequestEducationQualificationComponent } from './education-qualification/request-education-qualification/request-education-qualification.component';
import { QualificationComponent } from './education-qualification/request-education-qualification/qualification/qualification.component';
import { SchoolInformationComponent } from './education-qualification/request-education-qualification/school-information/school-information.component';
import { QualificationInformationComponent } from './education-qualification/request-education-qualification/qualification-information/qualification-information.component';
import { SubjectInformationComponent } from './education-qualification/request-education-qualification/subject-information/subject-information.component';
import { TutionInformationComponent } from './education-qualification/request-education-qualification/tution-information/tution-information.component';
import { TrainingInformationComponent } from './education-qualification/request-education-qualification/training-information/training-information.component';
import { EmployeeRequestRoutingModule } from './employee-request-routing.module';
import { AddSubjectComponent } from './education-qualification/request-education-qualification/subject-information/add-subject/add-subject.component';
import { MyDocumentsComponent } from './my-documents/my-documents.component';
import { ExpenseClaimComponent } from './expense-claim/expense-claim.component';
import { RequestExpenseClaimComponent } from './expense-claim/request-expense-claim/request-expense-claim.component';
import { OfficialTripComponent } from './official-trip/official-trip.component';
import { RequestOfficialTripComponent } from './official-trip/request-official-trip/request-official-trip.component';
import { FormsModule } from '@angular/forms';
import { FinancingRequestComponent } from './financing-request/financing-request.component';
import { AddFinancingRequestComponent } from './financing-request/add-financing-request/add-financing-request.component';
import { OfficialTripRoutesComponent } from './official-trip/official-trip-routes/official-trip-routes.component';
import { ExpenseLinesComponent } from './expense-claim/expense-lines/expense-lines.component';
import { EducationQualificationDetailsComponent } from './education-qualification/education-qualification-details/education-qualification-details.component';

@NgModule({
  imports: [
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule,
    EmployeeRequestRoutingModule,
    NgxMyDatePickerModule.forRoot()
  ],
  declarations: [
    EmployeeRequestComponent,
    CreditCardComponent, AddCreditCardComponent, ResignationRequestComponent,
    AddResignationRequestComponent, EducationQualificationComponent, RequestEducationQualificationComponent,
    QualificationComponent, SchoolInformationComponent, QualificationInformationComponent,
    SubjectInformationComponent, TutionInformationComponent, TrainingInformationComponent, AddSubjectComponent,
    MyDocumentsComponent, ExpenseClaimComponent, RequestExpenseClaimComponent,
    OfficialTripComponent, RequestOfficialTripComponent, FinancingRequestComponent,
    AddFinancingRequestComponent, OfficialTripRoutesComponent, ExpenseLinesComponent, EducationQualificationDetailsComponent
  ]
})
export class EmployeeRequestModule { }
