import { CommonService } from './../../shared/services/common.service';
import { MyDocumentsService } from './../data-services/my-documents.service';
import { Component, OnInit } from '@angular/core';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';
import { WorklistDetailService } from 'src/app/dashboard/worklist-detail/worklist-detail.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-my-documents',
  templateUrl: './my-documents.component.html',
  styleUrls: ['./my-documents.component.scss']
})
export class MyDocumentsComponent implements OnInit {
  showAddAttachment: boolean;
  showLoader = false;
  documentdetails: any = [];
  noSummary = false;
  message = '';
  constructor(
    private myDocumentsService: MyDocumentsService,
    private common: CommonService,
    private readonly worklistdetail: WorklistDetailService
  ) { }

  ngOnInit() {
    this.getSummary();
  }
  /**
   * get the document summary
   */
  getSummary() {
    this.showLoader = true;
    this.myDocumentsService.getDocumentsSummary().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.noSummary = false;
          this.documentdetails = response.myDocumentTab;
          console.log(this.documentdetails);
        } else if (response.returnCode === '9') {
          this.documentdetails = [];
          this.noSummary = true;
          this.message = response.returnMsg;
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  /**
   * method to create the file
   * @param file the selected file
   */
  createDocument(file) {
    this.showLoader = true;
    const data = {
      'attachmentTab': [
        {
          'attachementName': file.attachmentName,
          'attachementType': file.attachmentType,
          'deleteFlag': 'N',
          'description': file.comments,
          'documentId': null,
          'fileData': file.fileData,
          'title': file.title
        }
      ]
    };
    this.myDocumentsService.createMyDocument(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.getSummary();
          const toast = ToastSuccess;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        } else {
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.createDocument(file);
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  /**
   * download the file
   * @param mediaId id of the file to be downlaoded
   */
  getaddAttachment(mediaId) {
    this.worklistdetail.getaddAttachment(mediaId).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.saveFileInLocal(response);
          // this.absenceSummaryTab = response.absenceSummaryTab;
        } else {
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
      }
    );
  }
  saveFileInLocal(file) {
    const blob = this.common.createBlob(file);
    saveAs(blob, file.fileName);
  }
}
