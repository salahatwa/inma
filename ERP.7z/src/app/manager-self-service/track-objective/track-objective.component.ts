import { CommonService } from 'src/app/shared/services/common.service';
import { Location, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { TransferObjectiveService } from '../data-services/transfer-objective.service';
import { Observable, Subject } from 'rxjs';

@Component({
  providers: [DatePipe],
  selector: 'app-track-objective',
  templateUrl: './track-objective.component.html',
  styleUrls: ['./track-objective.component.scss']
})
export class TrackObjectiveComponent implements OnInit {
  objectiveListingTab: any = [];
  showLoader;
  comments: any = [];
  details: any = [];
  backNav = false;
  backConfirm = false;
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  private confirm$: Subject<boolean> = new Subject<boolean>();
  panelExpand = false;
  constructor(
    private objectiveService: TransferObjectiveService,
    private common: CommonService,
    private readonly datePipe: DatePipe
  ) {

  }

  ngOnInit() {
    this.getObjectiveListing();
  }
  panelExpandClick(index) {
    this.objectiveListingTab[index].isShow = !this.objectiveListingTab[index].isShow;
  }
  getObjectiveListing() {
    this.showLoader = true;
    this.objectiveService.getObjectiveListingAPI().subscribe(resposnse => {
      this.showLoader = false;
      if (resposnse.returnCode === '0' || resposnse.returnCode === '9') {
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.details = resposnse.mobListDetailsTab;
        this.objectiveListingTab.forEach(element => {
          if (element.achivementDate && element.achivementDate != null) {
            element.achivementDate = { jsdate: new Date(element.achivementDate) };
          }
          element.prevComments = element.comments;
        });
      } else {
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.details = resposnse.mobListDetailsTab;
      }
    }, error => {
      this.showLoader = false;
    });
  }
  saveTrackObjective() {
    this.showLoader = true;
    this.objectiveListingTab.forEach(element => {
      if (element.achivementDate != null && element.achivementDate.jsdate) {
        element.achivementDate = this.datePipe.transform(new Date(element.achivementDate.jsdate), 'yyyy-MM-dd');
      }
    });
    const body = {
      objectiveTab: this.objectiveListingTab
    };
    this.backNav = true;
    this.objectiveService.submitTrackObjective(body).subscribe(
      (response) => {
        if (response.returnCode === '0') {
          const toast = {
            show: true,
            status: 'success',
            message: 'The transaction has been sucessfully submitted'
          };
          this.showLoader = false;
          this.common.showToast(toast);
          this.comments = [];
          this.getObjectiveListing();
        } else if (response.returnCode === '1') {
          this.showLoader = false;
          const toast = {
            show: true,
            status: 'failed',
            message: response.returnMsg
          };
          this.common.showToast(toast);
          this.backNav = false;
        } else {
          this.showLoader = false;
          this.backNav = false;
        }
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    let flag = false;
    this.backNav ? flag = false : flag = true;
    if (flag) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }
  /**
 * @desc popup cancel for navigating from page
 */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
}
