import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { ManagerSelfServiceComponent } from './manager-self-service.component';
import { TrackObjectiveComponent } from './track-objective/track-objective.component';
import { AppraisalComponent } from './appraisal/appraisal.component';
import { ReporteesComponent } from './reportees/reportees.component';
import { SetObjectiveComponent } from './set-objective/set-objective.component';
import { AddSetObjectiveComponent } from './set-objective/add-set-objective/add-set-objective.component';
import { ManagerSelfServiceRoutingModule } from './manager-self-service-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { ManagerActionsComponent } from './manager-actions/manager-actions.component';
import { AppraisalCompetencyComponent } from './appraisal/appraisal-competency/appraisal-competency.component';
import { AppraisalObjectiveComponent } from './appraisal/appraisal-objective/appraisal-objective.component';
import { AppraisalSubmitComponent } from './appraisal/appraisal-submit/appraisal-submit.component';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    RouterModule,
    ManagerSelfServiceRoutingModule,
    ReactiveFormsModule,
    InfiniteScrollModule,
    NgxMyDatePickerModule.forRoot()
  ],
  declarations: [
    ManagerSelfServiceComponent,
    TrackObjectiveComponent,
    AppraisalComponent,
    ReporteesComponent,
    SetObjectiveComponent,
    AddSetObjectiveComponent,
    AppraisalCompetencyComponent,
    AppraisalObjectiveComponent,
    AppraisalSubmitComponent,
    ManagerActionsComponent
  ]
})
export class ManagerSelfServiceModule { }
