import { SubordinateService } from './../data-services/subordinate.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportees',
  templateUrl: './reportees.component.html',
  styleUrls: ['./reportees.component.scss']
})
export class ReporteesComponent implements OnInit {
  suboridanateList = [];
  message = '';
  constructor(
    private readonly subordinateService: SubordinateService
  ) { }

  ngOnInit() {
  }
}
