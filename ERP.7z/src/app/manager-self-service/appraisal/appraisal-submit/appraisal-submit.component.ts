import { CommonService } from './../../../shared/services/common.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AppraisalDetailsService } from '../data-services/appraisal-details.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { ShareAppraisalService } from '../data-services/share-appraisal.service';
import { Subject, Observable } from 'rxjs';

@Component({
  selector: 'app-appraisal-submit',
  templateUrl: './appraisal-submit.component.html',
  styleUrls: ['./appraisal-submit.component.scss']
})
export class AppraisalSubmitComponent implements OnInit {
  performanceDetailsObj = [];
  objectiveRatingsValue: any;
  appraisalBasicDetails: any;
  competencyMeta: any;
  overallRating = '';
  appraiseeComments = '';
  objectiveMeta: any;
  formsubmit = false;
  agreement = '';
  showLoader = false;
  appraisals: { [k: string]: any } = {};
  showCompetency = false;
  showObjective = false;
  noDataFound = false;
  compComment = '';
  headerTab: any = [];
  backNav = false;
  returnMsg = '';
  backConfirm = false;
  plan: any = {};
  totalCompScore = 0;
  totalObjScore = 0;
  private confirm$: Subject<boolean> = new Subject<boolean>();
  objComment = '';
  confirmSubmit = false;
  emptyRateLevelIdFlag = false;
  constructor(
    private appraisalDetails: AppraisalDetailsService,
    private readonly router: Router,
    private common: CommonService,
    private shareAppraisalService: ShareAppraisalService
  ) { }

  ngOnInit() {
    this.getAppraisalDetails();
    // this.plan = this.common.getPLanDetails();
  }
  getAppraisalDetails() {
    this.showLoader = true;
    const plan = this.common.getPLanDetails() || this.common.selectedPlanDetails;
    this.appraisalDetails.getAppraisalDetailsAndObjectiveDetails(plan.planId).subscribe(
      response => {
        if (response.returnCode === '0' || response.returnCode === '9') {
          this.appraisals = response;
          this.compComment = this.appraisals.compComment;
          this.objComment = this.appraisals.objComment;
          this.headerTab = this.appraisals.headerTab;
          const value = response.perApprTab[0].overallPerformanceLevelId.split('###$$$');
          this.overallRating = value[0] ? value[0] : '';
          this.agreement = value[1] ? value[1] : '';
          this.appraiseeComments = response.perApprTab[0].appraiseeComments;
          // this.appraisalBasicDetails = response.perApprTab[0];
          // this.competencyRatingsValue = response.perCompTab;
          // this.objectiveRatingsValue = response.perObjTab;
          // this.competencyMeta = response.compRatLevelTab;
          // this.objectiveMeta = response.objRatLevelTab;
          this.appraisals.perCompTab.forEach(element => {
            element.id = element.ratingLevelId;
            if (element.ratingLevelId === null || !element.ratingLevelId) {
              this.emptyRateLevelIdFlag = true;
            }
            element.ratingLevelId = '';
            this.totalCompScore = this.totalCompScore + (+element.score);
          });
          this.appraisals.perObjTab.forEach(competency => {
            const ratings = this.appraisals.objRatLevelTab.find(rating => rating.ratingLevelId === competency.score);
            if (ratings && ratings.stepValue) {
              this.totalObjScore = this.totalObjScore + (+ratings.stepValue);
            }
          });
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  panelExpandClick(index) {
    this.appraisals.perObjTab[index].isShow = !this.appraisals.perObjTab[index].isShow;
  }
  showConfirmPopup(form: NgForm) {
    this.formsubmit = true;
    this.backNav = true;
    if (this.emptyRateLevelIdFlag) {
      const toast = {
        show: true,
        status: 'failed',
        message: 'You cannot send the appraisal to appraisee for approval without defining the final rating'
      };
      this.common.showToast(toast);
    }
    if (form.valid && !this.emptyRateLevelIdFlag) {
      this.confirmSubmit = true; // check click of final submit
    } else {
      this.backNav = false;
    }
  }
  cancelSubmit() {
    this.confirmSubmit = false;
  }
  finalSubmit(/*form: NgForm*/) {
    /*this.formsubmit = true;
    this.backNav = true;
    if (form.valid) {*/
    this.showLoader = true;
    const perCompTabs = [...this.appraisals.perCompTab] || [];
    perCompTabs.forEach(element => {
      delete element.ratLeveltab;
      delete element.id;
    });
    const body = {
      action: 'SUBMIT',
      perCompTab: perCompTabs,
      perObjTab: this.appraisals.perObjTab,
      planId: this.plan.planId,
      comments: this.appraisals.comments,
      objComment: this.objComment,
      compComment: this.compComment
    };
    this.shareAppraisalService.shareAppraisalDetails(body).subscribe(
      response => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          const toast = {
            show: true,
            status: 'success',
            message: 'The transaction has been sucessfully submitted'
          };
          this.common.showToast(toast);
          this.router.navigate(['/manager-self-service']);
        } else {
          const toast = {
            show: true,
            status: 'false',
            message: response.returnMsg
          };
          this.common.showToast(toast);
        }
        this.confirmSubmit = false;
      },
      () => {
        this.showLoader = false;
      }
    );
    /*} else {
      this.backNav = false;
    }*/
  }
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    let flag = false;
    // (this.appraisals.perCompTab || []).forEach(element => {
    //   if (element.ratingLevelId === '') {
    //     flag = true;
    //     return;
    //   }
    // });
    this.backNav ? flag = false : flag = true;
    if (flag) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }
  /**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
}
