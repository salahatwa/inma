import { tap, map, share } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ShareAppraisalService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
  ) { }

  shareAppraisalDetails(data): Observable<any> {
    data.selectedUserName = this.common.getUserNameForMngrAction();
    data.creatorUserName = this.common.getUserDetails().userName;
    const url = this.url.getCreateAppraisalDetails();
    return this.http.post<any>(url, data);
  }
  getPeriodMetadata(): Observable<any> {
    const body = {
      type: 'PERIOD',
      userName: this.common.getUserDetails().userName,
      language: this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC'
    };
    const url = this.url.getCoursePeriodUrl();
    return this.http.post<any>(url, body).pipe(
      tap(res => {
        if (res.returnCode !== '0') {
          const toast = {
            show: true,
            status: 'failed',
            message: res.returnMsg
          };
          this.common.showToast(toast);
        }
      }),
      map(res => {
        if (res.returnCode === '0') {
          return res.lookupTab;
        } else {
          return [];
        }
      }),
      share()
    );
  }
}
