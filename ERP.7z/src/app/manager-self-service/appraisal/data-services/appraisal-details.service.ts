import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { Observable, forkJoin } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppraisalDetailsService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
  ) { }

  getAppraisalDetails(id): Observable<any> {
    const data = {
      userName: this.common.getUserNameForMngrAction(),
      loggedInUser: this.common.getUserDetails().userName,
      language: '',
      planId: id
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    const url = this.url.getAppraisalDetails();
    return this.http.post<any>(url, data);
  }
  getAppraisalDetailsAndObjectiveDetails(id): Observable<any> {
    const data = {
      userName: this.common.getUserNameForMngrAction(),
      loggedInUser: this.common.getUserDetails().userName,
      language: this.common.getRequestLanguage(),
      planId: id
    };
    const apprisalDetailsUrl = this.url.getAppraisalDetails();
    const objectiveListingUrl = this.url.objectiveListingUrl();
    const apprisalDetails = this.http.post<any>(apprisalDetailsUrl, data);
    const objectiveListingDetails = this.http.post<any>(objectiveListingUrl, data);
    return forkJoin([apprisalDetails, objectiveListingDetails]).pipe(map((response) => {
      const apprisalData = response[0];
      const objectiveData = response[1];
      apprisalData.perObjTab.forEach((element, index) => {
        const objective = objectiveData.objectiveListingTab.find(item => (+item.objectiveId) === (+element.objectiveId));
        const mergedData = { ...objective, ...element };
        apprisalData.perObjTab[index] = mergedData;
      });
      apprisalData.headerTab = response[1].headerTab;
      return apprisalData;
    }));
  }
}
