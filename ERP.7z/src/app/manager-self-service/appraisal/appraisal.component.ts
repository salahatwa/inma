import { Location } from '@angular/common';
import { CommonService } from './../../shared/services/common.service';
import { Subscription, Observable, Subject } from 'rxjs';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AppraisalDetailsService } from './data-services/appraisal-details.service';
import { ShareAppraisalService } from './data-services/share-appraisal.service';

@Component({
  selector: 'app-appraisal',
  templateUrl: './appraisal.component.html',
  styleUrls: ['./appraisal.component.scss']
})
export class AppraisalComponent implements OnInit {
  performanceDetailsObj = [];
  competencyRatingsValue: any = {};
  objectiveRatingsValue: any;
  appraisalBasicDetails: any = [];
  competencyMeta: any;
  overallRatings = '';
  agreement = '';
  confirmSubmit = false;
  appraiseeComments = '';
  appraisalSavedData: any = {};
  headerTab: any = [];
  appraisalSubscription$: Subscription;
  objectiveMeta: any;
  appraisals: any = {};
  comments = '';
  showLoader = false;
  showPopupFlag = true;
  showCompetency = false;
  showObjective = false;
  noDataFound = false;
  submitFlag = '';
  returnMsg = '';
  objScore = '';
  compScore = '';
  formsubmit = false;
  backConfirm = false;
  plan: any = {};
  metadata$: Observable<any>;
  private confirm$: Subject<boolean> = new Subject<boolean>();
  saveMessage = false;
  constructor(
    private appraisalDetails: AppraisalDetailsService,
    private readonly router: Router,
    private shareAppraisalService: ShareAppraisalService,
    private common: CommonService,
    private location: Location
  ) { }

  ngOnInit() {
    this.getAppraisalDetails();
    this.plan = this.common.getPLanDetails();
    this.metadata$ = this.shareAppraisalService.getPeriodMetadata();
  }
  /**
   * method to get the appraisal details incliuding competency and objectives with ratings
   */
  getAppraisalDetails() {
    this.showLoader = true;
    const plan = this.common.getPLanDetails();
    this.appraisalSubscription$ = this.appraisalDetails.getAppraisalDetailsAndObjectiveDetails(plan.planId).subscribe(
      response => {
        if (response.returnCode === '0' || response.returnCode === '9') {
          this.appraisals = JSON.parse(JSON.stringify(response));
          this.appraisalSavedData = response;
          this.headerTab = this.appraisals.headerTab;
          this.appraisalBasicDetails = response.perApprTab;
          this.objScore = response.objTotal;
          this.compScore = response.compTotal;
          const value = response.perApprTab[0].overallPerformanceLevelId.split('###$$$');
          this.overallRatings = value[0] ? value[0] : '';
          this.agreement = value[1] ? value[1] : '';
          this.appraiseeComments = response.perApprTab[0].appraiseeComments;
          this.comments = response.perApprTab[0].comments;
          this.submitFlag = response.submitFlag;
        } else {
          this.appraisals.returnCode = response.returnCode;
          this.appraisals.returnMsg = response.returnMsg;
        }
        this.showLoader = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  shareAppraisal(actions) {
    this.formsubmit = true;
    if (this.appraisals.course1 && this.appraisals.course2 && this.appraisals.period1 && this.appraisals.period2) {
      if (actions === 'SWA' && (!this.overallRatings || this.overallRatings === null)) {
        const toast = {
          show: true,
          status: 'failed',
          message: 'Please save the ratings before proceeding.'
        };
        this.common.showToast(toast);
      } else if (actions === 'UPD' || actions === 'SUBMIT') {
        // this.appraisals.action = action;
        this.showLoader = true;
        const perCompTabs = this.appraisals.perCompTab;
        perCompTabs.forEach(element => {
          delete element.ratLeveltab;
        });
        const body = {
          action: actions,
          perCompTab: perCompTabs,
          course1: this.appraisals.course1,
          course2: this.appraisals.course2,
          period1: this.appraisals.period1,
          period2: this.appraisals.period2,
          perObjTab: this.appraisals.perObjTab,
          planId: this.plan.planId,
          comments: this.comments,
          objComment: this.appraisals.objComment,
          compComment: this.appraisals.compComment
        };
        this.callShareAppraiseeApi(body);
      } else {
        this.showLoader = true;
        const perCompTabs = this.appraisalSavedData.perCompTab;
        perCompTabs.forEach(element => {
          delete element.ratLeveltab;
        });
        const body = {
          action: actions,
          course1: this.appraisals.course1,
          course2: this.appraisals.course2,
          period1: this.appraisals.period1,
          period2: this.appraisals.period2,
          perCompTab: perCompTabs,
          perObjTab: this.appraisalSavedData.perObjTab,
          planId: this.plan.planId,
          comments: this.comments,
          objComment: this.appraisalSavedData.objComment,
          compComment: this.appraisalSavedData.compComment
        };
        this.callShareAppraiseeApi(body);
      }
    }
  }
  callShareAppraiseeApi(body) {
    this.shareAppraisalService.shareAppraisalDetails(body).subscribe(
      response => {
        if (response.returnCode === '0') {
          // const toast = {
          //   show: true,
          //   status: 'success',
          //   message: 'Transaction created successfully'
          // };
          this.saveMessage = true;
          this.showLoader = false;
          this.showPopupFlag = false;
          // this.router.navigate(['/manager-self-service']);
          // this.common.showToast(toast);
        } else {
          const toast = {
            show: true,
            status: 'false',
            message: response.returnMsg
          };
          this.showLoader = false;
          this.common.showToast(toast);
        }
        this.confirmSubmit = false;
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  onSaveMessageClicked() {
    this.saveMessage = false;
    this.router.navigate(['/manager-self-service']);
  }
  giveFinalRatingNav() {
    if (!this.overallRatings) {
      const toast = {
        show: true,
        status: 'failed',
        message: 'Please save the ratings before proceeding.'
      };
      this.common.showToast(toast);
    } else {
      // this.router.navigate(['/manager-self-service/appraisal-submit']);
      this.confirmSubmit = true;
    }
  }
  cancelSubmit() {
    this.confirmSubmit = false;
  }

  canDeactivate(nextState): boolean | Observable<boolean> | Promise<boolean> {
    if (nextState.url !== '/manager-self-service/appraisal-submit') {
      if (this.showPopupFlag) {
        this.backConfirm = true;
        return this.confirm$;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }
  /**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  /**
   * close the competency view by emiting true from child component
   * @param value true or false
   */
  closeCompetency(value) {
    this.showCompetency = value;
  }
  /**
   * close the objective view by emting true from child component
   * @param value true or false
   */
  closeObjective(value) {
    this.showObjective = value;
  }
  /**
   * get the value of competency ratings
   * @param value competency ratings
   */
  competencyRatings(value) {
    this.appraisals = value;
  }
  /**
  * get the value of objective ratings
  * @param value objective ratings
  */
  objectiveRatings(value) {
    this.appraisals = value;
  }
}
