import { NgForm } from '@angular/forms';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-appraisal-objective',
  templateUrl: './appraisal-objective.component.html',
  styleUrls: ['./appraisal-objective.component.scss']
})
export class AppraisalObjectiveComponent implements OnInit {
  @Output() objectiveRatings = new EventEmitter();
  @Output() closeObjective = new EventEmitter();
  @Input() objectives: any = [];
  @Input() metaData;
  submitted = false;
  plan: any = {};
  constructor(
    private common: CommonService
  ) { }

  ngOnInit() {
    this.plan = this.common.getPLanDetails();
  }
  close() {
    this.closeObjective.emit(false);
  }
  panelExpandClick(index) {
    this.objectives.perObjTab[index].isShow = !this.objectives.perObjTab[index].isShow;
  }
  ratingsSubmit(form: NgForm) {
    console.log(this.objectives);
    this.submitted = true;
    if (form.valid) {
      /*const toast = {
        'show': true,
        'status': 'success',
        'message': 'Saved'
      };
      this.common.showToast(toast);*/
      this.objectiveRatings.emit(this.objectives);
      this.closeObjective.emit(false);
    }
  }
}
