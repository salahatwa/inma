import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-appraisal-competency',
  templateUrl: './appraisal-competency.component.html',
  styleUrls: ['./appraisal-competency.component.scss']
})
export class AppraisalCompetencyComponent implements OnInit {
  @Output() competencyRatings = new EventEmitter();
  @Output() closeCompetency = new EventEmitter();
  @Input() competencies;
  @Input() metaData;
  submitted = false;
  plan: any = {};
  constructor(
    private common: CommonService
  ) { }

  ngOnInit() {
    console.log(this.competencies);
    this.plan = this.common.getPLanDetails();
  }

  close() {
    this.closeCompetency.emit(false);
  }
  ratingsSubmit(form: NgForm) {
    console.log(this.competencies);
    this.submitted = true;
    if (form.valid) {
      /*const toast = {
        'show': true,
        'status': 'success',
        'message': 'Saved'
      };
      this.common.showToast(toast);*/
      this.competencyRatings.emit(this.competencies);
      this.closeCompetency.emit(false);
    }
  }
}
