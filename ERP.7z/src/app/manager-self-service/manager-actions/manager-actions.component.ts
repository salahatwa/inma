import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TransferObjectiveService } from '../data-services/transfer-objective.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager-actions',
  templateUrl: './manager-actions.component.html',
  styleUrls: ['./manager-actions.component.scss']
})
export class ManagerActionsComponent implements OnInit {
  scoreCardId: any = null;
  objectiveListingTab: any = [];
  details: any = [];
  comments = null;
  showLoader;

  panelExpand = false;
  constructor(
    private objectiveService: TransferObjectiveService,
    private common: CommonService,
    private location: Location,
    private readonly router: Router
  ) { }

  ngOnInit() {
    this.getObjectiveListing();
  }

  panelExpandClick(index) {
    this.objectiveListingTab[index].isShow = !this.objectiveListingTab[index].isShow;
  }

  getObjectiveListing() {
    this.showLoader = true;
    this.objectiveService.getObjectiveListingAPI().subscribe(resposnse => {
      this.showLoader = false;
      if (resposnse.returnCode === '0' || resposnse.returnCode === '9') {
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.details = resposnse.mobListDetailsTab;
        this.scoreCardId = resposnse.objectiveListingTab[0].scoreCardId;
      } else {
        // this.objectiveListingTab = [];
        this.details = resposnse.mobListDetailsTab;
        this.scoreCardId = resposnse.objectiveListingTab[0].scoreCardId;
        this.objectiveListingTab = resposnse.objectiveListingTab;
      }
    }, error => {
      this.showLoader = false;
    });
  }

  navigateBack() {
    this.location.back();
  }
  modifyObjectives() {
    this.showLoader = true;
    const scoreCardId = this.objectiveListingTab[0].scoreCardId;
    this.objectiveService.modifyObjectives(scoreCardId, this.comments).subscribe((response) => {
      if (response.returnCode === '0') {
        const toast = {
          show: true,
          status: 'success',
          message: 'The transaction has been sucessfully submitted'
        };
        this.showLoader = false;
        this.common.showToast(toast);
        this.router.navigate(['/manager-self-service']);
      }
    }, () => {
      this.showLoader = false;
    });
  }
  performAction(actionFlag) {
    this.showLoader = true;
    const data: any = {};
    data.action = actionFlag;
    data.comments = this.comments;
    data.scoreCardId = this.scoreCardId;

    this.objectiveService.managerReviewAction(data).subscribe((response) => {
      const toast = {
        show: true,
        status: 'success',
        message: 'The transaction has been sucessfully submitted'
      };
      this.showLoader = false;
      this.common.showToast(toast);
      this.router.navigate(['/manager-self-service']);
    }, (error) => {
      this.showLoader = false;
    });
  }

}
