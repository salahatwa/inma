import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { TransferObjectiveService } from '../data-services/transfer-objective.service';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { SubordinateService } from '../data-services/subordinate.service';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';

@Component({
  selector: 'app-set-objective',
  templateUrl: './set-objective.component.html',
  styleUrls: ['./set-objective.component.scss']
})
export class SetObjectiveComponent implements OnInit {
  scoreCardId: any = null;
  objectiveListingTab = [];
  deletedObjectiveList: any = {};
  details: any = [];
  deleteFlag = false;
  showLoader;

  panelExpand = false;
  constructor(
    private objectiveService: TransferObjectiveService,
    private common: CommonService,
    private readonly url: UrlGeneratorService,
    private readonly subordinateService: SubordinateService,
    private readonly router: Router
  ) { }

  ngOnInit() {
    this.getObjectiveListing();
  }
  panelExpandClick(index) {
    this.objectiveListingTab[index].isShow = !this.objectiveListingTab[index].isShow;
  }
  getObjectiveListing() {
    localStorage.setItem('objectiveList', JSON.stringify([]));
    this.showLoader = true;
    this.objectiveService.getObjectiveListingAPI().subscribe(resposnse => {
      this.showLoader = false;
      if (resposnse.returnCode === '0' || resposnse.returnCode === '9') {
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.details = resposnse.mobListDetailsTab;
        localStorage.setItem('objectiveList', JSON.stringify(this.objectiveListingTab));
        this.scoreCardId = resposnse.objectiveListingTab[0].scoreCardId;
      } else {
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.details = resposnse.mobListDetailsTab;
      }
    }, error => {
      this.showLoader = false;
    });
  }

  transferObjectives(scoreCardId) {
    this.showLoader = true;
    this.objectiveService.transferObjective(scoreCardId).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        const toast = {
          show: true,
          status: 'success',
          message: 'The transaction has been sucessfully submitted'
        };
        this.common.showToast(toast);
        this.router.navigate(['manager-self-service']);
      } else if (response.returnCode === '1') {
        const toast = {
          show: true,
          status: 'failed',
          message: response.returnMsg
        };
        this.common.showToast(toast);
      }
    }, (error) => {
      this.showLoader = false;
    });
  }
  deleteObjectivePopup(objective) {
    this.deletedObjectiveList = objective;
    this.deleteFlag = true;
  }
  cancelAlert() {
    this.deleteFlag = false;
  }
  confirmDelete() {
    this.deleteFlag = false;
    this.deleteObjective();
  }
  deleteObjective() {
    const url = this.url.createObjectiveURL();
    const data = {
      language: this.common.getRequestLanguage(),
      objectiveListingTab: [this.deletedObjectiveList],
      loggedInUser: this.common.getUserDetails().userName,
      userName: this.common.selectedSubordinate.empUserName,
      transactionId: 2
    };
    this.showLoader = true;
    this.subordinateService.postActionApi(data, url).subscribe((response) => {
      if (response.returnCode === '0') {
        const toast = ToastSuccess;
        toast.message = 'The transaction has been sucessfully submitted';
        this.common.showToast(toast);
        this.getObjectiveListing();
      } else {
        this.showLoader = false;
        const toast = ToastFailed;
        toast.message = response.returnMsg;
        this.common.showToast(toast);
      }
    }, (error) => {
      const toast = ToastFailed;
      toast.message = error.returnMsg;
      this.common.showToast(toast);
      this.showLoader = false;
    });
  }
  editObjective(objective, index) {
    localStorage.setItem('objectives', JSON.stringify(objective));
    this.router.navigate(['/manager-self-service/add-set-objective'], { queryParams: { edit: true, index: index } });
  }
}
