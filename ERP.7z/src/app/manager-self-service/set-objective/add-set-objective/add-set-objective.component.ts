import { Component, OnInit } from '@angular/core';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { SubordinateService } from '../../data-services/subordinate.service';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location, DatePipe } from '@angular/common';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';

@Component({
  providers: [DatePipe],
  selector: 'app-add-set-objective',
  templateUrl: './add-set-objective.component.html',
  styleUrls: ['./add-set-objective.component.scss']
})
export class AddSetObjectiveComponent implements OnInit {
  createObjectiveForm: FormGroup;
  measurementStyle = '';
  edit = false;
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  priorityMeta;
  showLoader;
  backConfirm = false;
  private confirm$: Subject<boolean> = new Subject<boolean>();
  mettaDataMeasurement: any = [];
  mettaDataUom: any = [];
  mettaDataType: any = [];
  mettaDataWeighting: any = [];
  formsubmit: boolean;
  index: any;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private readonly subordinateService: SubordinateService,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService,
    private readonly location: Location,
    private readonly datePipe: DatePipe,
    private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    if(!this.common.selectedSubordinate.scoreCardId) {
      this.router.navigate(['/manager-self-service']);
    }
    this.activatedRoute.queryParams.subscribe(
      (params: Params) => {
        this.edit = params['edit'];
        this.index = params['index'];
      }
    );
    this.getObjectiveMetaData('PRIORITY');
    this.getObjectiveMetaData('MEASUREMENT');
    this.getObjectiveMetaData('WEIGHTING');
    this.getObjectiveMetaData('UOM');
    this.getObjectiveMetaData('MEASURE_TYPE');
    this.createObjectiveForm = this.formBuilder.group(
      {
        actualValue: '',
        appraiseeFlag: true,
        comments: '',
        createdBy: this.common.getUserDetails().fullName,
        details: '',
        measureComments: '',
        measureName: '',
        measureTypeCode: '',
        measurementStyleCode: '',
        objectiveId: null,
        objectiveName: ['', Validators.required],
        priorityCode: '',
        scoreCardId: this.common.selectedSubordinate.scoreCardId,
        startDate: ['', Validators.required],
        successCriteria: '',
        targetDate: '',
        targetValue: '',
        uomCode: '',
        varifiedFlag: true,
        weightingPercent: ['', Validators.required],
        completedPercent: 0,
        achivementDate: '',
        /*added values */
        measureTypeValue: '',
        measurementStyleValue: '',
        priorityValue: '',
        uomValue: ''
      }
    );
    if (this.edit) {
      this.setData();
    } else {
      this.changeMeasurementStyle('N_M');
      this.createObjectiveForm.controls.measurementStyleCode.setValue('N_M');
      this.createObjectiveForm.controls.priorityCode.setValue('3_H');
    }
  }
  getObjectiveMetaData(type) {
    const url = this.url.getObjectiveMetaDataURL();
    const data = {
      type: type,
      language: this.common.getRequestLanguage(),
      userName: this.common.getUserDetails().userName
    };
    this.showLoader = true;
    this.subordinateService.postActionApi(data, url).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        if (response.returnCode === '0') {
          if (type === 'PRIORITY') {
            this.priorityMeta = response.keyValueSet;
          } else if (type === 'MEASUREMENT') {
            this.mettaDataMeasurement = response.keyValueSet;
            // this.createObjectiveForm.controls.measurementStyleCode.setValue('N_M');
            // this.changeMeasurementStyle('N_M');
          } else if (type === 'UOM') {
            this.mettaDataUom = response.keyValueSet;
          } else if (type === 'MEASURE_TYPE') {
            this.mettaDataType = response.keyValueSet;
          } else {
            this.mettaDataWeighting = response.keyValueSet;
          }
        }
      }
    }, (error) => {
      this.showLoader = false;
    });
  }
  changeMeasurementStyle(value) {
    this.measurementStyle = value;
    if (value === 'QUANT_M') {
      this.createObjectiveForm.get('targetValue').setValidators([Validators.required]);
      this.createObjectiveForm.get('measureTypeCode').setValidators([Validators.required]);
      this.createObjectiveForm.get('uomCode').setValidators([Validators.required]);
      this.createObjectiveForm.get('measureName').setValidators([Validators.required]);
    } else if (value === 'QUALIT_M') {
      this.createObjectiveForm.get('measureName').setValidators([Validators.required]);
      this.createObjectiveForm.get('targetValue').setValidators(null);
      this.createObjectiveForm.get('measureTypeCode').setValidators(null);
      this.createObjectiveForm.get('uomCode').setValidators(null);
    } else {
      this.createObjectiveForm.get('targetValue').setValidators(null);
      this.createObjectiveForm.get('measureTypeCode').setValidators(null);
      this.createObjectiveForm.get('uomCode').setValidators(null);
      this.createObjectiveForm.get('measureName').setValidators(null);
    }
    this.createObjectiveForm.get('targetValue').updateValueAndValidity();
    this.createObjectiveForm.get('measureTypeCode').updateValueAndValidity();
    this.createObjectiveForm.get('uomCode').updateValueAndValidity();
    this.createObjectiveForm.get('measureName').updateValueAndValidity();
  }
  setData() {
    const data = JSON.parse(localStorage.getItem('objectives'));
    data.appraiseeFlag = (data.appraiseeFlag === 'Y') ? true : false;
    data.varifiedFlag = (data.varifiedFlag === 'Y') ? true : false;
    this.changeMeasurementStyle(data.measurementStyleCode);
    this.createObjectiveForm.controls.actualValue.setValue(data.actualValue);
    this.createObjectiveForm.controls.appraiseeFlag.setValue(data.appraiseeFlag);
    this.createObjectiveForm.controls.comments.setValue(data.comments);
    this.createObjectiveForm.controls.details.setValue(data.details);
    this.createObjectiveForm.controls.measureName.setValue(data.measureName);
    this.createObjectiveForm.controls.measureComments.setValue(data.measureComments);
    this.createObjectiveForm.controls.measureTypeCode.setValue(data.measureTypeCode);
    if (data.measurementStyleCode) {
      this.createObjectiveForm.controls.measurementStyleCode.setValue(data.measurementStyleCode);
    }/* else {
      this.createObjectiveForm.controls.measurementStyleCode.setValue('N_M');
    }*/
    this.createObjectiveForm.controls.objectiveId.setValue(data.objectiveId);
    this.createObjectiveForm.controls.objectiveName.setValue(data.objectiveName);
    if (data.priorityCode) {
      this.createObjectiveForm.controls.priorityCode.setValue(data.priorityCode);
    }/* else {
      this.createObjectiveForm.controls.priorityCode.setValue('3_H');
    }*/
    this.createObjectiveForm.controls.startDate.setValue({ jsdate: new Date(this.common.formatDateToMMDDYYYY(data.startDate))});
    this.createObjectiveForm.controls.successCriteria.setValue(data.successCriteria);
    if (data.targetDate) {
      this.createObjectiveForm.controls.targetDate.setValue({ jsdate: new Date(this.common.formatDateToMMDDYYYY(data.targetDate))});
    }
    this.createObjectiveForm.controls.targetValue.setValue(data.targetValue);
    this.createObjectiveForm.controls.uomCode.setValue(data.uomCode);
    this.createObjectiveForm.controls.varifiedFlag.setValue(data.varifiedFlag);
    this.createObjectiveForm.controls.weightingPercent.setValue(data.weightingPercent);
    // this.createObjectiveForm.controls.achivementDate.setValue(data.achivementDate);
  }
  createObjective() {
    this.formsubmit = true;
    let alreadyExists = false;
    let objectiveList = JSON.parse(localStorage.getItem('objectiveList'));
    if (this.edit) {
      objectiveList = objectiveList.filter((element, index) =>
        index !== Number(this.index)
      );
    }
    objectiveList.forEach(element => {
      // tslint:disable-next-line: max-line-length
      if (element.objectiveName.replace(/ +/g, '').toLowerCase() === this.createObjectiveForm.value.objectiveName.replace(/ +/g, '').toLowerCase()) {
        alreadyExists = true;
        return;
      }
    });
    if (alreadyExists) {
      const toast = ToastFailed;
      toast.message = 'Objective Name already exists';
      this.common.showToast(toast);
    }
    if (this.createObjectiveForm.valid && !alreadyExists) {
      const url = this.url.createObjectiveURL();
      this.createObjectiveForm.value.appraiseeFlag = this.createObjectiveForm.value.appraiseeFlag ? 'Y' : 'N';
      this.createObjectiveForm.value.varifiedFlag = this.createObjectiveForm.value.varifiedFlag ? 'Y' : 'N';
      this.createObjectiveForm.value.measurementStyleCode = this.createObjectiveForm.value.measurementStyleCode ?
        this.createObjectiveForm.value.measurementStyleCode : 'N_M';
      const dataobj = this.createObjectiveForm.value;
      let startDate = '';
      if (this.createObjectiveForm.value.startDate.jsdate && this.createObjectiveForm.value.startDate.jsdate != null) {
        startDate = this.datePipe.transform(this.createObjectiveForm.value.startDate.jsdate, 'yyyy-MMM-dd');
        const startDateArray = startDate.split('-');
        startDate = `${startDateArray[2]}-${startDateArray[1]}-${startDateArray[0]}`;
      }
      let targetDate = '';
      if (this.createObjectiveForm.value.targetDate.jsdate && this.createObjectiveForm.value.targetDate.jsdate != null) {
        targetDate = this.datePipe.transform(this.createObjectiveForm.value.targetDate.jsdate, 'yyyy-MMM-dd');
        const targetDateArray = targetDate.split('-');
        targetDate = `${targetDateArray[2]}-${targetDateArray[1]}-${targetDateArray[0]}`;
      }
      dataobj.startDate = startDate ? startDate :this.createObjectiveForm.value.startDate; // this.createObjectiveForm.value.startDate.jsdate;
      dataobj.targetDate = targetDate ? targetDate :this.createObjectiveForm.value.targetDate ; // this.createObjectiveForm.value.targetDate.jsdate;
      dataobj.groupCode = '';
      dataobj.nextReviewDate = '';
      dataobj.alingedWith = '';
      const data = {
        language: this.common.getRequestLanguage(),
        objectiveListingTab: [dataobj],
        loggedInUser: this.common.getUserDetails().userName,
        userName: this.common.selectedSubordinate.empUserName,
        transactionId: this.edit ? 1 : 0
      };
      this.showLoader = true;
      this.subordinateService.postActionApi(data, url).subscribe((response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.createObjectiveForm.markAsPristine();
          const toast = ToastSuccess;
          toast.message = 'Transaction created successfully';
          this.common.showToast(toast);
          this.location.back();
        } else {
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
      }, (error) => {
        const toast = ToastFailed;
        toast.message = error.returnMsg;
        this.common.showToast(toast);
        this.showLoader = false;
      });
    }
  }
  /**
  * @desc method to check if router needed to be deactivated if any input is there in form
  */
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if (this.createObjectiveForm && this.createObjectiveForm.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }
  /**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }/**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
}
