import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSetObjectiveComponent } from './add-set-objective.component';

describe('AddSetObjectiveComponent', () => {
  let component: AddSetObjectiveComponent;
  let fixture: ComponentFixture<AddSetObjectiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSetObjectiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSetObjectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
