import { SubordinateService } from './data-services/subordinate.service';
import { CommonService } from './../shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AttendanceService } from '../tam/data-services/attendance.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, tap, finalize, filter } from 'rxjs/operators';

@Component({
  selector: 'app-manager-self-service',
  templateUrl: './manager-self-service.component.html',
  styleUrls: ['./manager-self-service.component.scss']
})
export class ManagerSelfServiceComponent implements OnInit {
  searchForm: FormGroup;
  actionList = false;
  index = '';
  showLoader = false;
  showPaginationLoader = false;
  userNames = [];
  currentUser = '';
  stopPagination = false;
  suboridanateList: any = [];
  message = '';
  hrFlag = '';
  searchText = '';
  userName = '';
  scrollDistance = 2;
  searchedEmployees = [];
  showSearchResults = false;
  epmSearch = '';
  throttle = 200;
  selectedTab = '';
  noEmployeeMessage = '';
  start = 51;
  searchLoader = false;
  empSerach$ = new Subject();
  constructor(
    private readonly common: CommonService,
    private readonly formBuilder: FormBuilder,
    private readonly subordinateService: SubordinateService,
    private readonly router: Router,
    private attendanceService: AttendanceService
  ) { }

  ngOnInit() {
    this.selectedTab = 'REPORTEES';
    this.hrFlag = this.common.getUserDetails().hrFlag;
    this.userName = this.common.getUserDetails().userName;
    this.currentUser = this.userName;
    this.showLoader = true;
    this.searchForm = this.formBuilder.group({
      searchWord: '',
    });
    this.showReportees();
    this.handleSearch();
  }
  handleSearch() {
    this.searchForm.get('searchWord').valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      filter(searchWord => !searchWord.includes(':') && searchWord),
      tap(() => {
        this.searchLoader = true;
      }),
      switchMap((value) => {
        const data = {
          userName: value,
          type: 'ABS',
          startFrom: '',
          EndTo: ''
        };
        return this.attendanceService.getSearchReult(data).pipe(
          finalize(() => this.searchLoader = false)
        );
      })
    ).subscribe(
      response => {
        this.noEmployeeMessage = '';
        this.searchedEmployees = [];
        this.showSearchResults = false;
        if (response.returnCode === '0') {
          this.searchedEmployees = response.employeeList;
          this.showSearchResults = true;
        } else if (response.returnCode === '9') {
          this.showSearchResults = true;
          this.noEmployeeMessage = response.returnMsg;
        }
      },
      () => {
        this.noEmployeeMessage = '';
      }
    );
  }
  chooseEmployee(employee) {
    this.showSearchResults = false;
    //this.epmSearch = `${employee.employeeNumber} : ${employee.employeeName}`;
    this.searchForm.controls.searchWord.setValue(`${employee.employeeNumber} : ${employee.employeeName}`);
    this.showReportees('', '', employee.employeeNumber);
  }
  managerAction(i) {
    this.actionList = !this.actionList;
    this.index = i;
  }
  popUserNames(index) {
    this.userNames = this.userNames.slice(0, (index + 1));
    this.showLoader = true;
    this.showReportees(this.userNames[index]);
  }
  showReportees(user?: string, pagination?, searchText?: string) {
    if (user) {
      this.userName = user;
      this.userNames.push(user);
    } else {
      this.userNames = [];
      this.userName = this.common.getUserDetails().userName;
    }
    this.subordinateService.getAllSubordinates(this.userName, this.selectedTab, pagination, searchText).subscribe(
      (response) => {
        if (response.returnCode === '0') {
          this.searchText = '';
          this.message = '';
          (this.selectedTab === 'REPORTEES' || searchText) ? (this.suboridanateList = response.subordinateMngrPosListTab) :
            (this.suboridanateList = [...this.suboridanateList, ...response.subordinateMngrPosListTab]);
          const planDetails = {
            planId: response.planId,
            planName: response.palnName
          };
          localStorage.setItem('plan', JSON.stringify(planDetails));
          this.common.selectedPlanDetails = planDetails;
        } else if (response.returnCode === '9') {
          this.suboridanateList = [];
          this.message = response.returnMsg;
          this.stopPagination = true;
        } else {
          this.suboridanateList = [];
          this.message = '';
        }
        this.showLoader = false;
        this.showPaginationLoader = false;
      },
      () => {
        this.showLoader = false;
        this.showPaginationLoader = false;
      }
    );
  }
  searchEmployee(searchInput) {
    this.empSerach$.next(searchInput);
  }
  onScroll() {
    if (this.selectedTab === 'ALL_EMPLOYEES' && !this.stopPagination) {
      const pagination = {
        startFrom: this.start,
        endTo: this.start + 49
      };
      this.start = this.start + 49;
      this.showPaginationLoader = true;
      this.showReportees('', pagination);
    } else {
      this.start = 49;
    }
  }
  navToPersonalInfo(userName, fullName) {
    this.common.setUserNameForMngrAction(userName, fullName);
    this.router.navigate(['/manager-self-service/personal-info']);
  }
  navToReturnLeave(userName) {
    this.common.setUserNameForMngrAction(userName);
    this.router.navigate(['/manager-self-service/return-from-leave']);
  }
  navToOverTimeReq(userName) {
    this.common.setUserNameForMngrAction(userName);
    this.router.navigate(['/manager-self-service/overtime/INM_TIME_SHEET_FORM/SIT']);
  }
  navToLeaveManagement(userName, userId) {
    this.common.setUserNameForMngrAction(userName);
    this.common.setUserIdForMngrAction(userId);
    this.router.navigate(['/manager-self-service/leave-details']);
  }
  navToSetObjective(data) {
    this.common.selectedSubordinate = data;
    this.common.setUserNameForMngrAction(data.empUserName);
    if (data.cascadeOrSetObjectiveFlag === 'Y') {
      this.router.navigate(['/manager-self-service/set-objective']);
    }
  }
  navToTrackObjective(userName, flag) {
    this.common.setUserNameForMngrAction(userName);
    if (flag === 'Y') {
      this.router.navigate(['/manager-self-service/track-objective']);
    }
  }
  navToReviewWorker(userName, flag) {
    this.common.setUserNameForMngrAction(userName);
    if (flag === 'Y') {
      this.router.navigate(['/manager-self-service/review-worker']);
    }
  }
  navToAppraisal(userName, flag) {
    this.common.setUserNameForMngrAction(userName);
    if (flag === 'Y') {
      this.router.navigate(['/manager-self-service/appraisal']);
    }
  }
  navToTrainingAssessment(userName) {
    this.common.setUserNameForMngrAction(userName);
    this.router.navigate(['/manager-self-service/training-assessment']);
  }
  showPreviousPlan(userName, empName) {
    this.common.setUserNameForMngrAction(userName, empName);
    this.router.navigate(['/manager-self-service/performance']);
  }
}
