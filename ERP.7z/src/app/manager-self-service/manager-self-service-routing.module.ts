import { AppraisalSubmitComponent } from './appraisal/appraisal-submit/appraisal-submit.component';
import { ManagerActionsComponent } from './manager-actions/manager-actions.component';
import { AppraisalCompetencyComponent } from './appraisal/appraisal-competency/appraisal-competency.component';
import { CreateAbsenceComponent } from './../leave-management/absence-summary/create-absence/create-absence.component';
import { AddDependentComponent } from './../myprofile/personal-info/add-dependent/add-dependent.component';
import { CreateReturnLeaveComponent } from './../leave-management/return-leave/create-return-leave/create-return-leave.component';
import { AddRequestComponent } from './../employee-request/add-request/add-request.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagerSelfServiceComponent } from './manager-self-service.component';
import { SetObjectiveComponent } from './set-objective/set-objective.component';
import { AddSetObjectiveComponent } from './set-objective/add-set-objective/add-set-objective.component';
import { TrackObjectiveComponent } from './track-objective/track-objective.component';
import { AppraisalComponent } from './appraisal/appraisal.component';
import { ReporteesComponent } from './reportees/reportees.component';
import { PersonalInfoComponent } from '../myprofile/personal-info/personal-info.component';
import { RequestDetailsComponent } from '../employee-request/request-details/request-details.component';
import { EditPersonalInfoComponent } from '../myprofile/personal-info/edit-personal-info/edit-personal-info.component';
import { ReturnLeaveComponent } from '../leave-management/return-leave/return-leave.component';
import { AbsenceSummaryComponent } from '../leave-management/absence-summary/absence-summary.component';
import { CanDeactivateGuard } from '../shared/services/can-deactivate-guard.service';
import { PerformanceComponent } from '../performance/performance.component';
import { PerformanceDetailComponent } from '../performance/performance-detail/performance-detail.component';

const routes: Routes = [
  { path: '', component: ManagerSelfServiceComponent, data: { title: 'Manager Self Service' } },
  { path: 'set-objective', component: SetObjectiveComponent, data: { title: 'Set Objective' } },
  { path: 'add-set-objective', component: AddSetObjectiveComponent, data: { title: 'Set Objective' } },
  { path: 'track-objective', component: TrackObjectiveComponent, data: { title: 'Track Objective' } },
  { path: 'review-worker', component: ManagerActionsComponent, data: { title: 'Review Worker Changes' } },
  { path: 'appraisal', component: AppraisalComponent, data: { title: 'Appraisal' }, canDeactivate: [CanDeactivateGuard] },
  { path: 'appraisal-submit', component: AppraisalSubmitComponent, data: { title: 'Appraisal' },canDeactivate: [CanDeactivateGuard] },
  // { path: 'appraisal/competency/:id', component: AppraisalCompetencyComponent, data: { title: 'Competency' } },
  { path: 'reportees', component: ReporteesComponent, data: { title: 'Reportees' } },
  { path: 'personal-info', component: PersonalInfoComponent, data: { title: 'Personal Information' } },
  { path: 'personal-info/update', component: EditPersonalInfoComponent, data: { title: 'Personal Information' } },
  { path: 'overtime/:code/:type', component: RequestDetailsComponent, data: { title: 'Overtime Request' } },
  { path: 'add-overtime/:code/:type', component: AddRequestComponent, data: { title: 'Add Overtime Request' } },
  { path: 'return-from-leave', component: ReturnLeaveComponent, data: { title: 'Return From Leave' } },
  { path: 'add-return-from-leave', component: CreateReturnLeaveComponent, data: { title: 'Add Return From Leave' } },
  { path: 'add-dependent', component: AddDependentComponent, data: { title: 'Add Dependent' } },
  { path: 'leave-details', component: AbsenceSummaryComponent, data: { title: 'Leave Details' } },
  { path: 'leave-details/create', component: CreateAbsenceComponent, data: { title: 'Leave Details' } },
  { path: 'performance', component: PerformanceComponent, data: { title: 'Performance Management' } },
  { path: 'performance/detail/:id/:name', component: PerformanceDetailComponent, data: { title: 'Performance Management' } },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManagerSelfServiceRoutingModule { }
