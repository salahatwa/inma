import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransferObjectiveService {

  constructor(private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService) { }

  transferObjective(id): Observable<any> {
    const url = this.url.transferObjectiveUrl();
    const loggedInUser = this.common.getUserDetails().userName;
    const data = {
      'socreCardId': id,
      'userName': this.common.getUserNameForMngrAction(),
      'loggedInUser': loggedInUser,
      'language': ''
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
  }
  getObjectiveListingAPI(flag?): Observable<any> {
    const data =  {
      language: this.common.getRequestLanguage(),
      userName: flag ? this.common.getUserDetails().userName : this.common.getUserNameForMngrAction(),
      loggedInUser: this.common.getUserDetails().userName,
      planId:  this.common.getPLanDetails().planId
    };
    const url = this.url.objectiveListingUrl();
    return this.http.post<any>(url, data);
  }
  submitTrackObjective(data, flag?): Observable<any>  {
    data.loggedInUser = this.common.getUserDetails().userName;
    data.userName = flag ? this.common.getUserDetails().userName : this.common.getUserNameForMngrAction();
    const url = this.url.objectiveSubmitUrl();
    return this.http.post<any>(url, data);
  }
  managerReviewAction(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    const url = this.url.reviewWorkerChanges();
    return this.http.post<any>(url, data);
  }
  modifyObjectives(id, comments): Observable<any> {
    const data = {
      comments,
      language: this.common.getRequestLanguage(),
      scoreCardId: id,
      loggedInUser: this.common.getUserDetails().userName,
      userName: this.common.selectedSubordinate.empUserName,
    };
    const url = this.url.modifyObjectivesUrl();
    return this.http.post<any>(url, data);
  }
}
