import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SubordinateService {

  constructor(
    private readonly http: HttpClient,
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService
  ) { }
  getAllSubordinates(userName, selectedTab, pagination?, searchText?): Observable<any> {
    const url = (selectedTab === 'REPORTEES') ? this.url.getSubordinatesListingUrl() : this.url.getHRAllEmployeeListingUrl();
    const loggedInUser = this.common.getUserDetails().userName;
    let user = '';
    if (selectedTab !== 'REPORTEES') {
      user = searchText ? searchText : '';
    } else {
      user = userName;
    }
    const data = {
      'selectedUser': user,
      'userName': loggedInUser,
      'language': '',
      'startFrom': 1,
      'endTo': 49,
      'subordinateMngrPosListTab': [
        {
          'empPersonId': searchText ? +searchText : '',
          'empName': null,
          'assignmentNumber': null,
          'positionName': null,
          'positionId': null,
          'jobName': null,
          'organizationName': null,
          'businessGroup': null,
          'emailAddress': null,
          'empUserName': null,
          'subFlag': null,
          'employeeNumber': null,
          'cascadeOrSetObjectiveFlag': null,
          'reviewWorkerChangesFlag': null,
          'viewAndTrackObjectiveFlag': null,
          'manageApprisalFlag': null,
          'scoreCardId': null
        }
      ]
    };
    if (pagination) {
      data.startFrom = pagination.startFrom;
      data.endTo = pagination.endTo;
    }
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
  }
  /* Post Action API */
  postActionApi(data, url): Observable<any> {
    return this.http.post<any>(url, data);
  }
}
