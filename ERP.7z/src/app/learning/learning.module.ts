import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LearningComponent } from './learning.component';
import { IndividialDevelopmentComponent } from './individial-development/individial-development.component';
import { CourseRequestComponent } from './course-request/course-request.component';
import { LearningHomeComponent } from './learning-home/learning-home.component';
import { RouterModule } from '@angular/router';
import { CoursesComponent } from './learning-home/courses/courses.component';
import { AddIndividualDevelopmentComponent } from './individial-development/add-individual-development/add-individual-development.component';
import { AddCourseRequestComponent } from './course-request/add-course-request/add-course-request.component';
import { CourseDetailComponent } from './learning-home/courses/course-category/course-detail/course-detail.component';
import { CourseCategoryComponent } from './learning-home/courses/course-category/course-category.component';
import { EnrollComponent } from './learning-home/courses/course-category/course-detail/enroll/enroll.component';
import { SharedModule } from '../shared/shared.module';
import { LearningRoutingModule } from './learning-routing.module';
import { CourseClassesComponent } from './learning-home/courses/course-category/course-detail/course-classes/course-classes.component';

@NgModule({
  imports: [
    SharedModule,
    CommonModule,
    RouterModule,
    SharedModule,
    FormsModule,
    LearningRoutingModule
  ],
  declarations: [
    LearningComponent,
    IndividialDevelopmentComponent,
    CourseRequestComponent,
    LearningHomeComponent,
    CoursesComponent,
    AddIndividualDevelopmentComponent,
    AddCourseRequestComponent,
    CourseDetailComponent,
    CourseCategoryComponent,
    EnrollComponent,
    CourseClassesComponent
  ]
})
export class LearningModule { }
