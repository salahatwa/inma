import { CommonService } from 'src/app/shared/services/common.service';
import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LearningSummaryService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
  ) { }

  getLearningSummary(): Observable<any> {
    const data = { userName: this.common.getUserDetails().userName, language: '' };
    const url = this.url.getLearningSummary();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
  }
  unEnrollCourse(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    const url = this.url.unEnrollCourse();
    return this.http.post<any>(url, data);
  }

}
