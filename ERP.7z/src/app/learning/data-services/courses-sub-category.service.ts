import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CoursesSubCategoryService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
) {}

getCoursesSubCategory(id): Observable<any> {
    const data = {userName: this.common.getUserDetails().userName, language: '', categoryUsagesId: id};
    const url = this.url.getCourseSubCategories();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
 }
}
