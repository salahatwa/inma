import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CourseDetailsService {

  public courseDetailsObj: any = {};
  public activityVersionId: any = null;
  public categoryUsageId: any = null;
  public categoryName: any = null;
  public category: any = null;
  public subcategory: any = null;

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
  ) { }

  getCourseDetails(id): Observable<any> {
    const data = { userName: this.common.getUserDetails().userName, language: '', activityVersionId: id };
    const url = this.url.getCourseDetails();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
  }

  getJustificationDropdown(): Observable<any> {
    const data = { userName: this.common.getUserDetails().userName }
    const url = this.url.getJustificationDropdown();
    return this.http.post<any>(url, data);
  }

  enrollCourse(requestObj): Observable<any> {
    const data = {
      userName: this.common.getUserDetails().userName,
      bankingJustificationId: requestObj.bookingJustificationId,
      eventId: requestObj.eventId, comments: requestObj.comments
    };
    const url = this.url.enrollCourse();
    return this.http.post<any>(url, data);
  }
}
