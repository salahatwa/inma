import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CouseClassesService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
) {}

getCourseClasses(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    const url = this.url.getCourseClasses();
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data);
}
}
