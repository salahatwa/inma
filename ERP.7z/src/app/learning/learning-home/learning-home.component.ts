import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { LearningSummaryService } from '../data-services/learning-summary.service';

@Component({
  selector: 'app-learning-home',
  templateUrl: './learning-home.component.html',
  styleUrls: ['./learning-home.component.scss']
})
export class LearningHomeComponent implements OnInit {
  learningSummaryObj: any = [];
  cancelReason = [];
  cancelStatus = [];
  status = '';
  reason = '';
  id = '';
  showLoader = false;
  noDataFound = false;
  showUnEnrollAlert = false;
  returnMsg = '';

  constructor(private learningSummary: LearningSummaryService,
    private common: CommonService
  ) { }

  ngOnInit() {
    this.getLearningSummaryData();
  }

  getLearningSummaryData() {
    this.showLoader = true;
    this.learningSummary.getLearningSummary().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.learningSummaryObj = response.learningSummary;
          this.cancelReason = response.learningCancelReason;
          this.cancelStatus = response.learningCancelStatus;
          this.learningSummaryObj.forEach(item => {
            item.unenrollFlag = false;
            if (new Date() < new Date(item.courseStartDate)) {
              item.unenrollFlag = true;
            }
          })
        } else if (response.returnCode === '9') {
          this.learningSummaryObj = [];
          this.returnMsg = response.returnMsg;
          this.noDataFound = true;
        } else {
          this.learningSummaryObj = [];
        }
        this.showLoader = false;
      },
      error => {
        this.showLoader = false;
      }
    );
  }
  unEnroll(eventId) {
    this.showUnEnrollAlert = true;
    this.id = eventId;
  }
  confirmUnEnroll() {
    this.showLoader = true;
    this.showUnEnrollAlert = false;
    const data = {
      eventId: this.id,
      reason: this.reason,
      status: this.status,
    };
    this.learningSummary.unEnrollCourse(data).subscribe(response => {
      if (response.returnCode === '0') {
        this.getLearningSummaryData();
        const toast = {
          'show': true,
          'status': 'success',
          'message': response.returnMsg
        };
        this.common.showToast(toast);
      } else {
        this.showLoader = false;
        const toast = {
          'show': true,
          'status': 'failed',
          'message': response.returnMsg
        };
        this.common.showToast(toast);
      }
    });
  }
  cancelUnEnrollAlert() {
    this.showUnEnrollAlert = false;
  }
}
