import { CoursesService } from './../../data-services/courses.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.scss']
})
export class CoursesComponent implements OnInit {
  showLoader = false;
  coursesCategory = [];
  returnMsg = '';

  constructor(private courses: CoursesService) { }

  ngOnInit() {
    this.getCoursesData();
  }

  getCoursesData() {
    this.showLoader = true;
    this.courses.getCourses().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.coursesCategory = response.courseCategory;
        } else {
          this.coursesCategory = [];
        }
        this.showLoader = false;
        this.returnMsg = response.returnMsg;
      },
      error => {
        this.showLoader = false;
      }
    );
  }

}
