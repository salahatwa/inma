import { CoursesSubCategoryService } from './../../../data-services/courses-sub-category.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-category',
  templateUrl: './course-category.component.html',
  styleUrls: ['./course-category.component.scss']
})

export class CourseCategoryComponent implements OnInit {
  categoryUsageId = '';
  showLoader = false;
  courseCategoryObj = {category: '', categoryusageId: ''};
  courses = [];
  returnMsg = '';
  constructor(private route: ActivatedRoute, private coursesSubCategory: CoursesSubCategoryService ) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params) => {
        this.categoryUsageId = params['id'];
        this.getSubCategories(this.categoryUsageId);
      }
    );
  }

  getSubCategories(id) {
    this.showLoader = true;
    this.coursesSubCategory.getCoursesSubCategory(id).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.courseCategoryObj = response.mainCategories[0];
          this.courses = response.courses;
        } else {
          this.courseCategoryObj = {category: '', categoryusageId: ''};
          this.courses = [];
        }
        this.showLoader = false;
        this.returnMsg = response.returnMsg;
      },
      error => {
        this.showLoader = false;
      }
    );
  }

}
