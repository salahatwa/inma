import { Router } from '@angular/router';
import { CommonService } from './../../../../../../shared/services/common.service';
import { CourseDetailsService } from 'src/app/learning/data-services/course-details.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enroll',
  templateUrl: './enroll.component.html',
  styleUrls: ['./enroll.component.scss']
})
export class EnrollComponent implements OnInit {

  justification = [];

  showLoader = false;
  courseDetailsObj: any = {};
  enrollObj: any = {justification: null, comments: null};
  categoryUsageId: any = null;
  activityVersionId: any = null;
  categoryName: any = null;
  category: any = null;
  subcategory: any = null;
  className: any = null;

  constructor(private courseDetail: CourseDetailsService, private common: CommonService, private router: Router) { }

  ngOnInit() {
    this.courseDetailsObj = this.courseDetail.courseDetailsObj;
    this.categoryUsageId = this.courseDetail.categoryUsageId;
    this.categoryName = this.courseDetail.categoryName;
    this.activityVersionId = this.courseDetail.activityVersionId;
    this.category = this.courseDetail.category;
    this.subcategory = this.courseDetail.subcategory;
    this.className = this.courseDetail.courseDetailsObj.className;
    this.getJustificationDropdown();
  }

  getJustificationDropdown() {
    this.showLoader = true;
    this.courseDetail.getJustificationDropdown().subscribe(
      response => {
        this.justification = response.bookingJustificationTab;
        this.showLoader = false;
      },
      error => {
        this.showLoader = false;
      }
    );
  }

  enroll() {
    this.showLoader = true;
    const data = {
      eventId: this.courseDetailsObj.eventId,
      bookingJustificationId: this.enrollObj.justification,
      comments: this.enrollObj.comments
    };
    this.courseDetail.enrollCourse(data).subscribe(
      response => {
        if(response.returnCode === "0"){
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.common.showToast(toast);
          this.showLoader = false;
          this.router.navigate(['learning/courses-details', this.activityVersionId, this.categoryUsageId],
          {queryParams: {category: this.category, subcategory: this.subcategory}});
        } else {
          this.showLoader = false;
          const toast = {
            show: true,
            status: 'failed',
            message: response.returnMsg
          };
          this.common.showToast(toast);
        }
      },
      error => {
        this.showLoader = false;
      }
    );
  }

  goToClasses() {
    this.router.navigate(['/learning/classes'], {queryParams:
      {activityVersionId: this.activityVersionId,
       activityVersionName: this.courseDetailsObj.activityVersionName,
       category: this.courseDetail.category,
       subcategory: this.courseDetail.subcategory,
       categoryUsageId: this.categoryUsageId}});
  }

}
