import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CourseDetailsService } from 'src/app/learning/data-services/course-details.service';

@Component({
  selector: 'app-course-detail',
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.scss']
})
export class CourseDetailComponent implements OnInit {
  activityVersionId = '';
  categoryUsageId = '';
  searchText = '';
  categoryDetails: any = {};
  showLoader = false;
  courseDetails = [];
  noDataFound = false;
  returnMsg = '';

  constructor(private route: ActivatedRoute, private courseDetail: CourseDetailsService, private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params) => {
        this.activityVersionId = params['activityVersionId'];
        this.categoryUsageId = params['categoryUsageId'];
        this.courseDetail.activityVersionId = this.activityVersionId;
        this.courseDetail.categoryUsageId = this.categoryUsageId;
        this.getCourseDetails(this.activityVersionId);
      }
    );
    this.route.queryParams.subscribe(
      (params: Params) => {
        this.categoryDetails.category = params['category'];
        this.categoryDetails.subcategory = params['subcategory'];
        this.courseDetail.category = params['category'];
        this.courseDetail.subcategory = params['subcategory'];
      }
    )
  }

  getCourseDetails(id) {
    this.showLoader = true;
    this.courseDetail.getCourseDetails(id).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.courseDetails = response.courseDetails;
          this.courseDetail.categoryName = response.categoryName;
        } else {
          this.courseDetails = [];
          this.noDataFound = true;
        }
        this.showLoader = false;
        this.returnMsg = response.returnMsg;
      },
      error => {
        this.showLoader = false;
      }
    );
  }

  goToCourseClass(item) {
    this.courseDetail.courseDetailsObj = item;
    // this.router.navigate(['/learning/enroll']);
    this.router.navigate(['/learning/classes'], {queryParams:
     {activityVersionId: this.activityVersionId,
      activityVersionName: item.activityVersionName,
      category: this.courseDetail.category,
      subcategory: this.courseDetail.subcategory,
      categoryUsageId: this.categoryUsageId}});
  }
}
