import { Location } from '@angular/common';
import { CommonService } from './../../../../../../shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { Params, ActivatedRoute, Router } from '@angular/router';
import { CouseClassesService } from 'src/app/learning/data-services/couse-classes.service';
import { CourseDetailsService } from 'src/app/learning/data-services/course-details.service';

@Component({
  selector: 'app-course-classes',
  templateUrl: './course-classes.component.html',
  styleUrls: ['./course-classes.component.scss']
})
export class CourseClassesComponent implements OnInit {
  activityVersionId = '';
  courseName = '';
  searchText = '';
  showLoader = false;
  noDataFound = false;
  courseClassesDetails: any = [];

  category = '';
  subcategory = '';
  categoryUsageId = '';

  constructor(
    private activeRoute: ActivatedRoute,
    private location: Location,
    private router: Router,
    private courseDetail: CourseDetailsService,
    private couseClassesService: CouseClassesService,
    private common: CommonService
  ) { }

  ngOnInit() {
    this.activeRoute.queryParams.subscribe(
      (params: Params) => {
        this.activityVersionId = params['activityVersionId'];
        this.courseName = params['activityVersionName'];
        this.category = params['category'];
        this.subcategory = params['subcategory'];
        this.categoryUsageId = params['categoryUsageId'];
      }
    );
    this.getCourseClasses();
  }
  getCourseClasses() {
    this.showLoader = true;
    const data = {
      activityVersionId: this.activityVersionId
    };
    this.couseClassesService.getCourseClasses(data).subscribe(response => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        this.courseClassesDetails = response.courseEnrollDetails;
      } else {
        const toast = {
          show: true,
          status: 'failed',
          message: response.returnMsg
        };
        this.common.showToast(toast);
        this.noDataFound = true;
      }
    }, () => {
      this.showLoader = false;
    });
  }
  close() {
    this.location.back();
  }
  enroll(item) {
    this.courseDetail.courseDetailsObj.className = item.className;
    this.courseDetail.courseDetailsObj.eventId = item.eventId;
    this.router.navigate(['/learning/enroll']);
  }
}
