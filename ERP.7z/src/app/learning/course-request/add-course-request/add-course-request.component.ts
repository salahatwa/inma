import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-course-request',
  templateUrl: './add-course-request.component.html',
  styleUrls: ['./add-course-request.component.scss']
})
export class AddCourseRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
