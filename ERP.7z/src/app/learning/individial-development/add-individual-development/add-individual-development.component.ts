import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-individual-development',
  templateUrl: './add-individual-development.component.html',
  styleUrls: ['./add-individual-development.component.scss']
})
export class AddIndividualDevelopmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
