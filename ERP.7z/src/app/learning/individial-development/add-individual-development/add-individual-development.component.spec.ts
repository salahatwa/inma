import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddIndividualDevelopmentComponent } from './add-individual-development.component';

describe('AddIndividualDevelopmentComponent', () => {
  let component: AddIndividualDevelopmentComponent;
  let fixture: ComponentFixture<AddIndividualDevelopmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddIndividualDevelopmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddIndividualDevelopmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
