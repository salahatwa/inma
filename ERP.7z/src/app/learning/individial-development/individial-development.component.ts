import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { RequestDetailsService } from 'src/app/employee-request/data-services/request-details.service';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { ToastFailed } from 'src/app/shared/constants/globalConstants';

@Component({
  selector: 'app-individial-development',
  templateUrl: './individial-development.component.html',
  styleUrls: ['./individial-development.component.scss']
})
export class IndividialDevelopmentComponent implements OnInit,OnDestroy {

  sitEitSubscription$: Subscription;
  showLoader = false;
  noSummary = false;
  reqDetails = [];
  reqName = '';
  requestType: string;
  requestCode: string;
  constructor(
    private readonly requestDetailService: RequestDetailsService,
    private readonly router: Router,
    private readonly common: CommonService
  ) { }

  ngOnInit() {
      this.requestType = 'EIT';
      this.requestCode = 'XXX_HR_OLM_IDP';
    this.getSitEitDetails();
  }
  getSitEitDetails() {
    this.showLoader = true;
    this.sitEitSubscription$ = this.requestDetailService.getRequestdetails(this.requestType, this.requestCode).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.reqName = response.requestName;
          this.reqDetails = response.sitEitSummaryTab;
        }
        if (response.returnCode === '9') {
          this.reqName = response.requestName;
          this.noSummary = true;
        }
        if (response.returnCode === '1') {
          this.reqName = response.requestName;
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  addRequest() {
    this.router.navigate(['/learning/add-idp', this.requestCode, this.requestType]);
  }
  ngOnDestroy() {
    this.sitEitSubscription$.unsubscribe();
  }

}
