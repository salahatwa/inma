import { CourseClassesComponent } from './learning-home/courses/course-category/course-detail/course-classes/course-classes.component';
import { AddRequestComponent } from './../employee-request/add-request/add-request.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LearningComponent } from './learning.component';
import { LearningHomeComponent } from './learning-home/learning-home.component';
import { IndividialDevelopmentComponent } from './individial-development/individial-development.component';
import { CourseRequestComponent } from './course-request/course-request.component';
import { CoursesComponent } from './learning-home/courses/courses.component';
import { CourseCategoryComponent } from './learning-home/courses/course-category/course-category.component';
import { CourseDetailComponent } from './learning-home/courses/course-category/course-detail/course-detail.component';
import { EnrollComponent } from './learning-home/courses/course-category/course-detail/enroll/enroll.component';
import { AddIndividualDevelopmentComponent } from './individial-development/add-individual-development/add-individual-development.component';
import { AddCourseRequestComponent } from './course-request/add-course-request/add-course-request.component';

const routes: Routes = [
  {
    path: '', component: LearningComponent,
    children: [
      { path: '', redirectTo: 'learning-home', pathMatch: 'full' },
      { path: 'learning-home', component: LearningHomeComponent, data: { title: 'Learning' } },
      { path: 'individial-development', component: IndividialDevelopmentComponent, data: { title: 'Learning' } },
      { path: 'course-request', component: CourseRequestComponent, data: { title: 'Learning' } },
      { path: 'courses', component: CoursesComponent, data: { title: 'Learning' } },
      { path: 'courses-category/:id', component: CourseCategoryComponent, data: { title: 'Learning' } },
      { path: 'courses-details/:activityVersionId/:categoryUsageId', component: CourseDetailComponent, data: { title: 'Learning' } },
      { path: 'enroll', component: EnrollComponent, data: { title: 'Learning' } },
      { path: 'learning-home', component: LearningHomeComponent, data: { title: 'Learning' } },
      { path: 'individial-development', component: IndividialDevelopmentComponent, data: { title: 'Learning' } },
      { path: 'course-request', component: CourseRequestComponent, data: { title: 'Learning' } },
      { path: 'classes', component: CourseClassesComponent, data: { title: 'Learning' } }
    ]
  },
  { path: 'courses', component: CoursesComponent, data: { title: 'Learning' } },
  { path: 'courses-category', component: CourseCategoryComponent, data: { title: 'Learning' } },
  { path: 'courses-details', component: CourseDetailComponent, data: { title: 'Learning' } },
/*   { path: 'classes', component: CourseClassesComponent, data: { title: 'Learning' } }, */
  { path: 'enroll', component: EnrollComponent, data: { title: 'Learning' } },
  { path: 'add-individual-development', component: AddIndividualDevelopmentComponent, data: { title: 'Learning' } },
  { path: 'add-course-request', component: AddCourseRequestComponent, data: { title: 'Learning' } },
  { path: 'add-idp/:code/:type', component: AddRequestComponent, data: { title: 'Individual Development Plan' } },
  { path: 'add-adhoc/:code/:type', component: AddRequestComponent, data: { title: 'Adhoc Courses' } }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LearningRoutingModule { }
