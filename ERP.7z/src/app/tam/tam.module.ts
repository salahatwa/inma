import { SharedModule } from './../shared/shared.module';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { FindTamComponent } from './find-tam/find-tam.component';
import { TamRoutingModule } from './tam-routing.module';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    SharedModule,
    TamRoutingModule,
    NgxMyDatePickerModule.forRoot()
  ],
  declarations: [FindTamComponent]
})
export class TamModule { }
