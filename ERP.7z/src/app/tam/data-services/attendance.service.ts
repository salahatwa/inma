import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
  ) { }

  fetchAttendanceDetails(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    const url = this.url.fetchAttendanceDetailsURl();
    return this.http.post<any>(url, data);
  }
  getSearchReult(data): Observable<any> {
    data.loggedInUser = this.common.getUserDetails().userName;
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    const url = this.url.fetchEmployeeListingForAttendanceURl();
    return this.http.post<any>(url, data);
  }
  createViolation(data): Observable<any> {
    data.userName = this.common.getUserDetails().userName;
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    const url = this.url.getAttendanceActionUrl();
    return this.http.post<any>(url, data);
  }
  getViolationType(data): Observable<any> {
    data.language = this.common.getLanguage() === 'en' ? 'AMERICAN' : 'ARABIC';
    const url = this.url.getViolationTypeUrl();
    return this.http.post<any>(url, data);
  }
}
