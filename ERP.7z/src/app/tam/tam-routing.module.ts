import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FindTamComponent } from './find-tam/find-tam.component';

const routes: Routes = [
  { path: '', component: FindTamComponent, data: { title: 'Attendance' } }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TamRoutingModule { }
