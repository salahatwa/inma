import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class TamService {
  tamDetail = [];
  constructor(
    private url: UrlGeneratorService,
    private readonly common: CommonService,
    private http: HttpClient
  ) {}

  getTamDetail(): Observable<any> {
    const url = this.url.getTamDetailUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: userDetails.userName
    };
    return this.http.post<any>(url, data).pipe(
      tap(response => {}),
      catchError(error => {
        return throwError(error);
      })
    );
  }

  getTamReason(data): Observable<any> {
    const url = this.url.getTamReasonUrl();
    const userDetails = this.common.getUserDetails();

    return this.http.post<any>(url, data).pipe(
      tap(response => {}),
      catchError(error => {
        return throwError(error);
      })
    );
  }
  getTAMDashboardDetails(data): Observable<any> {
    const url = this.url.getTamDashboardUrl();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
}
