import { Component, OnInit, OnDestroy } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MetadataService } from 'src/app/employee-request/data-services/metadata.service';
import { Subject, Subscription } from 'rxjs';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { AttendanceService } from '../data-services/attendance.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { ToastFailed, ToastSuccess } from 'src/app/shared/constants/globalConstants';

@Component({
  providers: [DatePipe],
  selector: 'app-find-tam',
  templateUrl: './find-tam.component.html',
  styleUrls: ['./find-tam.component.scss']
})
export class FindTamComponent implements OnInit, OnDestroy {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  metaData: any = [];
  showLoader = false;
  showViolation = false;
  showLoaderSearch = false;
  showSearchResults = false;
  search = false;
  attendanceDetails = [];
  searchedEmployees = [];
  violationData = [];
  counter$ = new Subject<number>();
  submitSubscripiton$: Subscription;
  counterSub$: Subscription;
  violationChangeSub$: Subscription;
  attendanceSub$: Subscription;
  violationSub$: Subscription;
  employeeListingSub$: Subscription;
  message = '';
  noEmployeeMessage = '';
  employeeDisplayName = '';
  violationAction = '';
  violationType = '';
  form: { [k: string]: any } = {
    'empNumber': '',
    'fromDate': '',
    'minLateFrom': '',
    'minLateTo': '',
    'status': '',
    'orgName': '',
    'toDate': ''
  };
  searchEmployeeForm: { [k: string]: any } = {};
  private metadataSubscription$: Subscription = new Subscription;
  constructor(
    private readonly datePipe: DatePipe,
    private metadataService: MetadataService,
    private attendanceService: AttendanceService,
    private common: CommonService
  ) { }

  ngOnInit() {
    this.counterSub$ = this.counter$.subscribe(
      value => {
        if (value === 2) {
          this.showLoader = false;
        }
      }
    );
    this.getDropdownMetaData();
  }
  getDropdownMetaData() {
    this.showLoader = true;
    const types = ['ATTND_JUSTIFY', 'ATTND_ORG', 'VIOL_ACT', 'VIOL_TYPE'];
    this.callMetaDataApi(types);
  }
  callMetaDataApi(typeArray: any) {
    let counter = 0;
    typeArray.forEach(type => {
      this.metadataSubscription$.add(this.metadataService.getMetadata(type).subscribe(
        response => {
          counter++;
          this.counter$.next(counter);
          if (response.res.returnCode === '0') {
            this.metaData[response.type] = response.res.lookupTab;
          }
        },
        () => {
          counter++;
          this.counter$.next(counter);
        }
      ));
    });
  }
  onViolationTypeChange(key) {
    if (key) {
      const data = {
        'pCode': key
      };
      this.violationChangeSub$ = this.attendanceService.getViolationType(data).subscribe(
        response => {
          if (response.returnCode === '0') {
            this.violationAction = response.lookupTab[0].key;
          } else {
            ToastFailed.message = response.returnMsg;
            this.common.showToast(ToastFailed);
          }
        }
      );
    }
  }
  searchEmployees() {
    this.showLoaderSearch = true;
    const splitArray = this.employeeDisplayName.split(':');
    if (splitArray.length === 2) {
      this.employeeDisplayName = splitArray[0].trim();
    } else {
      this.form.empNumber = '';
    }
    const data = {
      userName: this.employeeDisplayName ? this.employeeDisplayName : '%',
      type: '',
      startFrom: '',
      EndTo: ''
    };
    this.employeeListingSub$ = this.attendanceService.getSearchReult(data).subscribe(
      response => {
        this.showLoaderSearch = false;
        this.noEmployeeMessage = '';
        this.searchedEmployees = [];
        this.showSearchResults = false;
        if (response.returnCode === '0') {
          this.searchedEmployees = response.employeeList;
          this.showSearchResults = true;
        } else if (response.returnCode === '9') {
          this.showSearchResults = true;
          this.form.empNumber = '';
          this.noEmployeeMessage = response.returnMsg;
        }
      },
      () => {
        this.noEmployeeMessage = '';
        this.showLoaderSearch = false;
      }
    );
  }
  chooseEmployee(employee) {
    this.form.empNumber = employee.employeeNumber;
    this.showSearchResults = false;
    this.employeeDisplayName = employee && `${employee.employeeNumber} : ${employee.employeeName}`;
  }
  getAttendanceDetails() {
    this.showLoader = true;
    if (this.form.fromDate && this.form.fromDate.jsdate) {
      this.form.fromDate = `${this.datePipe.transform(this.form.fromDate.jsdate, 'yyyy-MM-dd')}`;
    }
    if (this.form.toDate && this.form.toDate.jsdate) {
      this.form.toDate = `${this.datePipe.transform(this.form.toDate.jsdate, 'yyyy-MM-dd')}`;
    }
    if (this.employeeDisplayName === '') {
      this.form.empNumber = '';
    }
    const data = { ...this.form };
    this.attendanceSub$ = this.attendanceService.fetchAttendanceDetails(data).subscribe(
      response => {
        this.showLoader = false;
        this.message = '';
        this.attendanceDetails = [];
        if (response.returnCode === '0') {
          this.attendanceDetails = response.attendanceDetails;
        } else if (response.returnCode === '9') {
          this.message = response.returnMsg;
        } else {
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
      },
      () => {
        this.message = '';
        this.showLoader = false;
      }
    );
  }
  showViolationPopup(employeeData) {
    this.violationData.push(employeeData);
    this.showViolation = true;
  }
  closeViolationPopup() {
    this.violationData = [];
    this.showViolation = false;
    this.violationAction = '';
    this.violationType = '';
  }
  createViolation(action) {
    this.showLoader = true;
    this.violationData[0].submitDate = '';
    this.violationData[0].violationAction = this.violationAction;
    this.violationData[0].violationType = this.violationType;
    const data = {
      attendanceDetails: this.violationData,
      'action': action
    };
    this.violationSub$ = this.attendanceService.createViolation(data).subscribe(
      response => {
        this.showLoader = false;
        this.violationData = [];
        if (response.returnCode === '0') {
          const toast = ToastSuccess;
          toast.message = response.returnMsg;
          this.getAttendanceDetails();
          this.common.showToast(toast);
        } else {
          const toast = ToastFailed;
          toast.message = response.returnMsg;
          this.common.showToast(toast);
        }
        this.closeViolationPopup();
      },
      () => {
        this.showLoader = false;
      }
    );
  }
  ngOnDestroy() {
    this.counterSub$.unsubscribe();
    this.metadataSubscription$.unsubscribe();
    if (this.submitSubscripiton$) {
      this.submitSubscripiton$.unsubscribe();
    }
    if (this.attendanceSub$) {
      this.attendanceSub$.unsubscribe();
    }
    if (this.employeeListingSub$) {
      this.employeeListingSub$.unsubscribe();
    }
    if (this.violationSub$) {
      this.violationSub$.unsubscribe();
    }
    if (this.violationChangeSub$) {
      this.violationChangeSub$.unsubscribe();
    }
  }
}
