import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, Renderer2 } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  toast: { show: true; status: string; message: string };
  showSidenav = false;
  message = '';
  constructor(private translate: TranslateService,
    private readonly common: CommonService,
    private readonly renderer: Renderer2,
    private readonly router: Router) {
    translate.setDefaultLang('en');
    translate.use(this.common.getLanguage());
  }
  title = 'alinma-web';
  ngOnInit() {
    this.common.getToast().subscribe(response => {
      this.toast = response;
      this.message = this.translate.instant(this.toast.message);
      setTimeout(() => {
        this.toast = null;
        this.message = '';
      }, 7000);
    });
    if (localStorage.getItem('language') === 'ar') {
      this.renderer.addClass(document.body, 'arabic');
    } else {
      this.renderer.removeClass(document.body, 'arabic');
      localStorage.setItem('language', 'en');
    }
    window.addEventListener('storage', (event) => {
      if (event.storageArea === localStorage) {
        const token = localStorage.getItem('authToken');
        if (token === undefined || !token) {
          this.common.logout();
        }
      }
    }, false);
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit() {
    this.router.events.subscribe(e => {
      if (e instanceof NavigationEnd) {
        this.showSidenav = (e.url !== '/login' && e.url !== '/') ? true : false;
      }
    });
  }
  clearToast() {
    this.toast = null;
    this.message = '';
  }
}
