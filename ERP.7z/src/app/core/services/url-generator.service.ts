import { Injectable } from '@angular/core';
import { EnvironmentProvider } from '../../shared/constants/environment';

@Injectable({
  providedIn: 'root'
})
export class UrlGeneratorService {

  constructor(private environment: EnvironmentProvider) { }

  getLoginUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/user/getUserDetails`;
  }
  getRefreshTokenUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/user/refresh`;
  }
  getEmploymentUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/getEmployementDetails`;
  }
  getSalaryDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/getSalaryDetails`;
  }
  getRequestListingUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/getSitEitList`;
  }
  getSitEitDetails(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/getSitEitDetails`;
  }
  getSitEitMetaData(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/getSitEitMetaData`;
  }
  getworkListUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/getWorkList`;
  }
  getPersonalDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/getProfileDetails`;
  }
  getworkListDetailUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/getWorkListDetails`;
  }
  getworkListAICDetailUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/offTripWorkList`;
  }
  getExpenseClaimworkListAICDetailUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/expenseClaimWorkList`;
  }
  getAttendanceDetailUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/expenseClaimWorkList`;
  }
  getTamworkListDetailUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/tam/getNotificationDetails`;
  }
  getworkpayslipDateUrl() {
    return `${this.environment.baseURL}/aichrmsservices/payslip/dates`;
  }
  getworkpayslipDetailUrl() {
    return `${this.environment.baseURL}/aichrmsservices/payslip/details`;
  }
  getDependentFlexValueSetUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/getDependentFlexValueSet`;
  }
  getEitSubmitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/createEITTransaction`;
  }
  getEitSubmitUrlV2(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/createEITTransactionV2`;
  }
  getEmployeeRequestSubmitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/submitEmployeeRequest`;
  }
  getSitSubmitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/createSITransaction`;
  }
  getSitSubmitUrlV2(): string {
    return `${this.environment.baseURL}/aichrmsservices/dashbord/createSITransactionV2`;
  }
  getTeamCalendarUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/getEmployeeCalendar`;
  }
  getLeaveTypeUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/type`;
  }
  getLeaveDurationUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/duration`;
  }
  getEntitlementBalanceUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/entitlement/balance/view`;
  }
  getAbsenceDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/getAbsenceSummary`;
  }
  getAbsenseSummaryCountUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/getAbsenseSummaryCount`;
  }
  getreplacedByUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/replacedBy`;
  }
  getCreateAbsence(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/createAbsence`;
  }
  getDeleteDependentUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/manageDependent`;
  }
  getEditDependentUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/manageDependent`;
  }
  getAddDependentUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/manageDependent`;
  }
  getKeyValueSetListUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/getKeyValueSetList`;
  }
  getEditEmployeeDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/editEmployeeDetails`;
  }
  getTamDetailUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/tam/getDetails`;
  }
  getEditContactNumberUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/editContactNumber`;
  }
  getaddAttachmentUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/leave/attachment/download`;
  }
  getExecuteActionUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/executeAction`;
  }
  getTamActionUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/tam/executeTAMAction`;
  }
  getTamReasonUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/tam/editReason`;
  }
  getTamDashboardUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/tam/executeTamDashboard`;
  }
  getcreditCard(): string {
    return `${this.environment.baseURL}/aichrmsservices/creditCard/createRequest`;
  }
  getcreditCardInfo(): string {
    return `${this.environment.baseURL}/aichrmsservices/creditCard/instruction`;
  }
  getcreditCardSummary(): string {
    return `${this.environment.baseURL}/aichrmsservices/creditCard/summary`;
  }
  getLearningSummary(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/getLearningSummaryDetails`;
  }
  getCourses(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/getCourseCategories`;
  }
  getCourseSubCategories(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/getCourseSubCategories`;
  }
  getCourseDetails(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/getCourseDetails`;
  }
  getCourseClasses(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/getCourseEnrollDetails`;
  }
  getSubordinatesListingUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/getSubOrdinateList`;
  }
  getPerformanceDetails(): string {
    return `${this.environment.baseURL}/aichrmsservices/performancemanagement/performancedetails`;
  }
  getPerformanceRatingDetails(): string {
    return `${this.environment.baseURL}/aichrmsservices/performancerating/performanceratingdetails`;
  }
  getManagerActionsSitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/createManagerSITTransaction`;
  }
  getManagerActionsEmpBaciInfoUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/editEmployeeBasicInformation`;
  }
  getManagerActionsEmpPhoneUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/editEmployeePhone`;
  }
  getManagerActionsManageDependentUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/manageDependent`;
  }
  getManagerActionsLeaveManagementUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/createAbsence`;
  }
  getFinaceSummaryURL(): string {
    return `${this.environment.baseURL}/aichrmsservices/finance/getFinaceSummary`;
  }
  getFinanceQuestionDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/finance/getFinanceQuestionDetails`;
  }
  getFinaceProductTypeUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/finance/getFinaceProductType`;
  }
  getFinaceSubmitRequestUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/finance/submitRequest`;
  }
  getCreditCardWorklistDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/creditCard/worklistDetails`;
  }
  getFinancingWorklistDetailsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/finance/financeRequestNotification`;
  }
  getCreditCardWorklistApprovalUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/creditCard/approval`;
  }
  getFinancingWorklistApprovalUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/finance/financeRequestApproval`;
  }
  getQuickLinkUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/user/getQuickLinks`;
  }
  getJustificationDropdown(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/bookingJustification`;
  }
  enrollCourse(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/learningEnrollment`;
  }
  unEnrollCourse(): string {
    return `${this.environment.baseURL}/aichrmsservices/learning/cancelEnrollment`;
  }
  getSearchUserlistUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/user/userSearch`;
  }
  getObjectiveMetaDataURL(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/objectiveMetaData`;
  }
  transferObjectiveUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/transferObjective`;
  }
  objectiveListingUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/objectiveListing`;
  }
  objectiveSubmitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/trackObjective`;
  }
  createObjectiveURL(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/createObjective`;
  }
  completeObjective(): string {
    return `${this.environment.baseURL}/aichrmsservices/performancemanagement/completeObjective`;
  }
  reviewWorkerChanges(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/reviewWorkerChanges`;
  }
  getAppraisalDetails(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/fetchAppraisal`;
  }
  getCreateAppraisalDetails(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/createAppraisal`;
  }
  submitFeedback(): string {
    return `${this.environment.baseURL}/aichrmsservices/performancemanagement/shareAppraisal`;
  }
  getCancelEmpEnrollUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/worklist/cancelEnrollAction`;
  }
  getResignationResonsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/metaDataDropdown`;
  }
  getCoursePeriodUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/metaDataDropdown`;
  }
  getOfficialTripSummaryUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/officialTrip/getSummary`;
  }
  getOfficialTripSubmitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/officialTrip/manage`;
  }
  getExpenseClaimSummaryUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/expense/getClaimSummary`;
  }
  getExpenseSubmitUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/expense/create`;
  }
  getResignationRequestUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/resignation/create`;
  }
  getMyDocumentsSummaryUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/myDocument/summary`;
  }
  getCreateMyDocumentsUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/myDocument/create`;
  }
  fetchRegistrationDetailsURl(): string {
    return `${this.environment.baseURL}/aichrmsservices/resignation/details`;
  }
  fetchAttendanceDetailsURl(): string {
    return `${this.environment.baseURL}/aichrmsservices/attendance/fetch`;
  }
  getHRAllEmployeeListingUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/manageractions/hrEmployeeList`;
  }
  fetchEmployeeListingForAttendanceURl(): string {
    return `${this.environment.baseURL}/aichrmsservices/attendance/employeeList`;
  }
  getEducationandQualifcationSummaryUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/eduAndQual/summary`;
  }
  getAttendanceActionUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/attendance/attendanceAction`;
  }
  getViolationTypeUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/profile/violationDropDown`;
  }
  getEducationAndQualificationUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/eduAndQual/create`;
  }
  getSchoolSearchUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/eduAndQual/searchSubject`;
  }
  modifyObjectivesUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/managerPerformance/modifObjective`;
  }
  getEducationWorklistUrl(): string {
    return `${this.environment.baseURL}/aichrmsservices/eduAndQual/getWorkList`;
  }
}
