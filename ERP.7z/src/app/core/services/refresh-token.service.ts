import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { tap, catchError, subscribeOn } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RefreshTokenService {

  constructor(
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService,
    private readonly http: HttpClient
  ) { }
  getRefreshToken() {
    const url = this.url.getRefreshTokenUrl();
    const oldRefreshToken = this.common.getRefreshToken();
    const body = {
      refreshtoken: oldRefreshToken,
      deviceId: 'web'
    };
    return this.http.post<any>(url, body).pipe(
      tap((response) => {
        localStorage.setItem('authToken', '');
        localStorage.setItem('authToken', JSON.stringify({ 'accessToken': response.accessToken, 'refreshToken': response.refreshToken }));
      })
    );
  }
}
