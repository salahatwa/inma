import { CommonService } from 'src/app/shared/services/common.service';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { map, catchError, filter, switchMap, tap, take } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { RefreshTokenService } from './refresh-token.service';
@Injectable()
export class ApiInterceptor implements HttpInterceptor {
  isRefreshingToken = false;
  cachedRequest: HttpRequest<any>;
  private refreshTokenSubject$: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  constructor(
    private readonly router: Router,
    private readonly common: CommonService,
    private readonly refreshTokenService: RefreshTokenService
  ) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let toast;
    if (this.common.getAccessToken()) {
      const accessToken = this.common.getAccessToken();
      const refreshToken = this.common.getRefreshToken();
      request = request.clone({ headers: request.headers.set('Access-Token', accessToken) });
    }
    request = request.clone({
      headers: request.headers.set('Content-Type', 'application/json'),
      body: { ...request.body, language: this.common.getRequestLanguage() }
    });
    return next.handle(request).pipe(
      tap((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          switch (event.body.returnCode) {
            case '0':
              event.body.returnMsg = 'SUBMITMSG';
              break;
            case '7':
              event.body.returnMsg = 'CANCELMSG';
              break;
            case '400':
            case '401':
              this.common.logout();
              toast = {
                'show': true,
                'status': 'failed',
                'message': 'Your session has expired. Please login again'
              };
              this.common.showToast(toast);
              break;
            case '500':
              toast = {
                'show': true,
                'status': 'failed',
                'message': 'Something went wrong, please try after some time'
              };
              this.common.showToast(toast);
              break;
            case '402':
              toast = {
                'show': true,
                'status': 'failed',
                'message': 'Your session has expired. Please login again'
              };
              this.common.showToast(toast);
              // return this.handle402(request, next);
              this.common.logout();
          }
        }
      }
      ),
      catchError((error: any) => {
        if (error instanceof HttpErrorResponse && error.status === 401 && error.error.toLowerCase().includes('expired')) {
          return this.handle402(request, next);
        } else if (error instanceof HttpErrorResponse && error.status === 401 && error.error.toLowerCase().includes('invalid')) {
          this.common.logout();
          toast = {
            'show': true,
            'status': 'failed',
            'message': 'Your session has expired. Please login again'
          };
          this.common.showToast(toast);
        } else {
          toast = {
            'show': true,
            'status': 'failed',
            'message': 'Connection Timed Out'
          };
          this.common.showToast(toast);
        }
        return throwError(error);
      })
    );
  }
  handle402(request: HttpRequest<any>, next: HttpHandler) {
    if (!this.isRefreshingToken) {
      this.isRefreshingToken = true;
      this.refreshTokenSubject$.next(null);
      return this.refreshTokenService.getRefreshToken().pipe(
        switchMap((token: any) => {
          this.isRefreshingToken = false;
          this.refreshTokenSubject$.next(token.accessToken);
          request = request.clone({ headers: request.headers.set('Access-Token', token.accessToken) });
          return next.handle(request);
        })
      );
    } else {
      return this.refreshTokenSubject$.pipe(
        filter(token => token != null),
        take(1),
        switchMap((accessToken) => {
          request = request.clone({ headers: request.headers.set('Access-Token', accessToken) });
          return next.handle(request);
        })
      );
    }
  }
}
