import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { CommonService } from '../../shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(
    public readonly common: CommonService,
    public readonly router: Router
  ) { }

  canActivate(): boolean {
    const userDetails = this.common.getUserDetails();
    if (userDetails) {
      return true;
    }
    this.router.navigate(['./login']);
    return true;
  }
}
