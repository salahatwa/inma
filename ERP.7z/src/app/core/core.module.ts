import { ApiInterceptor } from './services/api-interceptor';
import { NgModule } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

@NgModule({
  imports: [
  ],
  declarations: [],
  exports: [],
  providers: [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: ApiInterceptor,
    multi: true
  }
],
})
export class CoreModule { }
