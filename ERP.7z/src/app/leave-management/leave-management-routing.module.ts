import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LeaveManagementComponent } from './leave-management.component';
import { AbsenceSummaryComponent } from './absence-summary/absence-summary.component';
import { ReturnLeaveComponent } from './return-leave/return-leave.component';
import { CreateAbsenceComponent } from './absence-summary/create-absence/create-absence.component';
import { CreateReturnLeaveComponent } from './return-leave/create-return-leave/create-return-leave.component';

const routes: Routes = [
  { path: '', component: LeaveManagementComponent,
  children : [
    { path: '', redirectTo: 'absence', pathMatch: 'full' },
    { path: 'absence', component: AbsenceSummaryComponent,  data: { title: 'Leave Management' } },
    { path: 'return', component: ReturnLeaveComponent,  data: { title: 'Leave Management' } },
  ]
  },
  { path: 'absence-summary/create-absence', component: CreateAbsenceComponent },
  { path: 'return-from-leave-request/create-return-leave', component: CreateReturnLeaveComponent }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LeaveManagementRoutingModule { }
