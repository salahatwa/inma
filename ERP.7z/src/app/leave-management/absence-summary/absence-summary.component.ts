import { CommonService } from 'src/app/shared/services/common.service';
import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Month } from '../../shared/constants/month.constants';
import { MonthArabic } from '../../shared/constants/month_arabic.constants';
import { LeaveSummaryService } from '../data-service/leave-summary.service';
import { Router } from '@angular/router';

@Component({
  providers: [DatePipe],
  selector: 'app-absence-summary',
  templateUrl: './absence-summary.component.html',
  styleUrls: ['./absence-summary.component.scss']
})
export class AbsenceSummaryComponent implements OnInit {
  year: any;
  month: any;
  day: any;
  date: any;
  selectedUser = '';
  selectedUserId: number;
  managerAction = false;
  showLoader = false;
  attachment = false;
  leaveBalanceTab: any;
  absenceSummaryTab: any;
  popupData: any;
  message = false;
  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: 'dd.mm.yyyy',
    inline: true,
    firstDayOfWeek: 'su'
  };

  public absenceSummaryForm: FormGroup;
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly leaveSummaryService: LeaveSummaryService,
    private readonly route: Router,
    private readonly common: CommonService,
    private readonly router: Router,
    private readonly datePipe: DatePipe
  ) { }

  ngOnInit() {
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.selectedUserId = +this.common.getUserIdForMngrAction();
    this.initialBalance();
    this.getAbsenceDetails();

    this.absenceSummaryForm = this.formBuilder.group({
      // Empty string or null means no initial value. Can be also specific date for
      // example: {date: {year: 2018, month: 10, day: 9}} which sets this date to initial
      // value.

      myDate: [null, Validators.required]
      // other controls are here...
    });
    this.setToday();

  }
  setToday() {
    const date = new Date();
    this.year = date.getFullYear();
    this.day = date.getDate();
    if (localStorage.getItem('language') == 'ar') {
      this.month = MonthArabic[(date.getMonth() + 1) - 1];
      this.date = `${this.day} ${this.month} ${this.year}`;
    } else {
      this.month = Month[(date.getMonth() + 1) - 1];
      this.date = `${this.day} ${this.month} ${this.year}`;
    }
  }

  setDate(): void {
    // Set today date using the patchValue function
    const date = new Date();
    this.absenceSummaryForm.patchValue({
      myDate: {
        date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      }
    });
    this.year = date.getFullYear();
    this.day = date.getDay();

    if (localStorage.getItem('language') == 'ar') {
      this.month = MonthArabic[(date.getMonth() + 1) - 1];
      this.date = `${this.day} ${this.month} ${this.year}`;
    } else {
      this.month = Month[(date.getMonth() + 1) - 1];
      this.date = `${this.day} ${this.month} ${this.year}`;
    }
  }
  onDateChanged(event: IMyDateModel) {
    this.showLoader = true;
    /* event properties are: event.date, event.jsdate, event.formatted and event.epoc */
    this.year = event.date.year;
    this.day = event.date.day;
    this.month = Month[event.date.month - 1];
    this.date = `${this.day} ${this.month} ${this.year}`;
    const formattedDate = this.datePipe.transform(new Date(event.jsdate), 'yyyy-MM-dd');
    // const formattedDate = `${event.jsdate.toISOString().split('T')[0]} 00:00:00`;
    this.leaveSummaryService.getEntitlementBalance(formattedDate, this.selectedUser, this.selectedUserId, this.managerAction).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.leaveBalanceTab = response.leaveBalanceTab;
        }

      },
      (error) => {
        this.showLoader = false;

      }
    );
  }
  viewDetails(data) {
    this.attachment = true;
    this.popupData = data;
  }
  closeAttachment(event) {
    this.attachment = event;
  }
  initialBalance() {
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    this.leaveSummaryService.getEntitlementBalance(formattedDate, this.selectedUser, this.selectedUserId, this.managerAction).subscribe(
      (response) => {
        if (response.returnCode === '0') {
          this.leaveBalanceTab = response.leaveBalanceTab;
        }

      },
      (error) => {

      }
    );
  }
  editAbsence(data) {
    if (localStorage.getItem('absenceDetails')) {
      localStorage.setItem('absenceDetails', '');
    }
    localStorage.setItem('absenceDetails', JSON.stringify(data));
    if (this.router.url.includes('manager-self-service')) {
    this.route.navigate(['/manager-self-service/leave-details/create', { edit: true }]);
    } else {
      this.route.navigate(['/leave-management/absence-summary/create-absence', { edit: true }]);
    }
  }
  getAbsenceDetails() {
    this.showLoader = true;
    this.leaveSummaryService.getAbsenceDetails(this.selectedUser, this.managerAction).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.message = false;
          this.absenceSummaryTab = response.absenceSummaryTab;
          this.absenceSummaryTab.forEach(element => {
            element.futureDate = false;
            if (new Date(element.endDate) > new Date() && element.status === 'Approved') {
              element.futureDate = true;
            }
          });
        }
        if (response.returnCode === '1') {
          this.message = true;
        }

      },
      (error) => {
        this.showLoader = false;

      }
    );
  }
  createLeave() {
    this.route.navigate(['/manager-self-service/leave-details/create']);
  }
}
