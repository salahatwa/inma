import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../../../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AbsenceSummaryService {

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient
  ) { }

  createAbsence(data, mngrAction): Observable<any> {
    let url = '';
    if (mngrAction) {
      url = this.url.getManagerActionsLeaveManagementUrl();
    } else {
     url = this.url.getCreateAbsence();
    }
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
}
