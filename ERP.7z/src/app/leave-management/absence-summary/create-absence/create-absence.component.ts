import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { LeaveSummaryService } from '../../data-service/leave-summary.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { AbsenceSummaryService } from './absence-summary.service';
import { CommonService } from '../../../shared/services/common.service';
import { Subscription, Observable, Subject } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import {
  ToastSuccess
} from 'src/app/shared/constants/globalConstants';
import { MonthSmall } from 'src/app/shared/constants/month.constants';
import { CanComponentDeactivate } from 'src/app/shared/services/can-deactivate-guard.service';
@Component({
  providers: [DatePipe],
  selector: 'app-create-absence',
  templateUrl: './create-absence.component.html',
  styleUrls: ['./create-absence.component.scss']
})
export class CreateAbsenceComponent implements OnInit, CanComponentDeactivate {
  showAddAttachment = false;
  summaryData: any;
  showPickerStart = false;
  showPickerEnd = false;
  timeData;
  type = '';
  transactionId = '';
  uploadedFile = [];
  endDateHasValue = false;
  startDateHasValue = false;
  formsubmit = false;
  hasValueEndDAte = false;
  attachmentRequired = false;
  subscription$: Subscription;
  leaveTypeMeta: any;
  test: any;
  validationMessage = '';
  attachmentValidation: string;
  hoursDuration: number;
  managerAction = false;
  selectedUser = '';
  selectedUserId: number;
  replacedTypeMeta: any;
  disableUntil: any;
  daysDuration: number;
  leaveTypeId: number;
  backConfirm = false;
  confirm$: Subject<boolean> = new Subject<boolean>();
  leaveForm: FormGroup;
  showLoader = false;
  editPage = 'false';
  approverList: any = [];
  myOptions: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su',
    disableUntil: { year: 0, month: 0, day: 0 }
  };
  myOptionsar: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'su',
    disableUntil: { year: 0, month: 0, day: 0 }
  };
  myOptions1: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  myOptions1ar: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'su'
  };
  language = '';
  enableTimeFields = false;
  startDateSelected = false;
  base64TOView = '';
  showViewAttachmentSec = false;
  userDetailsValue;
  showReplacedByList = false;
  selectedReplacedBy: any = { personId: '', personName: '' };
  searchText: any;
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly leaveSummaryService: LeaveSummaryService,
    private readonly createAbsenceSummary: AbsenceSummaryService,
    private readonly router: Router,
    private route: ActivatedRoute,
    private readonly datepipe: DatePipe,
    private readonly location: Location,
    private readonly common: CommonService
  ) { }

  ngOnInit() {
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.selectedUserId = +this.common.getUserIdForMngrAction();
    this.language = this.common.getLanguage();
    this.userDetailsValue = this.common.getUserDetails();
    this.getLeaveType();
    // this.getReplaced();
    this.leaveForm = this.formBuilder.group({
      absenceTypeId: '',
      leaveType: '',
      startDate: '',
      endDate: '',
      startTime: '',
      endTime: '',
      replacedVal: '',
      userComments: '',
      totalHours: '',
      totalDays: '',
      totalLeaves: '',
      attribute1: '',
      attribute2: '',
      attribute3: '',
      attribute11: ''
    });
    !this.leaveForm.value.startDate
      ? this.leaveForm.get('endDate').disable()
      : this.leaveForm.get('endDate').enable();
    !this.leaveForm.value.startTime
      ? this.leaveForm.get('endTime').disable()
      : this.leaveForm.get('endTime').enable();
    this.route.params.subscribe(params => {
      this.editPage = params.edit;
    });
  }

  setData() {
    const data = JSON.parse(localStorage.getItem('absenceDetails'));
    this.setDateTimeFlag(data.leavetypeId);
    this.uploadedFile = [...data.attachmentDetails];
    this.uploadedFile = Object.assign([], this.uploadedFile);
    this.leaveForm.controls.absenceTypeId.setValue(data.leavetypeId);
    this.leaveForm.controls.totalDays.setValue(data.leaveDurationDays);
    // this.leaveForm.controls.replacedVal.setValue(data.replacementPersonId);
    this.selectedReplacedBy.personId = data.replacementPersonId; // for edit
    // this.leaveForm.controls.replacedVal.setValue(data.replacedBy); // for edit
    this.searchText = data.replacedBy;
    this.leaveForm.controls.userComments.setValue(data.comments);
    this.leaveForm.controls.attribute2.setValue(data.attribute2);
    this.leaveForm.controls.attribute11.setValue(data.attribute11);
    this.leaveForm.controls.startTime.setValue(data.timeStart);
    this.leaveForm.controls.endTime.setValue(data.timeEnd); // for edit
    this.leaveForm.controls.totalHours.setValue(data.durationHours);
    this.leaveForm.controls.startDate.setValue({
      jsdate: new Date(data.startDate)
    });
    this.startDateHasValue = true;
    this.leaveForm.get('endDate').enable();
    this.leaveForm.controls.endDate.setValue({
      jsdate: new Date(data.endDate)
    });
    this.endDateHasValue = true;
  }

  setDate(): void {
    // Set today date using the patchValue function
    const date = new Date();
    this.leaveForm.patchValue({
      myDate: {
        date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()
        }
      }
    });
  }
  clearDate(): void {
    // Clear the date using the patchValue function
    // this.myForm.patchValue({myDate: null});
  }
  getLeaveType() {
    this.showLoader = true;
    this.leaveSummaryService.getLeaveType(this.managerAction, this.selectedUserId).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.leaveTypeMeta = response.leaveAbsenceType;
          if (this.editPage === 'true') {
            this.setData();
          }
        }
        this.showLoader = false;
      },
      error => {
        this.showLoader = false;

      }
    );
    this.leaveSummaryService.getReplaced(this.managerAction, this.selectedUserId).subscribe(
      response => {
        this.showLoader = false;

        if (response.returnCode === '0') {
          this.replacedTypeMeta = response.replacedByTab;
        }
      },
      error => {
        this.showLoader = false;

      }
    );
  }

  startDate(event) {
    // this.onDisablePast(event.currentTarget.checked);
  }
  getDaysDurationAPI(data) {
    if (data.absenceTypeId) {
      data.endDate = this.datepipe.transform(new Date(data.endDate), 'dd-MMM-yyyy');
      data.startDate = this.datepipe.transform(new Date(data.startDate), 'dd-MMM-yyyy');
      this.showLoader = true;
      this.leaveSummaryService.getLeaveDuration(data, this.managerAction, this.selectedUserId).subscribe(
        response => {
          this.showLoader = false;

          if (response.returnCode === '0') {
            this.validationMessage = '';
            // this.daysDuration = response.duration;
            this.leaveForm.controls.totalDays.setValue(response.duration);
            this.daysDuration = response.duration;
          } else if (response.returnCode === '1') {
            this.leaveForm.controls.totalDays.setValue(response.duration);
            this.daysDuration = response.duration;
            this.validationMessage = response.returnMsg;
          }
          this.showLoader = false;
        },
        error => {
          this.validationMessage = '';

        }
      );
    } else {
      this.validationMessage = 'A value must be enterd for Absence Type';
    }
  }
  startDateChange(event, checked?: boolean) {
    if (event.jsdate) {
      this.startDateHasValue = true;
    } else {
      this.startDateHasValue = false;
    }

    !event.jsdate
      ? this.leaveForm.get('endDate').disable()
      : this.leaveForm.get('endDate').enable();
    const copy = this.getCopyOfOptions();
    copy.disableUntil = checked
      ? {
        year: this.disableUntil.year,
        month: this.disableUntil.month,
        day: this.disableUntil.day
      }
      : { year: 0, month: 0, day: 0 };
    this.myOptions = copy;
    const data = this.leaveForm.value;
    if (event.jsdate) {
      data.startDate = this.datepipe.transform(new Date(event.jsdate), 'dd-MMM-yyyy');
    }
    if (this.leaveForm.value.endDate && this.leaveForm.value.endDate.jsdate) {
      data.endDate = this.datepipe.transform(new Date(this.leaveForm.value.endDate.jsdate), 'dd-MMM-yyyy');
      this.getDaysDurationAPI(data);
    }
    if (this.leaveForm.controls.absenceTypeId.value === '65') {
      let date = '';
      if (event.jsdate) {
        this.showLoader = true;
        date = this.datepipe.transform(new Date(event.jsdate), 'yyyy-MM-dd');
        this.leaveSummaryService.getEntitlementBalance(date, this.selectedUser, this.selectedUserId, this.managerAction).subscribe(
          (response) => {
            this.showLoader = false;
            if (response.returnCode === '0') {
              const totalLeaves = response.leaveBalanceTab[0].leaveBalance;
              this.leaveForm.controls.totalLeaves.setValue(totalLeaves);
            }
          },
          (error) => {
            this.showLoader = false;
          }
        );
      } else {
        this.leaveForm.controls.totalLeaves.setValue('');
      }
    }
  }
  endDateChange(event) {
    if (event.jsdate) {
      this.endDateHasValue = true;
    } else {
      this.endDateHasValue = false;
    }
    this.disableUntil = event.data;
    const data = this.leaveForm.value;

    if (this.leaveForm.value.startDate && this.leaveForm.value.startDate.jsdate) {
      data.startDate = this.datepipe.transform(new Date(this.leaveForm.value.startDate.jsdate), 'dd-MMM-yyyy');
    }
    if (event.jsdate) {
      data.endDate = this.datepipe.transform(new Date(event.jsdate), 'dd-MMM-yyyy');
    }
    if (event.date.year !== 0) {
      this.getDaysDurationAPI(data);
    }
  }
  getHoursDuration(endTime) {
    const data = this.leaveForm.value;
    if (
      this.leaveForm.value.startDate &&
      this.leaveForm.value.startDate.jsdate
    ) {
      data.startDate = this.datepipe.transform(new Date(this.leaveForm.value.startDate.jsdate), 'dd-MMM-yyyy');
    }
    if (this.leaveForm.value.endDate && this.leaveForm.value.endDate.jsdate) {
      data.endDate = this.datepipe.transform(new Date(this.leaveForm.value.endDate.jsdate), 'dd-MMM-yyyy');
    }
    data.startTime = this.leaveForm.value.startTime;
    data.endTime = endTime;
    this.callDaysDurationApi(data);
  }
  callDaysDurationApi(data) {
    data.startDate = this.datepipe.transform(new Date(data.startDate), 'dd-MMM-yyyy');
    data.endDate = this.datepipe.transform(new Date(data.endDate), 'dd-MMM-yyyy');
    this.leaveSummaryService.getLeaveDuration(data, this.managerAction, this.selectedUserId).subscribe(
      response => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.validationMessage = '';
          this.daysDuration = response.duration;
          // this.hoursDuration = response.durationHours;
          this.leaveForm.value.totalDays = '';
          this.leaveForm.controls.totalHours.setValue(response.durationHours);
          this.hoursDuration = response.durationHours;
        } else if (response.returnCode === '1') {
          this.leaveForm.controls.totalHours.setValue(response.durationHours);
          this.hoursDuration = response.durationHours;
          this.leaveForm.controls.totalHours.setValue('');
          this.validationMessage = response.returnMsg;
        }
      },
      error => {
        this.validationMessage = '';
        this.showLoader = false;

      }
    );
  }


  getCopyOfOptions(): INgxMyDpOptions {
    return JSON.parse(JSON.stringify(this.myOptions));
  }
  createAbsenceData(type?, subFlag?) {

    const userDetails = this.common.getUserDetails();

    this.formsubmit = true;

    if (this.leaveForm.valid) {
      // if (userDetails.mgrFlag == 'M' && !this.managerAction) {
      //   if (this.leaveForm.value.replacedVal) {
      //     this.callSubmitApi(type);
      //   }
      // }
      // else {
      this.callSubmitApi(type, subFlag);
      // }

    }
  }
  callSubmitApi(type, subFlag?) {
    const userDetails = this.common.getUserDetails();
    this.showLoader = true;
    const cred = this.leaveForm.value;
    if (
      this.leaveForm.value.startDate &&
      this.leaveForm.value.startDate.jsdate
    ) {
      cred.startDate = this.datepipe.transform(new Date(this.leaveForm.value.startDate.jsdate), 'dd-MMM-yyyy');
    }
    if (this.leaveForm.value.endDate && this.leaveForm.value.endDate.jsdate) {
      cred.endDate = this.datepipe.transform(new Date(this.leaveForm.value.endDate.jsdate), 'dd-MMM-yyyy');
    }
    if (this.editPage == 'true') {
      cred.absenceAttendanceId = JSON.parse(
        localStorage.getItem('absenceDetails')
      ).absenceId;
    } else {
      cred.absenceAttendanceId = '';
    }
    cred.transactionId = this.transactionId;
    cred.approvalStatus = '';
    cred.submitFlag = subFlag;
    // cred.absenceAttendanceId = '';
    cred.absenceCategory = '';
    cred.absenceType = '';
    cred.absenceReason = '';
    cred.absenceReasonId = '';
    cred.startTime = this.leaveForm.value.startTime ? this.leaveForm.value.startTime : '';
    cred.endTime = this.leaveForm.value.endTime ? this.leaveForm.value.endTime : '';
    cred.absenceDuration = this.leaveForm.value.totalHours ? this.leaveForm.value.totalDays : '';
    cred.durationHours = this.leaveForm.value.totalHours ? this.leaveForm.value.totalHours : '';
    cred.userComments = this.leaveForm.value.userComments ? this.leaveForm.value.userComments : '';
    (cred.replacedBy = ''),
      (cred.replacementId = this.selectedReplacedBy.personId),
      (cred.absenceStatus = '');
    if (type === 'save') {
      cred.action = 'SAVE';
    } else {
      cred.action = 'CREATE';
    }
    // cred.userName = "CBAKER";
    cred.userName = this.managerAction ? this.selectedUser : userDetails.userName;
    cred.managerName = userDetails.userName;
    cred.attachmentTab = [];
    // cred.leaveType = this.leaveForm.value.absenceTypeId;
    if (this.uploadedFile.length) {
      this.uploadedFile.forEach(file => {
        const data = {
          title: file.title ? file.title : '',
          documentId: file.documentId ? file.documentId : '',
          deleteFlag: '',
          description: file.comments ? file.comments : '',
          attachementName: file.attachmentName,
          fileData: file.fileData,
          attachementType: file.attachmentType
        };
        cred.attachmentTab.push(data);
      });
    }

    this.createAbsenceSummary.createAbsence(cred, this.managerAction).subscribe(
      response => {
        if (response.returnCode === '0') {
          if (response.approverTab && response.approverTab.length) {
            this.showLoader = false;
            this.approverList = response.approverTab;
            this.transactionId = response.transactionId;
          } else {
            this.transactionId = '';
            this.approverList = [];
            this.leaveForm.reset();
            this.validationMessage = '';
            this.showLoader = false;
            const toast = ToastSuccess;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
            this.leaveForm.markAsPristine();
            if (!this.managerAction) {
              this.router.navigate(['leave-management/absence']);
            } else {
              this.router.navigate(['manager-self-service/leave-details']);
            }
          }
        } else if (response.returnCode === '7') {
          this.approverList = [];
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.transactionId = '';
          this.common.showToast(toast);
          this.showLoader = false;
        } else if (response.returnCode === '1') {
          this.approverList = [];
          this.transactionId = '';
          this.validationMessage = response.returnMsg;
          this.showLoader = false;
        } else if (response.returnCode === '-1') {
          this.approverList = [];
          this.transactionId = '';
          this.validationMessage = response.returnMsg;
          this.showLoader = false;
        }
        this.showLoader = false;
      },
      () => {
        this.validationMessage = '';
        this.showLoader = false;
      }
    );
  }
  leaveDurationSubmit(type, subFlag?) {
    if (this.attachmentRequired && !this.uploadedFile.length) {
      this.attachmentValidation =
        '* Attachment is mandatory';
    } else {
      this.attachmentValidation = '';
      this.createAbsenceData(type, subFlag);
    }
  }
  endDate(event) {
    if (event) {
      this.hasValueEndDAte = true;
    } else {
      this.hasValueEndDAte = false;
    }
  }

  formClear() {
    this.leaveForm.get('endDate').enable();
    this.leaveForm.get('startDate').setValue(null);
    this.leaveForm.get('endDate').setValue(null);
    this.leaveForm.get('startTime').setValue(null);
    this.leaveForm.get('endTime').setValue(null);
    this.leaveForm.get('totalHours').setValue(null);
    this.leaveForm.get('totalDays').setValue(null);
    this.leaveForm.get('replacedVal').setValue(null);
    this.leaveForm.get('userComments').setValue(null);
    this.leaveForm.get('endDate').disable();
    this.startDateHasValue = false;
    this.endDateHasValue = false;

    this.uploadedFile = [];
  }
  setDateTimeFlag(val) {
    this.validationMessage = '';
    this.attachmentValidation = '';
    this.leaveForm.controls.totalLeaves.setValue('');
    this.formsubmit = false;
    for (let i = 0; i < this.leaveTypeMeta.length; i++) {
      if (this.leaveTypeMeta[i].absenceTypeId === parseInt(val)) {
        if (
          this.leaveTypeMeta[i].absenceTypeId === 1061 ||
          this.leaveTypeMeta[i].absenceTypeId === 61 ||
          this.leaveTypeMeta[i].absenceTypeId === 71 ||
          this.leaveTypeMeta[i].absenceTypeId === 67
        ) {
          this.attachmentRequired = true;
        } else {
          this.attachmentRequired = false;
        }

        if (this.leaveTypeMeta[i].dateTimeFlag === 'Y') {
          this.enableTimeFields = true;
          break;
        } else {
          this.enableTimeFields = false;
        }
      } else {
        this.enableTimeFields = false;
      }
    }
    this.formClear();
  }

  onStartTimeChange(val) {
    !val
      ? this.leaveForm.get('endTime').disable()
      : this.leaveForm.get('endTime').enable();

    if (this.leaveForm.value.endTime) {
      this.getHoursDuration(this.leaveForm.value.endTime);
    }
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  cancelSelectedFile(event) {
    this.showAddAttachment = false;
  }

  attachDismiss(attach) {
    this.showViewAttachmentSec = attach;
  }

  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  fileDismiss() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.uploadedFile.push(file);
    this.attachmentValidation = '';
  }
  deleteFile(index) {
    this.uploadedFile.splice(index, 1);
  }

  viewIndexBasedAttachment(valArr) {
    this.showViewAttachmentSec = false;
    if (valArr != null) {
      this.base64TOView = valArr.fileData;
      this.showViewAttachmentSec = true;
    }
  }
  /* display start time picker */
  showStartTimePicker() {
    this.showPickerStart = !this.showPickerStart;
    this.showPickerEnd = false;
    let selectedTime; // to display time in the picker
    selectedTime = this.leaveForm.get('startTime').value || '00:00';
    this.timeData = {
      time: selectedTime,
      target: 'startTime'
    };
  }
  /* display end time picker */
  showEndTimePicker() {
    this.showPickerEnd = !this.showPickerEnd;
    this.showPickerStart = false;
    let selectedTime; // to display time in the picker
    selectedTime = this.leaveForm.get('endTime').value || '00:00';
    this.timeData = {
      time: selectedTime,
      target: 'endTime'
    };
  }
  /* event triggered when time picker is closed */
  timePickerTriggered(event) {
    this.showPickerStart = false;
    this.showPickerEnd = false;
    if (event.target == 'startTime') {
      if (event.event == 'ok') {
        this.leaveForm.get('startTime').setValue(event.time);
        this.onStartTimeChange(this.leaveForm.get('startTime').value);
      } else {
        this.leaveForm.get('startTime').setValue(null);
      }
    } else if (event.target == 'endTime') {
      if (event.event == 'ok') {
        this.leaveForm.get('endTime').setValue(event.time);
        this.getHoursDuration(this.leaveForm.get('endTime').value);
      } else {
        this.leaveForm.get('endTime').setValue(null);
      }
    }
  }
  /**
   * @desc method to check if router needed to be deactivated if any input is there in form
   */
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if (this.leaveForm && this.leaveForm.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }
  /**
   * @desc popup cancel for navigating from page
   */
  cancelBack() {
    this.backConfirm = false;
    this.confirm$.next(false);
  }
  /**
   * @desc  popup confirm for navigating from page
   */
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  closeLeave() {
    this.location.back();
  }
  changeReplacedBy() {
    this.showReplacedByList = true;
  }
  chooseReplacedBy(replacedBy) {
    this.showReplacedByList = false;
    this.selectedReplacedBy = replacedBy;
    this.leaveForm.controls.replacedVal.setValue(replacedBy.personName);
  }
}
