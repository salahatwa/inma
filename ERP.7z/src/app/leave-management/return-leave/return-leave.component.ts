import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit } from '@angular/core';
import { ReturnFromLeaveService } from '../data-service/return-from-leave.service';
import { ToastFailed } from 'src/app/shared/constants/globalConstants';

@Component({
  selector: 'app-return-leave',
  templateUrl: './return-leave.component.html',
  styleUrls: ['./return-leave.component.scss']
})
export class ReturnLeaveComponent implements OnInit {
  attachmentDetail: boolean;
  reqDetails = [];
  noSummary = false;
  showLoader = false;
  selectedUser = '';
  managerAction = false;
  constructor(
    private readonly returnService: ReturnFromLeaveService,
    private readonly common: CommonService,
    private readonly router: Router,
  ) { }
  ngOnInit() {
    this.selectedUser = this.common.getUserNameForMngrAction();
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.returnFromLeaveDetails();
  }
  returnFromLeaveDetails() {
    this.showLoader = true;
    this.returnService.getReturnFromLeavedetails(this.selectedUser, this.managerAction).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.noSummary = false;
          this.reqDetails = response.sitEitSummaryTab;
        }
        if (response.returnCode === '9') {
          this.noSummary = true;
        }
      },
      () => {
        this.noSummary = false;
        this.showLoader = false;
        this.common.showToast(ToastFailed);
      }
    );
  }
  addRequest() {
      this.router.navigate(['/manager-self-service/add-return-from-leave']);
  }
}
