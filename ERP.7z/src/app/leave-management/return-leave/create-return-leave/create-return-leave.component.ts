import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable, Subject } from 'rxjs';
import { ActivatedRoute, Router, CanDeactivate } from '@angular/router';
import { INgxMyDpOptions } from 'ngx-mydatepicker';

import { RequestMetaService } from '../../../employee-request/data-services/request-meta.service';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SubmitRequestService } from '../../../employee-request/data-services/submit-request.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { DatePipe, Location } from '@angular/common';

@Component({
  providers: [DatePipe],
  selector: 'app-create-return-leave',
  templateUrl: './create-return-leave.component.html',
  styleUrls: ['./create-return-leave.component.scss']
})
export class CreateReturnLeaveComponent implements OnInit, OnDestroy {
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };
  myOptions2: INgxMyDpOptions = {
    dateFormat: 'dd-mm-yyyy',
    firstDayOfWeek: 'su'
  };
  selectedUser = '';
  language = '';
  reqName = '';
  attachmetReq = '';
  managerAction = false;
  formattedDate: string;
  formSbmitted = true;
  backConfirm = false;
  showAddAttachment = false;
  confirm$: Subject<boolean> = new Subject<boolean>();
  routeSubscription$: Subscription;
  metaDataSubscription$: Subscription;
  saveRequestSubscription$: Subscription;
  dependentSubscription$: Subscription = new Subscription;
  private approverSubscription$: Subscription;
  requestForm: FormGroup;
  showLoader = false;
  validationMessage = '';
  errorMsg = '';
  approverList = [];
  transactionId = '';
  uploadedFile = [];
  formDetails: { [k: string]: any } = {};
  metaData: any;
  currentIndex: number;
  requestType: string;
  requestCode: string;
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly router: Router,
    private readonly metaService: RequestMetaService,
    private readonly reqSubmitService: SubmitRequestService,
    private readonly common: CommonService,
    private readonly location: Location,
    private readonly datepipe: DatePipe
  ) { }

  ngOnInit() {
    this.requestType = 'SIT';
    this.requestCode = 'INM_LEAVE_RETURN';
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
    this.selectedUser = this.common.getUserNameForMngrAction();
    this.getSitEitMetaData();
    this.language = this.common.getLanguage();
  }
  /**
   * @desc this method is used to get the data for populating the form fields in create employee request
   */
  getSitEitMetaData() {
    this.showLoader = true;
    this.metaDataSubscription$ = this.metaService
      .getRequestMetaData(this.requestType, this.requestCode, this.selectedUser, this.managerAction)
      .subscribe(
        response => {
          this.showLoader = false;
          if (response.returnCode === '0') {
            this.attachmetReq = response.attachementFlag;
            this.reqName = response.requestName;
            this.metaData = response.sitEitMetaDataTab;
            this.metaData.forEach(element => {
              element.hasValue = false;
              if (element.is_mandatory === 'N') {
                this.formDetails[element.application_column_name] = '';
              } else {
                this.formDetails[element.application_column_name] = [
                  '',
                  Validators.required
                ];
              }
            });
            // this.formDetails['userComments'] = '';
            this.requestForm = this.formBuilder.group(this.formDetails);
            this.metaData.forEach(element => {
              if (element.defaultValue) {
                this.requestForm.controls[element.application_column_name].setValue(element.defaultValue);
                element.hasValue = true;
              }
            });
          }
        },
        () => {
          this.showLoader = false;
        }
      );
  }
  /**
   * @desc method to dynamically handle back in breadcrumbs
   */
  goBack() {
    this.location.back();
  }
  /**
   * @decs method to get metadata of dependent fields of the clicked or changed field
   * @param index index of the clicked field metadata
   * @param event event to be passed in case of date picker as change is not detected in formgroup
   */
  checkForNextDependent(index: number, event?) {
    let currentDate;
    this.currentIndex = index;
    /**
     * event is checked in the case of date picker to get selected date
     */
    if (event) {
      if (event.date.year === 0) {
        currentDate = '';
      } else {
        if (event.date.month.toString().length === 1) {
          event.date.month = `0${event.date.month}`;
        }
        if (event.date.day.toString().length === 1) {
          event.date.day = `0${event.date.day}`;
        }
        currentDate = `${event.date.year}-${event.date.month}-${
          event.date.day
          } 00:00:00`;
      }
    }
    /**
     * to add class on datepicker input based on value
     */
    if (this.metaData[index].column_type === 'DATE' && event.date.year) {
      this.metaData[index].hasValue = true;
    } else if (
      this.metaData[index].column_type === 'DATE' &&
      !event.date.year
    ) {
      this.metaData[index].hasValue = false;
    }
    /**
     * loop over the fields from selected field to check dependent fields
     */
    if (this.metaData) {
      for (let i = index + 1; i < this.metaData.length; i++) {
        if (this.metaData[i].dependent_value_set_exists === 'Y') {
          const data = this.getPreviousFieldData(i, currentDate);
          this.dependentSubscription$.add(this.metaService.getDependentFlexValueSet(data, this.selectedUser, this.managerAction).subscribe(
            response => {
              if (response.returnCode === '0') {
                if (this.metaData[i].column_type === 'DROPDOWN') {
                  this.metaData[i].flexValuesTab = response.flexValuesTab;
                } else if (response.defaultValue !== null && this.metaData[i].column_type === 'DATE') {
                  this.metaData[i].defaultValue = response.defaultValue;
                  this.requestForm.controls[this.metaData[i].application_column_name]
                    .setValue({ jsdate: new Date(this.common.formatDate(response.defaultValue)) });
                  this.metaData[i].hasValue = true;
                } else {
                  this.metaData[i].defaultValue = response.defaultValue;
                  this.requestForm.controls[this.metaData[i].application_column_name].setValue(response.defaultValue);
                  this.metaData[i].hasValue = true;
                }
              }
            },
            () => {
            }
          ));
        }
      }
    }
  }
  /**
   * @desc method to get the all field values from the passed index of metadata
   * @param index the index upto which the values are neededd
   * @param selectedDate formated date passed in the case of selected field is date
   */
  getPreviousFieldData(index, selectedDate) {
    const data = {
      userName: '',
      language: '',
      requestCode: this.requestCode,
      requestType: this.requestType,
      displayLabel: this.metaData[index].display_label,
      displayLabelCode: this.metaData[index].display_label_code,
      dependentFlexTab: []
    };
    /**
    * get the input values upto passed index but for date set input value as formatted date
    */
    for (let i = 0; i < index; i++) {
      let inputValue = '';
      if (
        this.requestForm.controls[this.metaData[i].application_column_name]
          .value &&
        this.requestForm.controls[this.metaData[i].application_column_name]
          .value.jsdate
      ) {
        const value = this.requestForm.controls[
          this.metaData[i].application_column_name
        ].value;
        if (value.date.month.toString().length === 1) {
          value.date.month = `0${value.date.month}`;
        }
        if (value.date.day.toString().length === 1) {
          value.date.day = `0${value.date.day}`;
        }
        const formattedDate = `${value.date.year}-${value.date.month}-${
          value.date.day
          } 00:00:00`;
        inputValue = formattedDate;
      } else {
        inputValue = this.requestForm.controls[
          this.metaData[i].application_column_name
        ].value;
      }
      if (i === this.currentIndex && this.metaData[i].column_type === 'DATE') {
        inputValue = selectedDate;
      }
      const flexTab = {
        display_label: this.metaData[i].display_label,
        display_label_code: this.metaData[i].display_label_code,
        input_value: inputValue
      };
      data.dependentFlexTab.push(flexTab);
    }
    return data;
  }
  /**
   * desc method to submit the request based on SIT and EIT
   * @param requestForm the form with all input values
   */
  saveRequest(requestForm: NgForm) {
    if (this.requestForm.valid) {
      this.formSbmitted = true;
      this.showLoader = true;
      let formattedDate = '';
      const formArray = requestForm.value;
      for (const key of Object.keys(formArray)) {
        if (typeof formArray[key] === 'object') {
          if (formArray[key] && formArray[key].date) {
            if (formArray[key].date.month.toString().length === 1) {
              formArray[key].date.month = `0${formArray[key].date.month}`;
            }
            if (formArray[key].date.day.toString().length === 1) {
              formArray[key].date.day = `0${formArray[key].date.day}`;
            }
            formattedDate = `${formArray[key].date.year}-${
              formArray[key].date.month
              }-${formArray[key].date.day} 00:00:00`;
            requestForm.value[key] = formattedDate;
          }
        }
      }
      const data = {
        flexStructure: this.requestCode,
        mobSITTab: [],
        mobSITAttachementTab: [],
        userComments: ''
      };
      if (this.uploadedFile.length) {
        this.uploadedFile.forEach((file) => {
          const attachment = {
            title: file.title,
            documentId: '',
            deleteFlag: '',
            description: file.description,
            attachementName: file.attachmentName,
            fileData: file.fileData,
            attachementType: file.attachmentType
          };
          data.mobSITAttachementTab.push(attachment);
        });
        data.mobSITTab.push(requestForm.value);
        this.sitEitApiCall(data);
      } else if (this.attachmetReq === 'Y') {
        this.formSbmitted = false;
        this.showLoader = false;
        this.errorMsg = 'Attachment is mandatory for this request';
      } else {
        data.mobSITTab.push(requestForm.value);
        this.sitEitApiCall(data);
      }
    } else {
      this.formSbmitted = false;
      this.errorMsg = 'Please enter all required fields';
    }
  }
  /**
   * @desc api call for submitting sit and eit
   * @param data data to be submitted
   */
  sitEitApiCall(data) {
    this.saveRequestSubscription$ = this.reqSubmitService.submitEitRequest(data, 'sit', this.managerAction, this.selectedUser).subscribe(
      (response) => {
        this.validationMessage = '';
        this.showLoader = false;
        if (response.returnCode === '0') {
          if (this.managerAction) {
            this.requestForm.reset();
            const toast = {
              show: true,
              status: 'success',
              message: response.returnMsg
            };
            if (!this.managerAction) {
              this.router.navigate([
                '/leave-management/return'
              ]);
            } else {
              this.location.back();
            }
            this.common.showToast(toast);
          } else {
          this.approverList = response.approverList;
          this.transactionId = response.transactionId;
          if (!this.approverList.length) {
            this.submitRquest('Y');
          }
        }
      }
        if (response.returnCode === '1') {
          this.validationMessage = response.returnMsg;
        }
      },
      (error) => {
        this.validationMessage = '';
        this.showLoader = false;
      }
    );
  }
  submitRquest(action) {
    this.showLoader = true;
    const body = {
      'requestType': this.requestType,
      'submitFlag': action,
      'transactionId': this.transactionId,
    };
    this.approverSubscription$ = this.reqSubmitService.submitFinalRequest(body).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.requestForm.reset();
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          if (!this.managerAction) {
            this.router.navigate([
              '/employee-request/details',
              this.requestCode,
              this.requestType
            ]);
          } else {
            this.location.back();
          }
          this.common.showToast(toast);
        } else {
          this.approverList = [];
        }
      },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  confirmBack() {
    this.backConfirm = false;
    this.confirm$.next(true);
  }
  addAttachment() {
    this.showAddAttachment = true;
  }
  fileSelected(file) {
    this.showAddAttachment = false;
    this.uploadedFile.push(file);
  }
  deleteFile(index) {
    this.uploadedFile.splice(index, 1);
  }
  cancelAttachment(event) {
    this.showAddAttachment = event;
  }
  canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
    if (this.requestForm && this.requestForm.dirty) {
      this.backConfirm = true;
      return this.confirm$;
    } else {
      return true;
    }
  }
  ngOnDestroy() {
    this.metaDataSubscription$.unsubscribe();
    this.dependentSubscription$.unsubscribe();
    if (this.saveRequestSubscription$) {
      this.saveRequestSubscription$.unsubscribe();
    }
    if (this.approverSubscription$) {
      this.approverSubscription$.unsubscribe();
    }
    this.confirm$.unsubscribe();
  }
}
