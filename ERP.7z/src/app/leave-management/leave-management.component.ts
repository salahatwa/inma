import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-leave-management',
  templateUrl: './leave-management.component.html',
  styleUrls: ['./leave-management.component.scss']
})
export class LeaveManagementComponent implements OnInit {
  public showCreateAbsence = true;
  public showReturFromLeave = false;
  constructor(
    public readonly router: Router
    ) { }

  ngOnInit() {
    // this.router.navigateByUrl('leave-management/absence');
  }

}
