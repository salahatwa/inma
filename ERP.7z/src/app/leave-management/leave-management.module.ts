import { MyDatePickerModule } from 'mydatepicker';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeaveManagementComponent } from './leave-management.component';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { LeaveManagementRoutingModule } from './leave-management-routing.module';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        MyDatePickerModule,
        RouterModule,
        LeaveManagementRoutingModule,
        NgxMyDatePickerModule.forRoot()
    ],
    declarations: [
        LeaveManagementComponent,
    ]
})
export class LeaveManagementModule { }
