import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';

import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReturnFromLeaveService {

  constructor(
    private readonly common: CommonService,
    private readonly url: UrlGeneratorService,
    private readonly http: HttpClient
  ) { }
  getReturnFromLeavedetails(user?, mngrAction?): Observable<any> {
    const userDetails = this.common.getUserDetails();
    const data = {
      userName: mngrAction ? user : userDetails.userName,
      loggedInUser: userDetails.userName,
      language: '',
      analysisCriteriaId: '',
      extraInfoId: '',
      requestCode: 'INM_LEAVE_RETURN',
      requestType: 'SIT'
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    const url = this.url.getSitEitDetails();
    return this.http.post<any>(url, data).pipe(
      catchError((error) => {
        return throwError(error);
      })
    );
  }
}
