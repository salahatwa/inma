import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { tap, catchError } from 'rxjs/operators';
import { throwError, Observable } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';

@Injectable({
  providedIn: 'root'
})
export class LeaveSummaryService {

  constructor(
    private readonly common: CommonService,
    private readonly url: UrlGeneratorService,
    private readonly http: HttpClient
  ) { }

  getLeaveType(mngrAction?, userId?): Observable<any> {
    const url = this.url.getLeaveTypeUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      'personId': mngrAction ? userId : userDetails.personId,
      'loggedInId': userDetails.personId,
      'language': 'AMERICAN'
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  getReplaced(mngrAction?, userId?): Observable<any> {
    const url = this.url.getreplacedByUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      'personId': mngrAction ? userId : userDetails.personId,
      'loggedInId': userDetails.personId,
      'language': 'AMERICAN'
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  getLeaveDuration(reqData, mngrAction?, userId?): Observable<any> {
    const url = this.url.getLeaveDurationUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      'personId': mngrAction ? userId : userDetails.personId,
      'loggedInId': userDetails.personId,
      'absenceTypeId': reqData.absenceTypeId ? +reqData.absenceTypeId : 0,
      'startDate': reqData.startDate,
      'endDate': reqData.endDate,
      'startTime': reqData.startTime,
      'endTime': reqData.endTime ? reqData.endTime : ''
    };
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  getEntitlementBalance(effectiveDate: string, user?: string, userId?: number, mngrAction?: boolean): Observable<any> {
    const url = this.url.getEntitlementBalanceUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      'userName': mngrAction ?  user : userDetails.userName,
      'loggedInUser':  userDetails.userName,
      'personId': mngrAction ? userId : userDetails.personId,
      'effectiveDate': effectiveDate
    };
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }

  getAbsenceDetails(user?: string, mngrAction?: boolean): Observable<any> {
    const url = this.url.getAbsenceDetailsUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      'userName' : mngrAction ? user : userDetails.userName,
      'loggedInUser': userDetails.userName,
      'deviceId': '',
      'approvalStatus' : '',
      'absenceAttendanceId' : '',
      'language': 'AMERICAN'
    };
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }

  getaddAttachment(mediaId): Observable<any> {
    const url = this.url.getaddAttachmentUrl();
    const userDetails = this.common.getUserDetails();
    const data = {
      'tempId' : +userDetails.personId,
      'mediaId' : mediaId
    };
    return this.http.post<any>(url, data);
  }

}


