
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  // { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  // // { path: '', component: LoginComponent },
  // {
  //   // path: '', component: HomeComponent, canActivate: [AuthGuard],
  //   children: [
      // { path: 'dashboard', component: DashboardComponent, data: { title: 'Dashboard' } },
      /*{
        path: 'myprofile', component: MyprofileComponent, data: { title: 'My Profile' },
        children: [
          { path: '', redirectTo: 'personal-info', pathMatch: 'full' },
          { path: 'personal-info', component: PersonalInfoComponent },
          { path: 'employment', component: EmploymentComponent },
          { path: 'salary', component: SalaryComponent },
          { path: 'payslip', component: PayslipComponent },
          { path: 'passport', component: PassportComponent },
          { path: 'emergency-contact', component: EmergencyContactComponent }
        ]
      },*/
      // { path: 'find-tam', component: FindTamComponent, data: { title: 'Time and Attendance' } },
      // {
      //   path: 'leave-management', component: LeaveManagementComponent, data: { title: 'Leave Management' },
      //   children: [
      //     { path: '', redirectTo: 'absence', pathMatch: 'full' },
      //     { path: 'absence', component: AbsenceSummaryComponent },
      //     { path: 'return', component: ReturnLeaveComponent }
      //   ]
      // },
      /*{
          path: 'learning', component: LearningComponent, data: { title: 'Learning' },
          children: [
              { path: '', redirectTo: 'learning-home', pathMatch: 'full' },
              { path: 'learning-home', component: LearningHomeComponent },
              { path: 'individial-development', component: IndividialDevelopmentComponent },
              { path: 'course-request', component: CourseRequestComponent },
          ]
      },
      { path: 'performance', component: PerformanceComponent, data: { title: 'Performance Management' } },
      { path: 'performance/detail', component: PerformanceDetailComponent, data: { title: 'Performance Management' } },

      // {
      //   path: 'myprofile/personal-info/add-dependent', component: AddDependentComponent, data: { title: 'My Profile' },
      //   canDeactivate: [CanDeactivateGuard]
      // },
      // { path: 'myprofile/add-emergency-contact', component: AddEmergencyContactComponent, data: { title: 'My Profile' } },
      // {
      //   path: 'myprofile/personal-info/edit-personal-info', component: EditPersonalInfoComponent,
      //   data: { title: 'My Profile' }, canDeactivate: [CanDeactivateGuard]
      // },
      /*{
        path: 'leave-management/absence-summary/create-absence', component: CreateAbsenceComponent,
        data: { title: 'Leave Management' }, canDeactivate: [CanDeactivateGuard]
      },
      {
        path: 'leave-management/return-from-leave-request/create-return-leave', component: CreateReturnLeaveComponent,
        data: { title: 'Leave Management' }, canDeactivate: [CanDeactivateGuard]
      },*/
      /*{ path: 'employee-request', component: EmployeeRequestComponent, data: { title: 'Employee Requests' } },
      { path: 'employee-request/add-credit-card', component: AddCreditCardComponent, data: { title: 'Add Credit Card' } },
      { path: 'employee-request/credit-card', component: CreditCardComponent, data: { title: 'Credit Card' } },
      { path: 'employee-request/details/:code/:type', component: RequestDetailsComponent, data: { title: 'Employee Requests' } },
      {
        path: 'employee-request/add/:code/:type',
        component: AddRequestComponent, data: { title: 'Employee Requests' },
        canDeactivate: [CanDeactivateGuard]
      },*/
      // {
      //   path: 'myprofile/add-passport', component: AddPassportComponent,
      //   canDeactivate: [CanDeactivateGuard], data: { title: 'My Profile' }
      // },
      // {
      //   path: 'myprofile/add-emergency-contact', component: AddEmergencyContactComponent,
      //   canDeactivate: [CanDeactivateGuard], data: { title: 'My Profile' }
      // },
      // { path: 'dashboard/worklist-detail', component: WorklistDetailComponent, data: { title: 'WorkList' } },
      // { path: 'dashboard/worklist-tam-detail', component: WorklistTamDetailComponent, data: { title: 'WorkList' } },
      /*{ path: 'courses', component: CoursesComponent, data: { title: 'Learning' } },
      { path: 'courses-category', component: CourseCategoryComponent, data: { title: 'Learning' } },
      { path: 'courses-details', component: CourseDetailComponent, data: { title: 'Learning' } },
      { path: 'enroll', component: EnrollComponent, data: { title: 'Learning' } },

     /* { path: 'add-individual-development', component: AddIndividualDevelopmentComponent, data: { title: 'Learning' } },
      { path: 'add-course-request', component: AddCourseRequestComponent, data: { title: 'Learning' } },
      { path: 'create-absence', component: CreateAbsenceComponent, data: { title: 'Leave Management' } },
      { path: 'manager-self-service', component: ManagerSelfServiceComponent, data: { title: 'Manager Self Service' } },
      { path: 'manager-self-service/set-objective', component: SetObjectiveComponent, data: { title: 'Set Objective' } },
      { path: 'manager-self-service/add-set-objective', component: AddSetObjectiveComponent, data: { title: 'Set Objective' } },
      { path: 'manager-self-service/track-objective', component: TrackObjectiveComponent, data: { title: 'Track Objective' } },
      { path: 'manager-self-service/appraisal', component: AppraisalComponent, data: { title: 'Appraisal' } },
      { path: 'manager-self-service/training-assessment', component: TrainingAssessmentComponent, data: { title: 'Training Assessment' } },
      { path: 'manager-self-service/reportees', component: ReporteesComponent, data: { title: 'Reportees' } },
      { path: 'set-objective', component: SetObjectiveComponent, data: { title: 'Set Objective' } },
      { path: 'add-set-objective', component: AddSetObjectiveComponent, data: { title: 'Set Objective' } },
      { path: 'track-objective', component: TrackObjectiveComponent, data: { title: 'Track Objective' } },
      { path: 'appraisal', component: AppraisalComponent, data: { title: 'Appraisal' } },
      { path: 'training-assessment', component: TrainingAssessmentComponent, data: { title: 'Training Assessment' } },
      { path: 'reportees', component: ReporteesComponent, data: { title: 'Reportees' } },
      { path: 'quick-links', component: QuickLinksComponent, data: { title: 'Quick Links ' } },
      { path: '**', component: ComingSoonComponent, data: { title: 'Coming Soon' } }
    ]
  }*/
];

export const routing = RouterModule.forRoot(routes);
