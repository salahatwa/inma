import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PerformanceComponent } from './performance.component';
import { PerformanceDetailComponent } from './performance-detail/performance-detail.component';
import { PerformanceSubmitFeedbackComponent } from './performance-submit-feedback/performance-submit-feedback.component';

const routes: Routes = [
  { path: '', component: PerformanceComponent, data: { title: 'Performance Management' } },
  { path: 'detail/:id/:name', component: PerformanceDetailComponent, data: { title: 'Performance Management' } },
  { path: 'submitfeedback/:id/:name', component: PerformanceSubmitFeedbackComponent, data: {title: 'Performance Management'}}
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PerformanceRoutingModule { }
