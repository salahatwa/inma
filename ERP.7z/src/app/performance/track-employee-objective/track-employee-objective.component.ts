import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { INgxMyDpOptions } from 'ngx-mydatepicker';
import { TransferObjectiveService } from 'src/app/manager-self-service/data-services/transfer-objective.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { Location, DatePipe } from '@angular/common';

@Component({
  providers: [DatePipe],
  selector: 'app-track-employee-objective',
  templateUrl: './track-employee-objective.component.html',
  styleUrls: ['./track-employee-objective.component.scss']
})
export class TrackEmployeeObjectiveComponent implements OnInit {
  trackObjectiveForm: FormGroup;
  objectiveListingTab: any = [];
  details: any = [];
  showLoader;
  comments: any = [];
  myOptions: INgxMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    firstDayOfWeek: 'su'
  };

  panelExpand = false;
  constructor(
    private objectiveService: TransferObjectiveService,
    private readonly location: Location,
    private common: CommonService,
    private readonly datePipe: DatePipe
  ) {

  }

  ngOnInit() {
    this.getObjectiveListing();
  }
  panelExpandClick(index) {
    this.objectiveListingTab[index].isShow = !this.objectiveListingTab[index].isShow;
  }
  /**
   * function for fetching all objectives
   */
  getObjectiveListing() {
    this.showLoader = true;
    this.objectiveService.getObjectiveListingAPI(true).subscribe(resposnse => {
      this.showLoader = false;
      if (resposnse.returnCode === '0' || resposnse.returnCode === '9') {
        this.details = resposnse.mobListDetailsTab;
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.objectiveListingTab.forEach(element => {
          if (element.achivementDate && element.achivementDate != null) {
            element.achivementDate = { jsdate: new Date(element.achivementDate) };
          }
          element.prevComments = element.comments;
        });
      } else {
        this.objectiveListingTab = resposnse.objectiveListingTab;
        this.details = resposnse.mobListDetailsTab;
      }
    }, error => {
      this.showLoader = false;
    });
  }
  /**
   * Function for save track objectives
   */
  saveTrackObjective() {
    this.showLoader = true;
    this.objectiveListingTab.forEach(element => {
      if (element.achivementDate && element.achivementDate != null && element.achivementDate.jsdate) {
        element.achivementDate = this.datePipe.transform(new Date(element.achivementDate.jsdate), 'yyyy-MM-dd');
      }
    });
    const body = {
      objectiveTab: this.objectiveListingTab
    };
    this.objectiveService.submitTrackObjective(body, true).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.showLoader = false;
          const toast = {
            show: true,
            status: 'success',
            message: 'The transaction has been sucessfully submitted'
          };
          this.common.showToast(toast);
          this.comments = [];
          this.getObjectiveListing();
        }  else if (response.returnCode === '1') {
          this.showLoader = false;
          const toast = {
            show: true,
            status: 'failed',
            message: response.returnMsg
          };
          this.common.showToast(toast);
        } else {
          this.showLoader = false;
        }
      },
      () => {
        this.showLoader = false;
      }
    );
  }
}
