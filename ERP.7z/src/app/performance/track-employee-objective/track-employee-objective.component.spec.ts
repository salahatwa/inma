import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackEmployeeObjectiveComponent } from './track-employee-objective.component';

describe('TrackEmployeeObjectiveComponent', () => {
  let component: TrackEmployeeObjectiveComponent;
  let fixture: ComponentFixture<TrackEmployeeObjectiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackEmployeeObjectiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackEmployeeObjectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
