import { Location } from '@angular/common';
import { CompleteObjectiveService } from './../data-services/complete-objective.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { PerformanceRatingDetailsService } from './../data-services/performance-rating-details.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-performance-detail',
  templateUrl: './performance-detail.component.html',
  styleUrls: ['./performance-detail.component.scss']
})
export class PerformanceDetailComponent implements OnInit {
  competencyFlag = false;
  objectiveFlag = false;
  userName = '';
  appraisalId = '';
  planName = '';
  objectiveComment = '';
  competencyComment = '';
  performObjectivesTab: any = [];
  performRatingTab: any = [];
  details: any = [];
  detailsInAppraisal: any = [];
  comments = '';
  objScore = '';
  compComment = '';
  showLoader = false;
  returnMsg = '';
  planTask: any = '';
  feedbackComments = '';
  notificationMessage = '';
  feedbackFlag: any = null;
  selectedEmployeeName = '';
  endDateFlag = false;

  constructor(private route: ActivatedRoute, public performanceRating: PerformanceRatingDetailsService,
    private common: CommonService, private completeObjective: CompleteObjectiveService,
    private location: Location) { }

  ngOnInit() {
    this.competencyFlag = true;
    this.userName = this.common.getUserDetails().userName;
    this.planTask = this.performanceRating.planTask;
    this.route.params.subscribe(
      (params: Params) => {
        this.appraisalId = (params['id'] && params['id'] !== '0') ? params['id'] : '';
        this.planName = params['name'];
        this.getPerformanceRating(this.appraisalId);
      }
    );
    this.selectedEmployeeName = this.common.getFullName(); // get selected employee name from Manager self service
  }

  showCompetencies() {
    this.competencyFlag = true;
    this.objectiveFlag = false;
  }

  showObjectives() {
    this.competencyFlag = false;
    this.objectiveFlag = true;
  }
/**
 * Fuction for get perforance rating
 * @param id
 */
  getPerformanceRating(id) {
    this.showLoader = true;
    // tslint:disable-next-line: max-line-length
    this.performanceRating.getPerformanceRatingAndObjectiveDetails(id, this.performanceRating.planId, this.performanceRating.managerAction).subscribe(
      response => {
/*         if (response.returnCode === '0') { */
          this.performObjectivesTab = response.performObjectivesTab;
          this.performRatingTab = response.performRatingTab;
          this.details = response.mobListDetailsTab;
          this.detailsInAppraisal = response.headerTab;
          this.returnMsg = 'No Data Found';
          const value = response.feedbackFlag.split('###$$$');
          this.feedbackFlag = value[0];
          localStorage.setItem('overallRatings', value[1] ? value[1] : '');
          this.compComment = response.compComment;
          const ratingAndComment = response.objComment !== null ? response.objComment.split('###$$$') : ['' , ''];
          this.objectiveComment = ratingAndComment[0];
          this.objScore = ratingAndComment[1] ? ratingAndComment[1] : '';
/*         } else {
          this.performObjectivesTab = [];
          this.performRatingTab = [];
        } */
        this.showLoader = false;
      },
      error => {
        this.showLoader = false;
      }
    );
  }
/**
 * Function for submit employee objectives
 */
  submitEmployeeObjectives() {
    const data: any = {};
    data.comments = this.comments;
    data.scoreCardId = this.performanceRating.planId;
    this.showLoader = true;
    this.completeObjective.callCompleteObjective(data).subscribe(
      response => {
        const toast = {
          show: true,
          status: 'success',
          message: 'The transaction has been sucessfully submitted'
        };
        this.common.showToast(toast);
        this.showLoader = false;
        this.location.back();
      },
      error => {
        this.showLoader = false;
      }
    );
  }
}
