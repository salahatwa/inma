import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class PerformanceDetailsService {

    constructor(
        private url: UrlGeneratorService,
        private http: HttpClient,
        private common: CommonService,
        private readonly router: Router,
    ) { }

    getPerformanceDetails(): Observable<any> {
        let data = { userName: this.common.getUserDetails().userName,  loggedInUser: this.common.getUserDetails().userName };
        if (this.router.url.includes('manager-self-service')) {
            data = { userName: this.common.getUserNameForMngrAction(),  loggedInUser: this.common.getUserDetails().userName };
        }
        const url = this.url.getPerformanceDetails();
        return this.http.post<any>(url, data).pipe(
            tap((response) => {
                console.log(response);
            }),
            catchError((error) => {
                console.log(error);
                return throwError(error);
            })
        );
    }
}
