import { Injectable } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { Observable, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PerformanceRatingDetailsService {
  planTask: any = null;
  planId: any = null;
  managerAction: any;
  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private common: CommonService
  ) { }

  getPerformanceRatingAndObjectiveDetails(id, planId, managerAction?: boolean): Observable<any> {
    const dataObj = {
      userName: managerAction ? this.common.getUserNameForMngrAction() : this.common.getUserDetails().userName,
      loggedInUser: this.common.getUserDetails().userName,
      language: this.common.getRequestLanguage() + '###$$$' + id,
      appraisalId: id,
      planId
    };
    const dataPerf = {
      userName: managerAction ? this.common.getUserNameForMngrAction() : this.common.getUserDetails().userName,
      loggedInUser: this.common.getUserDetails().userName,
      language: this.common.getRequestLanguage(),
      appraisalId: id,
      planId
    };
    const performanceRatingUrl = this.url.getPerformanceRatingDetails();
    const objectiveListingUrl = this.url.objectiveListingUrl();
    const performanceRatingDetails = this.http.post<any>(performanceRatingUrl, dataPerf);
    const objectiveListingDetails = this.http.post<any>(objectiveListingUrl, dataObj);
    return forkJoin([performanceRatingDetails, objectiveListingDetails]).pipe(map((response) => {
      const performanceData = response[0];
      const objectiveData = response[1];
      performanceData.performObjectivesTab.forEach((element, index) => {
        const objective = objectiveData.objectiveListingTab.find(item => item.objectiveName === element.objectiveName);
        const mergedData = { ...objective, ...element };
        performanceData.performObjectivesTab[index] = mergedData;
      });
      performanceData.mobListDetailsTab = response[1].mobListDetailsTab;
      performanceData.headerTab = response[1].headerTab;
      return performanceData;
    }));
  }
}
