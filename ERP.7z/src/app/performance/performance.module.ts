import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { PerformanceComponent } from './performance.component';
// import { PerformanceDetailComponent } from './performance-detail/performance-detail.component';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { PerformanceRoutingModule } from './performance-routing.module';
// import { TrackEmployeeObjectiveComponent } from './track-employee-objective/track-employee-objective.component';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { PerformanceSubmitFeedbackComponent } from './performance-submit-feedback/performance-submit-feedback.component';
import { DigitOnlyModule } from '@uiowa/digit-only';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    FormsModule,
    PerformanceRoutingModule,
    ReactiveFormsModule,
    DigitOnlyModule,
    NgxMyDatePickerModule.forRoot()
  ],
  declarations: [
    PerformanceSubmitFeedbackComponent
  ]
})
export class PerformanceModule { }
