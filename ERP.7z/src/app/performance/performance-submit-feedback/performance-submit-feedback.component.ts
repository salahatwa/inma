import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { CompleteObjectiveService } from './../data-services/complete-objective.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-performance-submit-feedback',
  templateUrl: './performance-submit-feedback.component.html',
  styleUrls: ['./performance-submit-feedback.component.scss']
})
export class PerformanceSubmitFeedbackComponent implements OnInit {
  planName: any = null;
  appraisalId: any = null;
  feedbackComments: any = null;
  notificationMessage: any = null;
  feedbackRatingFlag = '';
  showLoader = false;
  overallRatings = '';
  formsubmitted = false;

  constructor(private route: ActivatedRoute, private router: Router,
    private common: CommonService, private completeObjective: CompleteObjectiveService,
    private location: Location) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params) => {
        this.appraisalId = params['id'];
        this.planName = params['name'];
      }
    );
    this.overallRatings = localStorage.getItem('overallRatings');
  }


  modalChange() {
    console.log(this.feedbackRatingFlag);
  }
/**
 * Function for submit their feedback
 */
  submitFeedback() {
    this.formsubmitted = true;
    if (this.feedbackRatingFlag) {
      const data: any = {};
      data.feedbackComments = this.feedbackComments;
      data.feedbackRatingFlag = this.feedbackRatingFlag;
      // if (this.feedbackRatingFlag) {
      //   data.feedbackRatingFlag = 'Y';
      // } else {
      //   data.feedbackRatingFlag = 'N';
      // }
      data.notificationComments = this.notificationMessage;
      data.appraisalId = this.appraisalId;
      this.showLoader = true;
      this.completeObjective.submitFeedback(data).subscribe(
        response => {
          const toast = {
            show: true,
            status: 'success',
            message: response.returnMsg
          };
          this.common.showToast(toast);
          this.showLoader = false;
          this.router.navigate(['/performance']);
        },
        error => {
          this.showLoader = false;
        }
      );
    }
  }

}
