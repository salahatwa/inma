import { PerformanceRatingDetailsService } from './data-services/performance-rating-details.service';
import { PerformanceDetailsService } from './data-services/performance-details.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-performance',
  templateUrl: './performance.component.html',
  styleUrls: ['./performance.component.scss']
})
export class PerformanceComponent implements OnInit {

  performanceDetailsObj = [];
  showLoader = false;
  noDataFound = false;
  returnMsg = '';
  managerAction = false;

  constructor(private performanceDetails: PerformanceDetailsService,
    private performanceRatings: PerformanceRatingDetailsService,
    private router: Router) { }

  ngOnInit() {
    this.getPerformanceDetails();
    if (this.router.url.includes('manager-self-service')) {
      this.managerAction = true;
    }
  }
/**
 * function for fetching performace details
 */
  getPerformanceDetails() {
    this.showLoader = true;
    this.performanceDetails.getPerformanceDetails().subscribe(
      response => {
        if (response.returnCode === '0') {
          this.performanceDetailsObj = response.performanceManagementTab;
        } else if (response.returnCode === '9') {
          this.performanceDetailsObj = [];
          this.returnMsg = response.returnMsg;
          this.noDataFound = true;
        } else {
          this.performanceDetailsObj = [];
        }
        this.showLoader = false;
      },
      error => {
        this.showLoader = false;
      }
    );
  }

  navigateToPerformanceDetail(item, managerAction?: boolean) {
    const flagObj = {};
    let planTask = 'VIEW';
    for (const objective of item.objectiveTab) {
      flagObj[objective.planTask] = objective.taskEnabled;
    }
    if (flagObj['View and Track objective progress'] === 'D' && flagObj['Finish objective setting'] === 'Y') {
      planTask = 'SUBMIT';
    } else if (flagObj['View and Track objective progress'] === 'D' && flagObj['Finish objective setting'] === 'N') {
      planTask = 'VIEW';
    } else if (flagObj['View and Track objective progress'] === 'Y' && flagObj['Finish objective setting'] === 'N') {
      planTask = 'TRACK';
    }
    this.performanceRatings.planTask = planTask;
    this.performanceRatings.planId = item.planId;
    this.performanceRatings.managerAction = managerAction;
    if (managerAction) {
      this.router.navigate(['/manager-self-service/performance/detail', (item.appraisalId ? item.appraisalId : 0), item.planName]);
    } else {
      this.router.navigate(['/performance/detail', (item.appraisalId ? item.appraisalId : 0), item.planName]);
    }
  }

}
