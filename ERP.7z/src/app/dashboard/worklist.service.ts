import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class WorklistService {
  workListDetails: { [k: string]: any } = {};

  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient
  ) { }

  getworkListData(data): Observable<any> {
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    const url = this.url.getworkListUrl();
    return this.http.post<any>(url, data).pipe(
      tap((response) => {

      }),
      catchError((error) => {

        return throwError(error);
      })
    );
  }

  setWorklistDetails(notificationId: string, itemType: string, codeOrProcessName: string, itemKey: string) {
    this.workListDetails.notificationId = notificationId;
    this.workListDetails.itemType = itemType;
    this.workListDetails.codeOrProcessName = codeOrProcessName;
    this.workListDetails.itemKey = itemKey;
  }


}
