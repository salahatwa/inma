import { NgModule } from '@angular/core';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { RouterModule } from '@angular/router';
import { WorklistDetailComponent } from './worklist-detail/worklist-detail.component';
import { TeamCalendarComponent } from './team-calendar/team-calendar.component';
import { FormsModule } from '@angular/forms';
import { WorklistTamDetailComponent } from './worklist-detail/worklist-tam-detail/worklist-tam-detail.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { FinanceWorklistDetailComponent } from './finance-worklist-detail/finance-worklist-detail.component';
import { CreditcardWorklistDetailComponent } from './creditcard-worklist-detail/creditcard-worklist-detail.component';

@NgModule({
  imports: [
    SharedModule,
    RouterModule,
    FormsModule,
    DashboardRoutingModule
  ],
  declarations: [DashboardComponent, WorklistDetailComponent, TeamCalendarComponent, WorklistTamDetailComponent, FinanceWorklistDetailComponent, CreditcardWorklistDetailComponent]
})

export class DashboardModule {}
