import { CommonService } from 'src/app/shared/services/common.service';
import { WorklistDetailService } from './../worklist-detail.service';
import { WorklistService } from './../../worklist.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { localStorageKey} from 'src/app/shared/constants/globalConstants';
@Component({
  selector: 'app-worklist-tam-detail',
  templateUrl: './worklist-tam-detail.component.html',
  styleUrls: ['./worklist-tam-detail.component.scss']
})
export class WorklistTamDetailComponent implements OnInit {
  public notificationDetails = [];
  public actionHistory = [];
  public hasAction = '';
  public showCommentError = false;
  public formsubmitted = false;
  public notificationId: number;
  public action = '';
  public fromUser = '';
  public toUser = '';
  public sentDate = '';
  public subject = '';
  public comments = '';
  public showLoader = false;
  public isReadOnly = false;
  language = this.common.getLanguage();
  assignedByUsers: any = [];
  showLoaderSearch: boolean;
  searchFlag: any = 'UNAME';
  searchText: any;
  showReassign: boolean;
  selectedAssignedBy: any = {};
  invalidSearchText: boolean;
  reassignAction: any = 'DELEGATE';
  reassignComments: any;
  isReassign = false;
  constructor(
    private readonly worklistService: WorklistService,
    private readonly worklistDetailService: WorklistDetailService,
    private readonly common: CommonService,
    private readonly router: Router
  ) { }

  ngOnInit() {
    this.getTamWorklistDetails();
    this.hasAction = localStorage.getItem(localStorageKey.HAS_ACTION);
    this.isReadOnly = (this.hasAction === 'N') ? true : false;
  }
  /* TAM Worklist details API */
  getTamWorklistDetails() {
    this.showLoader = true;
    const data = this.worklistService.workListDetails;
    this.notificationId = data.notificationId;
    this.worklistDetailService.getTamDetails(this.notificationId).subscribe(
      (response) => {
        this.showLoader = false;
        if (response.returnCode === '0') {
          this.notificationDetails = response.tamNotificationDetailsTab;
          this.actionHistory = response.actionHistoryTab;
          this.fromUser = response.fromUser;
          this.sentDate = response.sentDate;
          this.subject = response.subject;
          this.toUser = response.toUser;
        }
      },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  /* Submit Action  */
  onSubmit(actionType) {
    let validation = true;
    this.notificationDetails.forEach(element => {
      if (!element.violationTypeCode || !element.statusCode || !element.justification) {
        validation = false;
        return;
      }
    });
    if ((actionType === 'REQUEST_MORE_INFO') && (!this.comments)) {
      this.showCommentError = true;
      validation = false;
    }
    this.showLoader = true;
    this.formsubmitted = true;
    if (validation) {
      let data = {};
      if (actionType === 'REASSIGN') {
        if (!this.searchText || !this.selectedAssignedBy.userName) {
          this.invalidSearchText = true;
          this.searchText = '';
          return;
        } else {
           data = {
            action: this.reassignAction,
            comments: this.comments,
            forwardToUser: this.selectedAssignedBy.userName,
            itemKey: '',
            notificationId: this.notificationId,
            tamEditActionTab: this.notificationDetails
          };
        }
      } else {
         data = {
          action: actionType,
          comments: this.comments,
          forwardToUser: '',
          itemKey: '',
          notificationId: this.notificationId,
          tamEditActionTab: this.notificationDetails
        };
      }
      this.showCommentError = false;
      this.formsubmitted = false;
      this.worklistDetailService.executeTamActions(data).subscribe(
        (response) => {
          this.showLoader = false;
          const toast = {
            'show': true,
            'status': 'success',
            'message': response.returnMsg
          };
          this.common.showToast(toast);
          if (response.returnCode === '0') {
            this.router.navigate(['/dashboard']);
          }
        },
        (error) => {
          const toast = {
            'show': true,
            'status': 'failed',
            'message': 'Something went wrong, please try after some time'
          };
          this.common.showToast(toast);
        }
      );
    } else {
      this.showLoader = false;
    }
  }
  searchReassignUsers() {
    this.assignedByUsers = [];
    const userDetails = this.common.getUserDetails();
    this.showLoaderSearch = true;
    const data = {
      searchFlag: this.searchFlag,
      searchText: this.searchText,
      userName: userDetails.userName
    };
    this.worklistDetailService.executeSearchUsers(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.showReassign = true;
          this.assignedByUsers = response.userDetailsTab;
        } else if (response.returnCode === '1') {
        } else {
          /*this.showReassign = true;
          this.assignedByUsers = [
            {
              "personId": 81194,
              "userName": "KAMOHSEN",
              "fullName": "AwNR YTmO bOFY kHMU",
              "email": ""
            },
            {
              "personId": 63228,
              "userName": "EAMOHAMMED",
              "fullName": "HFme XeHS bbQt qjyA",
              "email": ""
            },
            {
              "personId": 1277,
              "userName": "EHMOHAMD",
              "fullName": "HMbr XFeF wErC adys",
              "email": ""
            },
            {
              "personId": 71916,
              "userName": "MAMOHAREB",
              "fullName": "IHru nMxX jYvv LGGP",
              "email": ""
            },
            {
              "personId": 1723,
              "userName": "KMOHAMEDALI",
              "fullName": "ItoX HMMi fkZW snxW",
              "email": ""
            },
            {
              "personId": 3042,
              "userName": "AIMOHIEMED",
              "fullName": "Mfqm oRcz fjqU FuRX",
              "email": ""
            },
            {
              "personId": 21591,
              "userName": "BAABDULMOHSIN",
              "fullName": "QYfI OAUW IslC AaQJ",
              "email": ""
            },
            {
              "personId": 40304,
              "userName": "AAMOHSEN",
              "fullName": "QzUH Jxqo Dcvj njTb",
              "email": ""
            },
            {
              "personId": 82251,
              "userName": "TRMOHAMMED",
              "fullName": "VArC TibX wMSC VCZO",
              "email": ""
            },
            {
              "personId": 4590,
              "userName": "ASMOHSEN",
              "fullName": "YvEp szjR MVTA bTma",
              "email": ""
            },
            {
              "personId": 104755,
              "userName": "AFMOHAISEN",
              "fullName": "ZXEI OprR nmqE vhut",
              "email": ""
            },
            {
              "personId": 117517,
              "userName": "MAALMOHAMMADI",
              "fullName": "auNC BwoS gBKZ fgzh",
              "email": ""
            },
            {
              "personId": 105794,
              "userName": "UDMOHANNA",
              "fullName": "iRCM frhd VDbi UTny",
              "email": ""
            },
            {
              "personId": 120255,
              "userName": "AAALMOHSEN",
              "fullName": "nAWY lHYO ABcb Ccmv",
              "email": ""
            },
            {
              "personId": 1440,
              "userName": "MAMOHAMED",
              "fullName": "naxw hvxJ wrTO FLkT",
              "email": ""
            },
            {
              "personId": 2996,
              "userName": "THMOHAMMAD",
              "fullName": "rqDw BBqo vCUg BfAT",
              "email": ""
            },
            {
              "personId": 100037,
              "userName": "JMOHALI",
              "fullName": "yDWh DKgc JUKl yGEt",
              "email": ""
            }
          ];*/
        }
        this.showLoaderSearch = false;
      },
      () => {
        this.showLoaderSearch = false;
      }
    );
  }
  chooseAssignedBy(assignedBy) {
    this.selectedAssignedBy = assignedBy;
    this.searchText = assignedBy.fullName;
    this.showReassign = false;
    this.invalidSearchText = false;
  }
  closeReassignPopup () {
    this.showReassign = false;
    this.searchText = '';
    this.showReassign = false;
    this.invalidSearchText = false;
    this.searchFlag = 'UNAME';
    this.reassignAction = 'DELEGATE';
  }
  changeSearchText () {
    this.selectedAssignedBy = {};
  }
}
