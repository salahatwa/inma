import { CommonService } from 'src/app/shared/services/common.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from '../../../../node_modules/rxjs';
import { WorklistService } from '../worklist.service';
import { WorklistDetailService } from './worklist-detail.service';
import { saveAs } from 'file-saver';
import {
  ToastFailed,
  ToastSuccess,
  localStorageKey
} from 'src/app/shared/constants/globalConstants';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-worklist-detail',
  templateUrl: './worklist-detail.component.html',
  styleUrls: ['./worklist-detail.component.scss']
})
export class WorklistDetailComponent implements OnInit, OnDestroy {
  showComments = false;
  executeComments: FormGroup;
  comments: string;
  showCommentsErr = false;
  workListDetailData = [];
  subjectData = [];
  actionHistoryData = [];
  workListDetailAttachment = [];
  worklistSubject = '';
  worklistToUser = '';
  worklistsentDate = '';
  worklistFromUser = '';
  dependentDeleteStatus = false;
  subscription$: Subscription;
  hasAction: string;
  showLoader = false;
  isSubjectTab = false;
  notificationId = '';
  itemKey = '';
  toUser = '';
  worklistApproverComments = '';
  isReassign = false;
  language = this.common.getLanguage();
  searchFlag: any = 'UNAME';
  reassignAction: any = 'DELEGATE';
  searchText: any;
  assignedByUsers: any = [];
  showReassign = false;
  selectedAssignedBy: any = {};
  invalidSearchText: boolean;
  showLoaderSearch: boolean;
  isCancelEmpEnroll: any;
  submitFlag = '';
  attachment = false;
  popupData: any;
  isOfficialTrip = false;
  isExpenceClaim = false;
  itemType = '';
  constructor(
    private readonly worklistdetail: WorklistDetailService,
    public readonly worklistService: WorklistService,
    private readonly common: CommonService,
    private readonly router: Router,
    private readonly formBuilder: FormBuilder,
    private readonly route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.worklistDetails();
    this.comments = '';
    this.isCancelEmpEnroll = this.route.snapshot.queryParams['isCancelEmpEnrollment'];
  }
  worklistDetails() {
    this.showLoader = true;
    this.hasAction = localStorage.getItem(localStorageKey.HAS_ACTION);
    const userDetails = this.common.getUserDetails();
    const userName = userDetails.userName;
    const data = this.worklistService.workListDetails;
    this.itemType = data.itemType;
    this.notificationId = data.notificationId;
    this.itemKey = data.itemKey;
    data.userName = userName;
    this.subscription$ = this.worklistdetail.getworkListDetail(data).subscribe(
      response => {
        this.showLoader = false;
        if (response.returnCode === '0' || response.returnCode === '9') {
          /* if (data.itemType !== 'XXINMHR') {
            this.workListDetailData = response.workListDetailsTab;
          } else {
            this.workListDetailData = response.offTripTab ? response.offTripTab[0] : response.expenseTab[0];
            if (response.offTripTab) {
              this.isOfficialTrip = true;
            } else if (response.expenseTab) {
              this.isOfficialTrip = false;
            }
          } */
          this.subjectData = response.subjectTab ? response.subjectTab : [];
          if (response.offTripTab || response.expenseTab) {
            this.workListDetailData = (response.offTripTab && response.offTripTab[0]) ||
              (response.expenseTab && response.expenseTab[0]);
            if (response.offTripTab) {
              this.isOfficialTrip = true;
            } else if (response.expenseTab) {
              this.isExpenceClaim = true;
            }
          } else {
            this.workListDetailData = response.workListDetailsTab;
          }
          this.actionHistoryData = response.actionHistoryTab;
          this.workListDetailAttachment = response.workListAttachmentDetailTab;
          this.worklistSubject = response.subject;
          this.worklistToUser = response.toUser;
          this.worklistsentDate = response.sentDate;
          this.worklistFromUser = response.fromUser;
          this.submitFlag = response.submitButtonFlag || response.submitFlag;
          if (response.actionHistoryTab.length) {
            for (let i = (response.actionHistoryTab.length - 1); i >= 0; i--) {
              if (response.actionHistoryTab[i].action === 'QUESTION') {
                this.worklistApproverComments = response.actionHistoryTab[i].comment;
              }
              break;
            }
          }
          if (data.codeOrProcessName === 'HR_PERSONAL_INFO_JSP_PRC') {
            this.workListDetailData.forEach(item => {
              if (item.key === 'Relationship End Date') {
                this.dependentDeleteStatus = true;
              }
            });
          }
        } else {
          this.workListDetailData = [];
          this.actionHistoryData = [];
        }

      },
      error => {
        this.showLoader = false;

      }
    );
  }

  getaddAttachment(mediaId) {
    this.worklistdetail.getaddAttachment(mediaId).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.saveFileInLocal(response);
          // this.absenceSummaryTab = response.absenceSummaryTab;
        }

      },
      error => {

      }
    );
  }
  saveFileInLocal(file) {
    const blob = this.common.createBlob(file);
    saveAs(blob, file.fileName);
  }
  executeAction(act_type) {
    const userDetails = this.common.getUserDetails();
    const userName = userDetails.userName;
    if ((act_type === 'REQUEST_MORE_INFO') && (this.comments === '')) {
      this.showCommentsErr = true;
    } else {
      let data = {};
      if (act_type === 'REASSIGN') {
        if (!this.searchText || !this.selectedAssignedBy.userName) {
          this.invalidSearchText = true;
          this.searchText = '';
          return;
        } else {
          data = {
            userName: userDetails.userName,
            notificationId: this.notificationId,
            itemKey: this.itemKey,
            action: this.reassignAction,
            comments: this.comments ? this.comments : null,
            forwardToUser: this.selectedAssignedBy.userName
          };
        }
      } else {
        data = {
          userName: userDetails.userName,
          notificationId: this.notificationId,
          itemKey: this.itemKey,
          action: act_type,
          comments: this.comments ? this.comments : null,
          forwardToUser: null
        };
      }
      this.showCommentsErr = false;
      this.showLoader = true;
      this.worklistdetail.executeAction(data, this.isCancelEmpEnroll).subscribe(
        response => {
          if (response.returnCode === '0') {
            this.router.navigate(['/dashboard']);
            this.showLoader = false;
            const toast = ToastSuccess;
            if (act_type === 'APPROVED') {
              toast.message = 'APPROVEMSG';
            } else if (act_type === 'REJECTED') {
              toast.message = 'REJECTMSG';
            } else if (act_type === 'CLOSED') {
              toast.message = 'The transaction has been closed';
            } else {
              toast.message = response.returnMsg;
            }
            this.common.showToast(toast);
          } else if (response.returnCode === '1') {
            this.showLoader = false;
            this.common.showToast(ToastFailed);
          }
          this.showLoader = false;
        },
        () => {
          this.showLoader = false;
          this.common.showToast(ToastFailed);
        }
      );
    }
  }

  requestInformation(type) {
    this.showComments = true;
    this.showCommentsErr = false;
    this.comments = '';
  }
  viewDetails(data) {
    this.attachment = true;
    this.popupData = data;
  }
  closeAttachment(event) {
    this.attachment = event;
  }
  ngOnDestroy() { }
  cancelCommentsPopup() {
    this.showComments = false;
    this.showCommentsErr = false;
    this.comments = '';
  }
  searchReassignUsers() {
    this.assignedByUsers = [];
    const userDetails = this.common.getUserDetails();
    this.showLoaderSearch = true;
    const data = {
      searchFlag: this.searchFlag,
      searchText: this.searchText,
      userName: userDetails.userName
    };
    this.worklistdetail.executeSearchUsers(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.showReassign = true;
          this.assignedByUsers = response.userDetailsTab;
        }
        this.showLoaderSearch = false;
      },
      () => {
        this.showLoaderSearch = false;
      }
    );
  }
  chooseAssignedBy(assignedBy) {
    this.selectedAssignedBy = assignedBy;
    this.searchText = assignedBy.fullName;
    this.showReassign = false;
    this.invalidSearchText = false;
  }
  closeReassignPopup() {
    this.isReassign = false;
    this.searchText = '';
    this.showReassign = false;
    this.invalidSearchText = false;
    this.searchFlag = 'UNAME';
    this.reassignAction = 'DELEGATE';
  }
  changeSearchText() {
    this.selectedAssignedBy = {};
  }
}
