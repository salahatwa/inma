import { CommonService } from 'src/app/shared/services/common.service';
import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class WorklistDetailService {
  workListDetail = [];
  constructor(
    private readonly url: UrlGeneratorService,
    private readonly common: CommonService,
    private readonly http: HttpClient
  ) { }
  getworkListDetail(data): Observable<any> {
    let language = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        language = 'ARABIC';
      }
    }
    data.language = language;
    let url = '';
    /*if (data.itemType === 'XXINMHR') {*/
      if (data.codeOrProcessName === 'EXPENSE') { /**this condtion for Expense claim work list details*/
        url = this.url.getExpenseClaimworkListAICDetailUrl();
      // tslint:disable-next-line: max-line-length
      } else if (data.codeOrProcessName === 'TRAINING' || data.codeOrProcessName === 'BUSINESS_TRIP') { /**this condtion for Official trip work list details*/
        url = this.url.getworkListAICDetailUrl();
      } else if (data.codeOrProcessName === 'HR_QUALIFICATION_JSP_PRC')  { /**this condtion for attendance work list details*/
        url = this.url.getEducationWorklistUrl();
      } else if (data.codeOrProcessName === '')  { /**this condtion for attendance work list details*/
        url = this.url.getAttendanceDetailUrl();
      } else { /**this condtion for normal work list details includes resignation*/
        url = this.url.getworkListDetailUrl();
      }
    /*} else {
      url = this.url.getworkListDetailUrl();
    }*/
    return this.http.post<any>(url, data);
  }
  getTamDetails(notificationId): Observable<any> {
    const url = this.url.getTamworkListDetailUrl();
    let lang = 'AMERICAN';
    if (localStorage.getItem('language')) {
      const localLanguage = localStorage.getItem('language');
      if (localLanguage === 'ar') {
        lang = 'ARABIC';
      }
    }
    const user = this.common.getUserDetails().userName;
    const data = {
      language: lang,
      notificationId: notificationId,
      userName: user
    };
    return this.http.post<any>(url, data);
  }
  getaddAttachment(mediaId): Observable<any> {
	const user = this.common.getUserDetails();
    const url = this.url.getaddAttachmentUrl();
    const data = {
      'tempId': +user.personId,
      'mediaId': mediaId
    };
    return this.http.post<any>(url, data);
  }

  executeAction(data, flag?): Observable<any> {
    let url;
    if (flag === 'Y') {
      url = this.url.getCancelEmpEnrollUrl();
    } else {
      url = this.url.getExecuteActionUrl();
    }
    return this.http.post<any>(url, data).pipe(
      tap((response) => {
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }
  executeTamActions(data): Observable<any> {
    const user = this.common.getUserDetails().userName;
    data.userName = user;
    const url = this.url.getTamActionUrl();
    return this.http.post<any>(url, data);
  }
  executeSearchUsers(data): Observable<any> {
    const user = this.common.getUserDetails().userName;
    data.userName = user;
    const url = this.url.getSearchUserlistUrl();
    return this.http.post<any>(url, data);
  }

}
