import { Component, OnInit } from '@angular/core';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription, Observable } from 'rxjs';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';
import { WorklistDetailService } from '../worklist-detail/worklist-detail.service';
@Component({
  selector: 'app-finance-worklist-detail',
  templateUrl: './finance-worklist-detail.component.html',
  styleUrls: ['./finance-worklist-detail.component.scss']
})
export class FinanceWorklistDetailComponent implements OnInit {
  showLoader = false;
  hasAction: string;
  routeSubscription$: Subscription;
  notificationId: any;
  itemKey: any;
  financeNotificationDetails: any ;
  financeNotificationTab: any;
  actionHistoryTab: any;
  comments: string;
  showErroMsg: boolean;
  submitClicked: boolean;
  language = this.common.getLanguage();
  assignedByUsers: any = [];
  showLoaderSearch: boolean;
  searchFlag: any = 'UNAME';
  searchText: any;
  additionalFlag = '';
  showReassign: boolean;
  selectedAssignedBy: any = {};
  invalidSearchText: boolean;
  reassignAction: any = 'DELEGATE';
  reassignComments: any;
  isReassign = false;
  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private readonly common: CommonService,
    private readonly activeRoute: ActivatedRoute,
    private readonly router: Router,
    private readonly worklistdetail: WorklistDetailService
  ) { }

  ngOnInit() {
    this.hasAction = localStorage.getItem('hasAction');
    /* Get the notification ID from URL route */
    this.routeSubscription$ = this.activeRoute.params.subscribe(params => {
      this.notificationId = params['id'];
      this.itemKey = params['item-key'];
    });
    this.getFinancingWorklistDetails();
  }
    /* worklist Details API for Financing Requests  */
    getFinancingWorklistDetails() {
      this.showLoader = true;
      const userDetails = this.common.getUserDetails();
      const data = {
        'language': this.common.getRequestLanguage(),
        'notificationId': this.notificationId,
        'userName':  userDetails.userName
      };
      const url = this.url.getFinancingWorklistDetailsUrl();
      this.postActionApi(data, url).subscribe( response => {
          if (response.returnCode === '0') {
            this.financeNotificationDetails = response.financeNotificationDetails;
            this.financeNotificationTab = response.financeNotificationTab;
            this.actionHistoryTab = response.actionHistoryTab;
            this.additionalFlag = response.cardTypeFalg;
          }

          this.showLoader = false;
      }, error => {
          this.showLoader = false;
      });
    }
    /* Submit ACTION API on user click */
    action(act_type: string){
      this.submitClicked = true;
      const userDetails = this.common.getUserDetails();
      if ((act_type === 'REQUEST_MORE_INFO') && (this.comments === '')) {
            this.showErroMsg = true;
      } else {
        let data = {};
        if (act_type === 'REASSIGN') {
          if (!this.searchText || !this.selectedAssignedBy.userName) {
            this.invalidSearchText = true;
            this.searchText = '';
            return;
          } else {
            data = {
              action: this.reassignAction,
              approvalComments: this.comments,
              approvedAmount: this.financeNotificationDetails.length ? this.financeNotificationDetails[0].approvedAmmount : 0,
              comments: this.reassignComments ? this.reassignComments : null,
              forwardToUser: this.selectedAssignedBy.userName,
              itemKey: this.itemKey,
              notificationId: this.notificationId,
              paybackPeriod: this.financeNotificationDetails.length ? this.financeNotificationDetails[0].periodPayback : 0,
              userName: userDetails.userName
          };
        }
      } else {
        data = {
          action: act_type,
          approvalComments: this.comments,
          approvedAmount: this.financeNotificationDetails.length ? this.financeNotificationDetails[0].approvedAmmount : 0,
          comments: '',
          forwardToUser: '',
          itemKey: this.itemKey,
          notificationId: this.notificationId,
          paybackPeriod: this.financeNotificationDetails.length ? this.financeNotificationDetails[0].periodPayback : 0,
          userName: userDetails.userName
        };
      }
        this.showErroMsg = false;
        this.showLoader = true;
        const url = this.url.getFinancingWorklistApprovalUrl();
        this.postActionApi(data, url).subscribe(
          response => {
            if (response.returnCode === '0') {
              this.router.navigate(['/dashboard']);
              this.showLoader = false;
              const toast = ToastSuccess;
              toast.message = response.returnMsg;
              this.common.showToast(toast);
            } else if (response.returnCode === '1') {
              this.showLoader = false;
              this.common.showToast(ToastFailed);
            }
            this.showLoader = false;
          },
          () => {
            this.showLoader = false;
            this.common.showToast(ToastFailed);
          }
        );
      }
    }
    /* Post Action API */
    postActionApi(data, url): Observable<any> {
      return this.http.post<any>(url, data);
    }
    searchReassignUsers() {
      this.assignedByUsers = [];
      const userDetails = this.common.getUserDetails();
      this.showLoaderSearch = true;
      const data = {
        searchFlag: this.searchFlag,
        searchText: this.searchText,
        userName: userDetails.userName
      };
      this.worklistdetail.executeSearchUsers(data).subscribe(
        response => {
          if (response.returnCode === '0') {
            this.showReassign = true;
            this.assignedByUsers = response.userDetailsTab;
          } else if (response.returnCode === '1') {
          } else {
            /*this.showReassign = true;
            this.assignedByUsers = [
              {
                "personId": 81194,
                "userName": "KAMOHSEN",
                "fullName": "AwNR YTmO bOFY kHMU",
                "email": ""
              },
              {
                "personId": 63228,
                "userName": "EAMOHAMMED",
                "fullName": "HFme XeHS bbQt qjyA",
                "email": ""
              },
              {
                "personId": 1277,
                "userName": "EHMOHAMD",
                "fullName": "HMbr XFeF wErC adys",
                "email": ""
              },
              {
                "personId": 71916,
                "userName": "MAMOHAREB",
                "fullName": "IHru nMxX jYvv LGGP",
                "email": ""
              },
              {
                "personId": 1723,
                "userName": "KMOHAMEDALI",
                "fullName": "ItoX HMMi fkZW snxW",
                "email": ""
              },
              {
                "personId": 3042,
                "userName": "AIMOHIEMED",
                "fullName": "Mfqm oRcz fjqU FuRX",
                "email": ""
              },
              {
                "personId": 21591,
                "userName": "BAABDULMOHSIN",
                "fullName": "QYfI OAUW IslC AaQJ",
                "email": ""
              },
              {
                "personId": 40304,
                "userName": "AAMOHSEN",
                "fullName": "QzUH Jxqo Dcvj njTb",
                "email": ""
              },
              {
                "personId": 82251,
                "userName": "TRMOHAMMED",
                "fullName": "VArC TibX wMSC VCZO",
                "email": ""
              },
              {
                "personId": 4590,
                "userName": "ASMOHSEN",
                "fullName": "YvEp szjR MVTA bTma",
                "email": ""
              },
              {
                "personId": 104755,
                "userName": "AFMOHAISEN",
                "fullName": "ZXEI OprR nmqE vhut",
                "email": ""
              },
              {
                "personId": 117517,
                "userName": "MAALMOHAMMADI",
                "fullName": "auNC BwoS gBKZ fgzh",
                "email": ""
              },
              {
                "personId": 105794,
                "userName": "UDMOHANNA",
                "fullName": "iRCM frhd VDbi UTny",
                "email": ""
              },
              {
                "personId": 120255,
                "userName": "AAALMOHSEN",
                "fullName": "nAWY lHYO ABcb Ccmv",
                "email": ""
              },
              {
                "personId": 1440,
                "userName": "MAMOHAMED",
                "fullName": "naxw hvxJ wrTO FLkT",
                "email": ""
              },
              {
                "personId": 2996,
                "userName": "THMOHAMMAD",
                "fullName": "rqDw BBqo vCUg BfAT",
                "email": ""
              },
              {
                "personId": 100037,
                "userName": "JMOHALI",
                "fullName": "yDWh DKgc JUKl yGEt",
                "email": ""
              }
            ];*/
          }
          this.showLoaderSearch = false;
        },
        () => {
          this.showLoaderSearch = false;
        }
      );
    }
    chooseAssignedBy(assignedBy) {
      this.selectedAssignedBy = assignedBy;
      this.searchText = assignedBy.fullName;
      this.showReassign = false;
      this.invalidSearchText = false;
    }
    closeReassignPopup () {
      this.isReassign = false;
      this.searchText = '';
      this.showReassign = false;
      this.invalidSearchText = false;
      this.searchFlag = 'UNAME';
      this.reassignAction = 'DELEGATE';
    }
    changeSearchText () {
      this.selectedAssignedBy = {};
    }
}
