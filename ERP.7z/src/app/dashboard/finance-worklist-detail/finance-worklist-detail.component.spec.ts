import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceWorklistDetailComponent } from './finance-worklist-detail.component';

describe('FinanceWorklistDetailComponent', () => {
  let component: FinanceWorklistDetailComponent;
  let fixture: ComponentFixture<FinanceWorklistDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinanceWorklistDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceWorklistDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
