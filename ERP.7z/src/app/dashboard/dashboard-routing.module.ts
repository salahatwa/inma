import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { AuthGuardService as AuthGuard } from './../core/services/auth-guard.service';
import { WorklistDetailComponent } from './worklist-detail/worklist-detail.component';
import { WorklistTamDetailComponent } from './worklist-detail/worklist-tam-detail/worklist-tam-detail.component';
import { CreditcardWorklistDetailComponent } from './creditcard-worklist-detail/creditcard-worklist-detail.component';
import { FinanceWorklistDetailComponent } from './finance-worklist-detail/finance-worklist-detail.component';

const routes: Routes = [
  { path: '', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'worklist-detail', component: WorklistDetailComponent, data: { title: 'WorkList' } },
  { path: 'worklist-tam-detail', component: WorklistTamDetailComponent, data: { title: 'WorkList' } },
  { path: 'creditcard-worklist-detail/:id/:item-key', component: CreditcardWorklistDetailComponent },
  { path: 'finance-worklist-detail/:id/:item-key', component: FinanceWorklistDetailComponent }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
