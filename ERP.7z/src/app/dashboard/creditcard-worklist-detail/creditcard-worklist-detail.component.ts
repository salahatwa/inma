import { Component, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { UrlGeneratorService } from 'src/app/core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { CommonService } from 'src/app/shared/services/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastSuccess, ToastFailed } from 'src/app/shared/constants/globalConstants';
import { WorklistDetailService } from '../worklist-detail/worklist-detail.service';

@Component({
  selector: 'app-creditcard-worklist-detail',
  templateUrl: './creditcard-worklist-detail.component.html',
  styleUrls: ['./creditcard-worklist-detail.component.scss']
})
export class CreditcardWorklistDetailComponent implements OnInit {
  routeSubscription$: Subscription;
  submitClicked;
  actionTypeEnter;
  comments = '';
  cardType;
  notificationId;
  showLoader = false;
  additionalInformation;
  actionHistoryTab;
  hasAction;
  itemKey;
  showErroMsg = false;
  language = this.common.getLanguage();
  assignedByUsers: any = [];
  showLoaderSearch: boolean;
  searchFlag: any = 'UNAME';
  searchText: any;
  showReassign: boolean;
  selectedAssignedBy: any = {};
  invalidSearchText: boolean;
  reassignAction: any = 'DELEGATE';
  reassignComments: any;
  isReassign = false;
  additionalFlag = '';
  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient,
    private readonly common: CommonService,
    private readonly activeRoute: ActivatedRoute,
    private readonly router: Router,
    private readonly worklistdetail: WorklistDetailService,
  ) { }

  ngOnInit() {
    this.hasAction = localStorage.getItem('hasAction');
    /* Get the notification ID from URL route */
    this.routeSubscription$ = this.activeRoute.params.subscribe(params => {
      this.notificationId = params['id'];
      this.itemKey = params['item-key'];
    });
    this.getCreditCardWorklistDetails();
  }
  /* Submit ACTION API on user click */
  action(act_type){
    this.submitClicked = true;
    const userDetails = this.common.getUserDetails();
    if ((act_type === 'REQUEST_MORE_INFO') && (this.comments === '')) {
          this.showErroMsg = true;
    } else {
      let data = {};
      if (act_type === 'REASSIGN') {
        if (!this.searchText || !this.selectedAssignedBy.userName) {
          this.invalidSearchText = true;
          this.searchText = '';
          return;
        } else {
           data = {
            userName: userDetails.userName,
            notificationId: this.notificationId,
            itemKey: this.itemKey,
            action: this.reassignAction,
            approvalComments: this.comments,
            comments: this.reassignComments ? this.reassignComments : null,
            forwardToUser: this.selectedAssignedBy.userName,
            cardType: this.additionalInformation[0].approvedCardType,
          };
        }
      } else {
        data = {
          action: act_type,
          approvalComments: this.comments,
          cardType: this.additionalInformation[0].approvedCardType,
          comments: this.comments,
          forwardToUser: '',
          itemKey: this.itemKey,
          notificationId: this.notificationId,
          userName: userDetails.userName
        };
      }
      this.showErroMsg = false;
      this.showLoader = true;
      const url = this.url.getCreditCardWorklistApprovalUrl();
      this.postActionApi(data, url).subscribe(
        response => {
          if (response.returnCode === '0') {
            this.router.navigate(['/dashboard']);
            this.showLoader = false;
            const toast = ToastSuccess;
            toast.message = response.returnMsg;
            this.common.showToast(toast);
          } else if (response.returnCode === '1') {
            this.showLoader = false;
            this.common.showToast(ToastFailed);
          }
          this.showLoader = false;
        },
        () => {
          this.showLoader = false;
          this.common.showToast(ToastFailed);
        }
      );
    }
  }
  /* worklist Details API for Credit Card Requests  */
  getCreditCardWorklistDetails(){
    this.showLoader = true;
    const userDetails = this.common.getUserDetails();
    const data = {
      'language': this.common.getRequestLanguage(),
      'notificationId': this.notificationId,
      'userName':  userDetails.userName
    };
    const url = this.url.getCreditCardWorklistDetailsUrl();
    this.postActionApi(data, url).subscribe( response => {
      if (response.returnCode === '0') {
          this.additionalInformation = response.notificationDetilsTab;
          this.actionHistoryTab = response.actionHistoryTab;
          this.additionalFlag = response.cardTypeFalg;
      }
        this.showLoader = false;
    }, error => {
        this.showLoader = false;
    });
  }
  /* Post Action API */
  postActionApi(data, url): Observable<any> {
    return this.http.post<any>(url, data);
  }
  searchReassignUsers() {
    this.assignedByUsers = [];
    const userDetails = this.common.getUserDetails();
    this.showLoaderSearch = true;
    const data = {
      searchFlag: this.searchFlag,
      searchText: this.searchText,
      userName: userDetails.userName
    };
    this.worklistdetail.executeSearchUsers(data).subscribe(
      response => {
        if (response.returnCode === '0') {
          this.showReassign = true;
          this.assignedByUsers = response.userDetailsTab;
        } else if (response.returnCode === '1') {
        } else {
          /*this.showReassign = true;
          this.assignedByUsers = [
            {
              "personId": 81194,
              "userName": "KAMOHSEN",
              "fullName": "AwNR YTmO bOFY kHMU",
              "email": ""
            },
            {
              "personId": 63228,
              "userName": "EAMOHAMMED",
              "fullName": "HFme XeHS bbQt qjyA",
              "email": ""
            },
            {
              "personId": 1277,
              "userName": "EHMOHAMD",
              "fullName": "HMbr XFeF wErC adys",
              "email": ""
            },
            {
              "personId": 71916,
              "userName": "MAMOHAREB",
              "fullName": "IHru nMxX jYvv LGGP",
              "email": ""
            },
            {
              "personId": 1723,
              "userName": "KMOHAMEDALI",
              "fullName": "ItoX HMMi fkZW snxW",
              "email": ""
            },
            {
              "personId": 3042,
              "userName": "AIMOHIEMED",
              "fullName": "Mfqm oRcz fjqU FuRX",
              "email": ""
            },
            {
              "personId": 21591,
              "userName": "BAABDULMOHSIN",
              "fullName": "QYfI OAUW IslC AaQJ",
              "email": ""
            },
            {
              "personId": 40304,
              "userName": "AAMOHSEN",
              "fullName": "QzUH Jxqo Dcvj njTb",
              "email": ""
            },
            {
              "personId": 82251,
              "userName": "TRMOHAMMED",
              "fullName": "VArC TibX wMSC VCZO",
              "email": ""
            },
            {
              "personId": 4590,
              "userName": "ASMOHSEN",
              "fullName": "YvEp szjR MVTA bTma",
              "email": ""
            },
            {
              "personId": 104755,
              "userName": "AFMOHAISEN",
              "fullName": "ZXEI OprR nmqE vhut",
              "email": ""
            },
            {
              "personId": 117517,
              "userName": "MAALMOHAMMADI",
              "fullName": "auNC BwoS gBKZ fgzh",
              "email": ""
            },
            {
              "personId": 105794,
              "userName": "UDMOHANNA",
              "fullName": "iRCM frhd VDbi UTny",
              "email": ""
            },
            {
              "personId": 120255,
              "userName": "AAALMOHSEN",
              "fullName": "nAWY lHYO ABcb Ccmv",
              "email": ""
            },
            {
              "personId": 1440,
              "userName": "MAMOHAMED",
              "fullName": "naxw hvxJ wrTO FLkT",
              "email": ""
            },
            {
              "personId": 2996,
              "userName": "THMOHAMMAD",
              "fullName": "rqDw BBqo vCUg BfAT",
              "email": ""
            },
            {
              "personId": 100037,
              "userName": "JMOHALI",
              "fullName": "yDWh DKgc JUKl yGEt",
              "email": ""
            }
          ];*/
        }
        this.showLoaderSearch = false;
      },
      () => {
        this.showLoaderSearch = false;
      }
    );
  }
  chooseAssignedBy(assignedBy) {
    this.selectedAssignedBy = assignedBy;
    this.searchText = assignedBy.fullName;
    this.showReassign = false;
    this.invalidSearchText = false;
  }
  closeReassignPopup () {
    this.isReassign = false;
    this.searchText = '';
    this.showReassign = false;
    this.invalidSearchText = false;
    this.searchFlag = 'UNAME';
    this.reassignAction = 'DELEGATE';
  }
  changeSearchText () {
    this.selectedAssignedBy = {};
  }
}
