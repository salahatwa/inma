import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditcardWorklistDetailComponent } from './creditcard-worklist-detail.component';

describe('CreditcardWorklistDetailComponent', () => {
  let component: CreditcardWorklistDetailComponent;
  let fixture: ComponentFixture<CreditcardWorklistDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditcardWorklistDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditcardWorklistDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
