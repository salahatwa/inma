import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { TeamCalendarService } from './team-calendar.service';
import { CommonService } from '../../shared/services/common.service';

@Component({
  providers: [DatePipe],
  selector: 'app-team-calendar',
  templateUrl: './team-calendar.component.html',
  styleUrls: ['./team-calendar.component.scss']
})
export class TeamCalendarComponent implements OnInit {


  teamCalendar = {
    teamCalendarList: [],
    holidayDateList: []
  };

  calendarView = [];
  calendarViewObjectTemplate = {
    'txt': '',
    'txtColor': '',
    'holidayFlag': '',
    'bgColor': '',
    'weekendFlag': '',
    'cellHeight': 'calendar-cell-height',
    'cellBorder': 'calendar-cell-border'
  };
  personNames = [];
  today: any;
  currentDate: any;
  currentMonth: any;
  monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  selectedMonth: any;
  currentYear: any;
  startDate: any;
  endDate: any;
  lastDateOfMonth: any;
  firstDayOfMonth: any;
  subscription$: any;

  constructor(
    public datepipe: DatePipe,
    private readonly calendarViewList: TeamCalendarService,
    private readonly common: CommonService) { }

  ngOnInit() {
    // self.calendarWidth = 'calendar-div-width-31';

    this.today = new Date();
    this.currentDate = this.today.getDate();
    this.currentMonth = this.monthNames[this.today.getMonth()];
    this.resetCalenderParams(this.today);
    this.populateTeamCalendar();
  }





  /**
  *To reset Calendar params on pre/nxt
  */
  refreshCalendar(status) {
    if (status === 'pre') {
      const newDate = new Date(this.startDate);
      newDate.setDate(newDate.getDate() - 1);
      this.resetCalenderParams(newDate);
    } else if (status === 'nxt') {
      const newDate = new Date(this.endDate);
      newDate.setDate(newDate.getDate() + 1);
      this.resetCalenderParams(newDate);
    }
    this.populateTeamCalendar();
  }
  /**
  *To reset/calculate month, year, startDate, endDate and lastDateOfMonth
  */
  resetCalenderParams(dateObject) {
    this.selectedMonth = this.monthNames[dateObject.getMonth()];
    this.currentYear = dateObject.getFullYear();
    this.startDate = this.datepipe.transform(new Date(this.currentYear, dateObject.getMonth(), 1), 'yyyy-MM-dd');
    this.endDate = this.datepipe.transform(new Date(this.currentYear, dateObject.getMonth() + 1, 0), 'yyyy-MM-dd');
    this.lastDateOfMonth = new Date(this.currentYear, dateObject.getMonth() + 1, 0).getDate();
    this.firstDayOfMonth = new Date(this.currentYear, dateObject.getMonth(), 1).getDay();
  }

  /**
  *API call to fetch leaves with tartDate and endDate
  */
  populateTeamCalendar() {
    const userDetails = this.common.getUserDetails();
    const data = {
      'userName': userDetails.userName,
      'fromDate': this.startDate,
      'toDate': this.endDate
    };

    this.subscription$ = this.calendarViewList.getCalendarList(data).subscribe((response) => {
      if (response.returnCode === '0') {
        this.teamCalendar.teamCalendarList = response.teamCalendarTab;
        this.teamCalendar.holidayDateList = response.teamCalendarHolidayTab;
        this.teamCalendar.teamCalendarList.forEach((value) => {
          const startDate = new Date(value.startDate);
          const endDate = new Date(value.endDate);
          if (!(((startDate.getFullYear() === new Date(this.startDate).getFullYear())
            && (startDate.getMonth() === new Date(this.startDate).getMonth()))
            || (((endDate.getFullYear() === new Date(this.endDate).getFullYear())
              && (endDate.getMonth() === new Date(this.endDate).getMonth()))))) {
            value.startDate = this.startDate;
            value.endDate = this.endDate;
          } else if (startDate.getMonth() !== endDate.getMonth()) {
            if (new Date(this.startDate).getMonth() === startDate.getMonth()) {
              const lastDate = new Date(new Date(this.startDate).getFullYear(), new Date(this.startDate).getMonth() + 1, 0);
              value.endDate = `${new Date(this.startDate).getFullYear()}-${new Date(this.startDate).getMonth() + 1}-${lastDate.getDate()} 00:00:00.0`;
            }
            if (new Date(this.endDate).getMonth() === endDate.getMonth()) {
              value.startDate = `${new Date(this.endDate).getFullYear()}-${new Date(this.endDate).getMonth() + 1}-1 00:00:00.0`;
            }
          }
        });
      } else {
        this.teamCalendar.teamCalendarList = [];
        this.teamCalendar.holidayDateList = [];
      }
      this.generateTeamCalendar();
    },
      (error) => {

      }
    );
  }

  /**
  *To set calendarView objects
  */
  generateTeamCalendar() {
    // resetCalendarWidth();
    const leaveList = this.createLeaveList();
    this.calendarView = [];
    const calendarRowTemplate = this.createCalendarTempalte(this.lastDateOfMonth);
    const calendarDayHeader = this.createCalendarDayHeader(this.firstDayOfMonth, JSON.parse(JSON.stringify(calendarRowTemplate)));
    this.calendarView.push(calendarDayHeader);
    const calendarDateHeader = this.createCalendarDateHeader(JSON.parse(JSON.stringify(calendarRowTemplate)));
    this.calendarView.push(calendarDateHeader);
    // var calendarLeaves = createCalendarLeaves(angular.copy(calendarRowTemplate), leaveList);
    this.createCalendarLeaves(JSON.parse(JSON.stringify(calendarRowTemplate)), leaveList);
    // self.calendarView.push(calendarLeaves);
    this.personNames = this.createPersonNames(leaveList);
  }

  /*
  *To create leave array for each person
  */
  createLeaveList() {
    const leaveList = [];
    let tempList = [];
    if (this.teamCalendar.teamCalendarList.length !== 0) {
      let tempPersonId = this.teamCalendar.teamCalendarList[0].personId;
      for (let i = 0; i < this.teamCalendar.teamCalendarList.length; i++) {
        if (tempPersonId !== this.teamCalendar.teamCalendarList[i].personId) {
          leaveList.push(tempList);
          tempList = [];
          tempPersonId = this.teamCalendar.teamCalendarList[i].personId;
        }
        tempList.push(this.teamCalendar.teamCalendarList[i]);

      }
      leaveList.push(tempList);
    }
    return leaveList;
  }
  /*
  *To create a master calendar row object for the month having arrasy of 30/30 objects
  */
  createCalendarTempalte(lastDay) {
    const calendarRow = [];
    for (let i = 1; i <= lastDay; i++) {
      calendarRow.push(JSON.parse(JSON.stringify(this.calendarViewObjectTemplate)));
    }
    return calendarRow;
  }

  /**
   * To create Calendar header row with days
   */
  createCalendarDayHeader(firstDay, calendarDayHeader) {
    const days = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    for (let i = 0; i < calendarDayHeader.length; i++) {
      calendarDayHeader[i].txt = days[firstDay];
      calendarDayHeader[i].txtColor = 'calender-week-day-color';
      calendarDayHeader[i].holidayFlag = '';
      calendarDayHeader[i].weekendFlag = '';
      calendarDayHeader[i].cellBorder = 'calendar-cell-border';
      calendarDayHeader[i].bgColor = 'calendar-div-header-color';
      calendarDayHeader[i].cellHeight = 'calendar-header-height';
      if (firstDay === 5 || firstDay === 6) {
        calendarDayHeader[i].txtColor = 'calendar-weekend-day-color';
      }
      firstDay++;
      if (firstDay > 6) {
        firstDay = 0;
      }
    }
    if (this.currentMonth === this.selectedMonth) {
      calendarDayHeader[this.currentDate - 1].bgColor = 'calendar-today';

    }
    return calendarDayHeader;
  }

  /**
    * To create Calendar header row with dates
    */
  createCalendarDateHeader(calendarDateHeader) {

    for (let i = 0; i < calendarDateHeader.length; i++) {
      calendarDateHeader[i].txt = i + 1;
      calendarDateHeader[i].txtColor = 'calender-week-day-color';
      calendarDateHeader[i].holidayFlag = '';
      calendarDateHeader[i].weekendFlag = '';
      calendarDateHeader[i].cellBorder = 'calendar-cell-border';
      calendarDateHeader[i].bgColor = 'calendar-div-header-color';
      calendarDateHeader[i].cellHeight = 'calendar-header-height';
    }
    if (this.currentMonth === this.selectedMonth) {
      calendarDateHeader[this.currentDate - 1].bgColor = 'calendar-today';
    }
    return calendarDateHeader;
  }

  /**
   * To create calendar leave rows using leaveList array
   */
  createCalendarLeaves(rowTemplate, leaveList) {
    // var leaveRows = [];
    let tempRowTemplate = [];
    let tempLeaves = [];
    for (let i = 0; i < leaveList.length; i++) {
      tempRowTemplate = JSON.parse(JSON.stringify(rowTemplate));
      tempLeaves = leaveList[i];
      for (let j = 0; j < tempLeaves.length; j++) {
        const start = new Date(tempLeaves[j].startDate).getDate();
        const end = new Date(tempLeaves[j].endDate).getDate();
        const status = tempLeaves[j].status;
        for (let k = start; k <= end; k++) {
          switch (status) {
            case 'Approved':
              tempRowTemplate[k - 1].bgColor = 'calendar-approved';
              break;
            case 'Requested':
              tempRowTemplate[k - 1].bgColor = 'calendar-requested';
              break;
            default:

          }
        }
      }
      for (let j = 0; j < this.teamCalendar.holidayDateList.length; j++) {
        const start = new Date(this.teamCalendar.holidayDateList[j].holidayStartDate).getDate();
        const end = new Date(this.teamCalendar.holidayDateList[j].holidayEndDate).getDate();
        for (let k = start; k <= end; k++) {
          if (this.teamCalendar.holidayDateList[j].weekendFlag === 'Y') {
            tempRowTemplate[k - 1].weekendFlag = 'Y';
            tempRowTemplate[k - 1].bgColor = 'calendar-weekend';
          } else {
            tempRowTemplate[k - 1].holidayFlag = 'Y';
          }
        }
      }
      this.calendarView.push(tempRowTemplate);
    }
    // return leaveRows;
  }
  /**
   * To Create array of person names
   */
  createPersonNames(leaveList) {
    const personNames = [
      { 'name': ' ', 'cellHeight': 'calendar-name-div-header-height', 'bgColor': 'calendar-name-div-header-bg' },
      { 'name': ' ', 'cellHeight': 'calendar-name-div-header-height', 'bgColor': 'calendar-name-div-header-bg' }
    ];
    for (let i = 0; i < leaveList.length; i++) {
      personNames.push(
        {
          'name': leaveList[i][0].employeeName,
          'cellHeight': 'calendar-name-div-height',
          'bgColor': 'calendar-name-div-bg'
        }
      );
    }
    return personNames;
  }
}
