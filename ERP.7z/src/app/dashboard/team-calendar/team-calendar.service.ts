import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TeamCalendarService {

  teamCalendarData = [];
  constructor(
    private url: UrlGeneratorService,
    private http: HttpClient
  ) { }

  getCalendarList(data): Observable<any> {
    const url = this.url.getTeamCalendarUrl();
    return this.http.post<any>(url, data).pipe(
        tap((response) => {
        }),
        catchError((error) => {
            return throwError(error);
        })
    );
}
}
