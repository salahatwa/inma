import { TranslateService } from '@ngx-translate/core';
import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { WorklistService } from './worklist.service';
import { CommonService } from '../shared/services/common.service';
import { Router } from '@angular/router';
import { AbsenceCountService } from './absencecount.service';
import { TamService } from '../tam/find-tam/tam.service';
import { localStorageKey } from 'src/app/shared/constants/globalConstants';
declare const c3;
declare const d3;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public showLoader = false;
  public chartData: any = {
    approvedCount: 0,
    pendingCount: 0,
    rejectedCount: 0,
    total: 0
  };
  public pending = 0;
  public approved = 0;
  public showGraph = false;
  public rejected = 0;
  public total = 0;
  public graphZero = false;
  public workListData = [];
  public subscription$: Subscription;
  public weekly = true;
  public tamDashboard: any = [];
  public persWorkedHrsWeekly: any;
  public persRemainingWeekly: any;
  public persWorkedHrsDay: any;
  public persRemainingDay: any;
  entiltmentBalance: any;
  constructor(
    private worklistservice: WorklistService,
    private readonly common: CommonService,
    private readonly absencecountService: AbsenceCountService,
    private readonly router: Router,
    private translate: TranslateService,
    private readonly tamService: TamService,
  ) { }

  ngOnInit() {
    this.getworkList();
    this.getAbsenseSummaryCount();
    //this.getTAMHourDetails();
    this.weekly = true;
  }
  /* Navigate to Worklist Details page */
  showWorkDetail(notificationId, itemType, codeOrProcessName, hasAction, itemKey) {
    if (localStorage.getItem(localStorageKey.HAS_ACTION)) {
      localStorage.setItem(localStorageKey.HAS_ACTION, '');
    }
    localStorage.setItem(localStorageKey.HAS_ACTION, hasAction);
    this.worklistservice.setWorklistDetails(notificationId, itemType, codeOrProcessName, itemKey);
    if (itemType === 'XXINMOTL') {
      this.router.navigate(['/dashboard/worklist-tam-detail']);
    } else if (codeOrProcessName === 'CREDIT_CARD') {
      this.router.navigate(['/dashboard/creditcard-worklist-detail', notificationId, itemKey]);
    } else if (codeOrProcessName === 'FINANCE_REQUEST') {
      this.router.navigate(['/dashboard/finance-worklist-detail', notificationId, itemKey]);
    } else if (codeOrProcessName === 'OLM_CANCEL_EMP_ENROLLMENT' && itemType === 'XXINMOLM') {
      this.router.navigate(['/dashboard/worklist-detail'], { queryParams: { isCancelEmpEnrollment: 'Y' } });
    } else {
      this.router.navigate(['/dashboard/worklist-detail'], { queryParams: { isCancelEmpEnrollment: 'N' } });
    }
  }
  /* Get the list of worklists */
  getworkList() {
    this.showLoader = true;
    const userDetails = this.common.getUserDetails();
    const userName = userDetails.userName;
    const data = {
      'userName': userName
    };
    this.subscription$ = this.worklistservice.getworkListData(data).subscribe((response) => {
      this.showLoader = false;
      if (response.returnCode === '0') {
        this.workListData = response.workListTab;
      }
    },
      (error) => {
        this.showLoader = false;
      }
    );
  }
  /* Change event for the Weekly and daily toggle button in schedule tab */
  choose(event) {
    this.weekly = event;
  }
  /* Generate absence summary donut chart */
  generateData() {
    const remaining = this.translate.instant('Remaining');
    const consumed = this.translate.instant('Consumed');
    this.chartData = {
      approvedCount: this.approved,
      pendingCount: this.pending,
      rejectedCount: this.rejected,
      total: this.total
    };
    const type = 'donut';
    const title = this.total;
    const columns = [
      ['Pending Actions ' + this.chartData.pendingCount, this.chartData.pendingCount],
      [remaining + ' ' + this.chartData.rejectedCount, this.chartData.rejectedCount],
      [consumed + ' ' + this.chartData.approvedCount, this.chartData.approvedCount],
    ];

    const colors = {
    };
    colors[columns[0][0]] = '#f9d400';
    colors[columns[1][0]] = '#e11352';
    colors[columns[2][0]] = '#701f6c';
    c3.generate({
      bindto: '#chart',
      size: {
        height: 140,
      },
      data: {
        columns,
        colors,
        type
      },
      donut: {
        title,
        label: {
          format(value, ratio, id) {
            return '';
          }
        },
        width: 15,
      },
      legend: {
        show: false,
        position: 'right',
        format: {
          title(a) {
            return 'Legend title';
          },
          name(a) {
            return 'Legend name';
          },
          value(a) {
            return 'Legend value';
          }
        }
      }
    });
    const label = d3.select('text.c3-chart-arcs-title');

    label.html('');
    label.insert('tspan').text(this.chartData.total).attr('dy', 0).attr('x', 0).attr('class', 'graph-value');
    label.insert('tspan').text('Total').attr('dy', 20).attr('x', 0);

  }

  /* Get the absense Summary details */
  getAbsenseSummaryCount() {
    this.absencecountService.getAbsenseSummaryCount().subscribe(
      (response) => {
        this.showGraph = true;
        if (response.returnCode === '0') {
          const count = response.absenseCountTab;
          if (count[0].balanceTab && count[0].balanceTab[0] && count[0].balanceTab[0].leaveBalance) {
            this.entiltmentBalance = count[0].balanceTab[0].leaveBalance;
          }
          this.pending = count[0].pendingLeave ? count[0].pendingLeave : 0;
          this.approved = count[0].approvedLeave ? count[0].approvedLeave : 0;
          this.rejected = count[0].rejectedLeave ? count[0].rejectedLeave : 0;
          this.total = this.pending + this.approved + this.rejected;
          if (this.total === 0) {
            this.graphZero = true;
          } else {
            this.graphZero = false;
          }
        } else {
          this.graphZero = true;
          this.pending = 0;
          this.approved = 0;
          this.rejected = 0;
          this.total = 0;
        }
        this.generateData();
      },
      () => {
        this.graphZero = true;
      }
    );
  }
  /* Convert 24 hours format time to minutes */
  // convertHourToMinut(hours) {
  //   if (hours) {
  //     return ((Math.abs(hours.split(':')[0]) * 60) + Math.abs(hours.split(':')[1]));
  //   } else {
  //     return 0;
  //   }
  // }

  /* Get TAM hour details API */
  // getTAMHourDetails() {
  //   const userName = this.common.getUserDetails().userName;
  //   const data = {
  //     'userName': userName
  //   };
  //   this.showLoader = true;
  //   this.tamService.getTAMDashboardDetails(data).subscribe(
  //     (response) => {
  //       this.showLoader = false;
  //       if (response.returnCode === '0') {
  //         this.tamDashboard = response;
  //         if (this.tamDashboard.workedWeeklyFlag === 'POSITIVE') {
  //           this.persWorkedHrsWeekly = '100%';
  //           this.persRemainingWeekly = '0%';
  //          } else {
  //           // tslint:disable-next-line:max-line-length
  //           this.persWorkedHrsWeekly = ((this.convertHourToMinut(this.tamDashboard.workedHrsWeekly) * 100) / this.convertHourToMinut(this.tamDashboard.totalHrsWeekly)) + '%';
  //           // tslint:disable-next-line:max-line-length
  //           this.persRemainingWeekly = ((this.convertHourToMinut(this.tamDashboard.remainingWeekly) * 100) / this.convertHourToMinut(this.tamDashboard.totalHrsWeekly)) + '%';
  //          }
  //          if (this.tamDashboard.workedDailyFlag === 'POSITIVE') {
  //           this.persWorkedHrsDay = '100%';
  //           this.persRemainingDay = '0%';
  //          } else {
  //           // tslint:disable-next-line:max-line-length
  //           this.persWorkedHrsDay = ((this.convertHourToMinut(this.tamDashboard.workedHrsDay) * 100) / this.convertHourToMinut(this.tamDashboard.totalHrsDay)) + '%';
  //           // tslint:disable-next-line:max-line-length
  //           this.persRemainingDay = ((this.convertHourToMinut(this.tamDashboard.remainingDay) * 100) / this.convertHourToMinut(this.tamDashboard.totalHrsDay)) + '%' ;
  //          }
  //          this.tamDashboard.remainingWeekly =  this.tamDashboard.remainingWeekly.replace('-', '').replace('+', '');
  //          this.tamDashboard.remainingDay = this.tamDashboard.remainingDay.replace('-', '').replace('+', '');
  //       }
  //     },
  //     (error) => {
  //       this.showLoader = false;
  //     }
  //   );
  // }
}
