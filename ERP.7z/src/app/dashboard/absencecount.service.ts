import { Injectable } from '@angular/core';
import { UrlGeneratorService } from '../core/services/url-generator.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { CommonService } from '../shared/services/common.service';

@Injectable({
    providedIn: 'root'
})
export class AbsenceCountService {

    constructor(
        private url: UrlGeneratorService,
        private http: HttpClient,
        private readonly common: CommonService
    ) { }
    /* Absense Summary Count API */
    getAbsenseSummaryCount(): Observable<any> {
        const userDetails = this.common.getUserDetails();
        const data = {
            'userName': userDetails.userName
        };
        const url = this.url.getAbsenseSummaryCountUrl();
        return this.http.post<any>(url, data).pipe(
            catchError((error) => {
                return throwError(error);
            })
        );
    }

}
