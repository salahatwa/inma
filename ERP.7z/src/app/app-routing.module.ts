import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { QuickLinksComponent } from './quick-links/quick-links.component';
import { ComingSoonComponent } from './coming-soon/coming-soon.component';
//import { ComingSoonComponent } from './coming-soon/coming-soon.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', loadChildren: '../app/login/login.module#LoginModule' },
  { path: 'dashboard', loadChildren: '../app/dashboard/dashboard.module#DashboardModule', data: { title: 'Dashboard' } },
  { path: 'myprofile', loadChildren: '../app/myprofile/myprofile.module#MyprofileModule', data: { title: 'My Profile' } },
  { path: 'attendance', loadChildren: '../app/tam/tam.module#TamModule' },
  {
    path: 'leave-management',
    loadChildren: '../app/leave-management/leave-management.module#LeaveManagementModule', data: { title: 'Leave Management' }
  },
  { path: 'learning', loadChildren: '../app/learning/learning.module#LearningModule', data: { title: 'Learning' } },
  { path: 'performance', loadChildren: '../app/performance/performance.module#PerformanceModule' },
  {
    path: 'employee-request',
    loadChildren: '../app/employee-request/employee-request.module#EmployeeRequestModule',
    data: { title: 'Employee Requests' }
  },
  { path: 'manager-self-service', loadChildren: '../app/manager-self-service/manager-self-service.module#ManagerSelfServiceModule' },
  { path: 'quick-links', component: QuickLinksComponent, data: { title: 'Quick Links ' } },
  { path: '**', component: ComingSoonComponent, data: { title: 'Not Found' } }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true }),
    CommonModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
