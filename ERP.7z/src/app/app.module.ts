import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { CoreModule } from './core/core.module';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { routing } from './app-routing';
import { DashboardModule } from './dashboard/dashboard.module';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SharedModule } from './shared/shared.module';
import { MyprofileModule } from './myprofile/myprofile.module';
import { LeaveManagementModule } from './leave-management/leave-management.module';
import { EmployeeRequestModule } from './employee-request/employee-request.module';
// import { HomeComponent } from './home/home.component';
import { ReactiveFormsModule } from '@angular/forms';
import { PerformanceModule } from './performance/performance.module';
import { ManagerSelfServiceModule } from './manager-self-service/manager-self-service.module';
import { LearningModule } from './learning/learning.module';
import { LoginModule } from './login/login.module';
import { TamModule } from './tam/tam.module';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ComingSoonComponent } from './coming-soon/coming-soon.component';
import { QuickLinksComponent } from './quick-links/quick-links.component';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
@NgModule({
  declarations: [
    AppComponent,
    // HomeComponent,
    ComingSoonComponent,
    QuickLinksComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    SharedModule,
    TamModule,
    HttpClientModule,
    ReactiveFormsModule,
    // routing,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
